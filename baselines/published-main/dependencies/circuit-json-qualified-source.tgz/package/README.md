# Circuit JSON Specification `circuit-json`

Circuit JSON a low-level JSON-array circuit representation. It contains all the information needed to visually represent a schematic, PCB, produce Gerber files, produce bill of materials, run SPICE simulations, view warnings and more. It is designed to easily interoperate with a SQL database.

[tscircuit](https://github.com/tscircuit/tscircuit) · [discord](https://tscircuit.com/join) · [online circuit json viewer](https://circuitjson.com/) · [example.json](https://github.com/tscircuit/circuitjson.com/blob/main/assets/usb-c-flashlight.json) · [Introduction to Circuit JSON Video](https://www.youtube.com/watch?v=QMWobH5tmqo)

[![npm version](https://badge.fury.io/js/circuit-json.svg)](https://badge.fury.io/js/circuit-json)

You can think of Circuit JSON as a big JSON array of "Circuit Elements", each
element can have references to other elements, for example a `source_component`
has a corresponding `pcb_component` representation, which has a corresponding
set of `pcb_ports` and is connected via `pcb_traces`.

If you generated Circuit JSON, you can use a wide range of utilities and libraries
provided by tscircuit. For example, if you want to autoroute a PCB, you could
use Circuit JSON as an input to the [tscircuit dsn-converter](https://github.com/tscircuit/dsn-converter)
to generate a DSN file for [freerouting](https://github.com/freerouting/freerouting), you
could then read the DSN file back to Circuit JSON.

This module has the zod definitions and conversion functions for using circuit json,
and is the primary way that Circuit JSON is defined and maintained.

https://github.com/user-attachments/assets/2f28b7ba-689e-4d80-85b2-5bdef84b41f8

> To quickly generate Circuit JSON with tscircuit, use [tscircuit/eval](https://github.com/tscircuit/eval)

## Things You Can Do With Circuit JSON

- Generate [Gerber files](https://github.com/tscircuit/circuit-json-to-gerber)
- Generate and read [Specctra DSN Autorouting files](https://github.com/tscircuit/dsn-converter)
- Generate [Pick'n'Place Files](https://github.com/tscircuit/circuit-json-to-pnp-csv)
- Generate [PCB and Schematic SVGs](https://github.com/tscircuit/circuit-to-svg)
- Generate [Bill of Materials](https://github.com/tscircuit/circuit-json-to-bom-csv)
- Generate [SPICE netlists and simulations](https://github.com/tscircuit/circuit-json-to-spice)
- Display [PCBs on the web](https://github.com/tscircuit/pcb-viewer)
- Display [Schematics on the web](https://github.com/tscircuit/schematic-viewer)
- Display [3d models of electronics on the web](https://github.com/tscircuit/3d-viewer)
- Render [Circuit JSON to a GLTF](https://github.com/tscircuit/circuit-json-to-gltf)

## Table of Contents

<!-- toc:start -->

- [Circuit JSON Specification `circuit-json`](#circuit-json-specification-circuit-json)

  - [Things You Can Do With Circuit JSON](#things-you-can-do-with-circuit-json)
  - [Typescript Usage](#typescript-usage)

  - [Source Components](#source-components)
    - [SourceAmbiguousPortReference](#sourceambiguousportreference)
    - [SourceBoard](#sourceboard)
    - [SourceBus](#sourcebus)
    - [SourceComponentBase](#sourcecomponentbase)
    - [SourceComponentInternalConnection](#sourcecomponentinternalconnection)
    - [SourceComponentMisconfiguredError](#sourcecomponentmisconfigurederror)
    - [SourceComponentPinsUnderspecifiedWarning](#sourcecomponentpinsunderspecifiedwarning)
    - [SourceConfusingNetNameWarning](#sourceconfusingnetnamewarning)
    - [SourceFailedToCreateComponentError](#sourcefailedtocreatecomponenterror)
    - [SourceGroup](#sourcegroup)
    - [SourceI2cMisconfiguredError](#sourcei2cmisconfigurederror)
    - [SourceInterconnect](#sourceinterconnect)
    - [SourceInvalidComponentPropertyError](#sourceinvalidcomponentpropertyerror)
    - [SourceManuallyPlacedVia](#sourcemanuallyplacedvia)
    - [SourceMissingManufacturerPartNumberWarning](#sourcemissingmanufacturerpartnumberwarning)
    - [SourceMissingPropertyError](#sourcemissingpropertyerror)
    - [SourceNet](#sourcenet)
    - [SourceNoGroundPinDefinedWarning](#sourcenogroundpindefinedwarning)
    - [SourceNoPowerPinDefinedWarning](#sourcenopowerpindefinedwarning)
    - [SourcePartNotFoundWarning](#sourcepartnotfoundwarning)
    - [SourcePcbGroundPlane](#sourcepcbgroundplane)
    - [SourcePinAttributes](#sourcepinattributes)
    - [SourcePinMissingTraceWarning](#sourcepinmissingtracewarning)
    - [SourcePinMustBeConnectedError](#sourcepinmustbeconnectederror)
    - [SourcePort](#sourceport)
    - [SourceProjectMetadata](#sourceprojectmetadata)
    - [SourcePropertyIgnoredWarning](#sourcepropertyignoredwarning)
    - [SourceRefdesConventionWarning](#sourcerefdesconventionwarning)
    - [SourceRuntimeError](#sourceruntimeerror)
    - [SourceSimpleAmmeter](#sourcesimpleammeter)
    - [SourceSimpleBattery](#sourcesimplebattery)
    - [SourceSimpleCapacitor](#sourcesimplecapacitor)
    - [SourceSimpleChip](#sourcesimplechip)
    - [SourceSimpleConnector](#sourcesimpleconnector)
    - [SourceSimpleCrystal](#sourcesimplecrystal)
    - [SourceSimpleCurrentSource](#sourcesimplecurrentsource)
    - [SourceSimpleDiode](#sourcesimplediode)
    - [SourceSimpleFiducial](#sourcesimplefiducial)
    - [SourceSimpleFuse](#sourcesimplefuse)
    - [SourceSimpleGround](#sourcesimpleground)
    - [SourceSimpleInductor](#sourcesimpleinductor)
    - [SourceSimpleLed](#sourcesimpleled)
    - [SourceSimpleMosfet](#sourcesimplemosfet)
    - [SourceSimpleOpAmp](#sourcesimpleopamp)
    - [SourceSimplePinHeader](#sourcesimplepinheader)
    - [SourceSimplePinout](#sourcesimplepinout)
    - [SourceSimplePotentiometer](#sourcesimplepotentiometer)
    - [SourceSimplePowerSource](#sourcesimplepowersource)
    - [SourceSimplePushButton](#sourcesimplepushbutton)
    - [SourceSimpleResistor](#sourcesimpleresistor)
    - [SourceSimpleResonator](#sourcesimpleresonator)
    - [SourceSimpleSwitch](#sourcesimpleswitch)
    - [SourceSimpleTestPoint](#sourcesimpletestpoint)
    - [SourceSimpleTransistor](#sourcesimpletransistor)
    - [SourceSimpleVoltageProbe](#sourcesimplevoltageprobe)
    - [SourceSimpleVoltageSource](#sourcesimplevoltagesource)
    - [SourceTrace](#sourcetrace)
    - [SourceTraceNotConnectedError](#sourcetracenotconnectederror)
    - [SourceUnnamedTraceWarning](#sourceunnamedtracewarning)
    - [UnknownErrorFindingPart](#unknownerrorfindingpart)
  - [CAD Components](#cad-components)
    - [CadCollisionError](#cadcollisionerror)
    - [CadComponent](#cadcomponent)
  - [PCB Elements](#pcb-elements)
    - [PcbAutoroutingError](#pcbautoroutingerror)
    - [PcbBend](#pcbbend)
    - [PcbBoard](#pcbboard)
    - [PcbBreakoutPoint](#pcbbreakoutpoint)
    - [PcbBusLengthSkewError](#pcbbuslengthskewerror)
    - [PcbComponent](#pcbcomponent)
    - [PcbComponentInvalidLayerError](#pcbcomponentinvalidlayererror)
    - [PcbComponentMissingCourtyardWarning](#pcbcomponentmissingcourtyardwarning)
    - [PcbComponentNotOnBoardEdgeError](#pcbcomponentnotonboardedgeerror)
    - [PcbComponentOutsideBoardError](#pcbcomponentoutsideboarderror)
    - [PcbConnectorNotInAccessibleOrientationWarning](#pcbconnectornotinaccessibleorientationwarning)
    - [PcbCopperPour](#pcbcopperpour)
    - [PcbCopperText](#pcbcoppertext)
    - [PcbCourtyardCircle](#pcbcourtyardcircle)
    - [PcbCourtyardOutline](#pcbcourtyardoutline)
    - [PcbCourtyardOverlapError](#pcbcourtyardoverlaperror)
    - [PcbCourtyardPill](#pcbcourtyardpill)
    - [PcbCourtyardPolygon](#pcbcourtyardpolygon)
    - [PcbCourtyardRect](#pcbcourtyardrect)
    - [PcbCutout](#pcbcutout)
    - [PcbDebugObject](#pcbdebugobject)
    - [PcbFabricationNoteDimension](#pcbfabricationnotedimension)
    - [PcbFabricationNotePath](#pcbfabricationnotepath)
    - [PcbFabricationNoteRect](#pcbfabricationnoterect)
    - [PcbFabricationNoteText](#pcbfabricationnotetext)
    - [PcbFabricatorExtraChargeWarning](#pcbfabricatorextrachargewarning)
    - [PcbFootprintOverlapError](#pcbfootprintoverlaperror)
    - [PcbGroundPlane](#pcbgroundplane)
    - [PcbGroundPlaneRegion](#pcbgroundplaneregion)
    - [PcbGroup](#pcbgroup)
    - [PcbHole](#pcbhole)
    - [PcbKeepout](#pcbkeepout)
    - [PcbKeepoutOverlapWarning](#pcbkeepoutoverlapwarning)
    - [PcbManualEditConflictWarning](#pcbmanualeditconflictwarning)
    - [PcbMissingFootprintError](#pcbmissingfootprinterror)
    - [PcbNet](#pcbnet)
    - [PcbNoteDimension](#pcbnotedimension)
    - [PcbNoteLine](#pcbnoteline)
    - [PcbNotePath](#pcbnotepath)
    - [PcbNoteRect](#pcbnoterect)
    - [PcbNoteText](#pcbnotetext)
    - [PcbPackingError](#pcbpackingerror)
    - [PcbPadPadClearanceError](#pcbpadpadclearanceerror)
    - [PcbPadTraceClearanceError](#pcbpadtraceclearanceerror)
    - [PcbPanel](#pcbpanel)
    - [PcbPanelizationPlacementError](#pcbpanelizationplacementerror)
    - [PcbPin1Location](#pcbpin1location)
    - [PcbPlacementError](#pcbplacementerror)
    - [PcbPlatedHole](#pcbplatedhole)
    - [PcbPort](#pcbport)
    - [PcbPortNotConnectedError](#pcbportnotconnectederror)
    - [PcbPortNotMatchedError](#pcbportnotmatchederror)
    - [PcbPreflightRoutingError](#pcbpreflightroutingerror)
    - [PcbRouteHints](#pcbroutehints)
    - [PcbSilkscreenCircle](#pcbsilkscreencircle)
    - [PcbSilkscreenGraphic](#pcbsilkscreengraphic)
    - [PcbSilkscreenLine](#pcbsilkscreenline)
    - [PcbSilkscreenOval](#pcbsilkscreenoval)
    - [PcbSilkscreenPath](#pcbsilkscreenpath)
    - [PcbSilkscreenPill](#pcbsilkscreenpill)
    - [PcbSilkscreenRect](#pcbsilkscreenrect)
    - [PcbSilkscreenText](#pcbsilkscreentext)
    - [PcbSolderPaste](#pcbsolderpaste)
    - [PcbStiffener](#pcbstiffener)
    - [PcbText](#pcbtext)
    - [PcbThermalSpoke](#pcbthermalspoke)
    - [PcbTrace](#pcbtrace)
    - [PcbTraceError](#pcbtraceerror)
    - [PcbTraceHint](#pcbtracehint)
    - [PcbTraceMissingError](#pcbtracemissingerror)
    - [PcbTraceTooLongError](#pcbtracetoolongerror)
    - [PcbTraceTooLongWarning](#pcbtracetoolongwarning)
    - [PcbTraceTooManyViasWarning](#pcbtracetoomanyviaswarning)
    - [PcbTraceWarning](#pcbtracewarning)
    - [PcbVia](#pcbvia)
    - [PcbViaClearanceError](#pcbviaclearanceerror)
    - [PcbViaTraceClearanceError](#pcbviatraceclearanceerror)
  - [Schematic Elements](#schematic-elements)
    - [SchematicArc](#schematicarc)
    - [SchematicBox](#schematicbox)
    - [SchematicCircle](#schematiccircle)
    - [SchematicComponent](#schematiccomponent)
    - [SchematicComponentOverlapWarning](#schematiccomponentoverlapwarning)
    - [SchematicComponentStylingWarning](#schematiccomponentstylingwarning)
    - [SchematicDebugObject](#schematicdebugobject)
    - [SchematicElementOutsideSheetWarning](#schematicelementoutsidesheetwarning)
    - [SchematicError](#schematicerror)
    - [SchematicGraphic](#schematicgraphic)
    - [SchematicGroup](#schematicgroup)
    - [SchematicLayoutError](#schematiclayouterror)
    - [SchematicLine](#schematicline)
    - [SchematicManualEditConflictWarning](#schematicmanualeditconflictwarning)
    - [SchematicMissingSheetWarning](#schematicmissingsheetwarning)
    - [SchematicNetLabel](#schematicnetlabel)
    - [SchematicPath](#schematicpath)
    - [SchematicPort](#schematicport)
    - [SchematicRect](#schematicrect)
    - [SchematicSheet](#schematicsheet)
    - [SchematicSymbol](#schematicsymbol)
    - [SchematicTable](#schematictable)
    - [SchematicTableCell](#schematictablecell)
    - [SchematicText](#schematictext)
    - [SchematicTextPart](#schematictextpart)
    - [SchematicTrace](#schematictrace)
    - [SchematicVoltageProbe](#schematicvoltageprobe)
  - [Simulation Elements](#simulation-elements)
    - [SimulationAcSweepCurrentGraph](#simulationacsweepcurrentgraph)
    - [SimulationAcSweepVoltageGraph](#simulationacsweepvoltagegraph)
    - [SimulationAnalysisResult](#simulationanalysisresult)
    - [SimulationComplexSample](#simulationcomplexsample)
    - [SimulationCurrentProbe](#simulationcurrentprobe)
    - [SimulationCurrentSource](#simulationcurrentsource)
    - [SimulationDcOperatingPointCurrent](#simulationdcoperatingpointcurrent)
    - [SimulationDcOperatingPointVoltage](#simulationdcoperatingpointvoltage)
    - [SimulationDcSweepCurrentGraph](#simulationdcsweepcurrentgraph)
    - [SimulationDcSweepVoltageGraph](#simulationdcsweepvoltagegraph)
    - [SimulationExperiment](#simulationexperiment)
    - [SimulationOpAmp](#simulationopamp)
    - [SimulationOscilloscopeTrace](#simulationoscilloscopetrace)
    - [SimulationParameterSweep](#simulationparametersweep)
    - [SimulationParameterSweepCoordinate](#simulationparametersweepcoordinate)
    - [SimulationSpiceSubcircuit](#simulationspicesubcircuit)
    - [SimulationSwitch](#simulationswitch)
    - [SimulationTransientCurrentGraph](#simulationtransientcurrentgraph)
    - [SimulationTransientVoltageGraph](#simulationtransientvoltagegraph)
    - [SimulationUnknownExperimentError](#simulationunknownexperimenterror)
    - [SimulationVoltageProbe](#simulationvoltageprobe)
    - [SimulationVoltageSource](#simulationvoltagesource)

<!-- toc:end -->

## Typescript Usage

```ts
import { any_circuit_element, simple_source_resistor } from "circuit-json"
import type { SourceSimpleResistor } from "circuit-json"

const resistor: SourceSimpleResistor = simple_source_resistor.parse({
  type: "source_component",
  ftype: "simple_resistor",
  source_component_id: "source_component_1",
  name: "R1",
  resistane: "1k",
})

console.log(resistor.resistance) // 1000

// This is the common way to parse/transform any element
any_circuit_element.parse({
  /* ... */
})
```

## Base Units

When there is not a string unit provided, tscircuit assumes the a "base unit" is used.

You can specify circuit json with string units to avoid ambiguity around
units, for example by specifying `{ max_trace_length: "100mm" }` avoids needing to know
the base unit. However if a number is specified, it should be in the base units in the
table below. In this case `{ max_trace_length: 100 }` is equivalent.

The default units when reading a number are defined as follows:

| Measurement Type | Base Unit | Description        |
| ---------------- | --------- | ------------------ |
| Length           | mm        | Millimeters        |
| Duration         | ms        | Milliseconds       |
| Timestamp        | string    | ISO 8601 Timestamp |
| Mass             | g         | Grams              |
| Angle            | deg       | Degrees            |
| Frequency        | Hz        | Hertz              |
| Volume           | ml        | Milliliters        |
| Voltage          | V         | Volts              |
| Current          | A         | Amperes            |
| Resistance       | Ω         | Ohms               |
| Capacitance      | F         | Farads             |
| Inductance       | H         | Henries            |

## Element Prefixes

Element prefixes are used to separate data that's used in different contexts. This allows
developers who use Circuit JSON to develop partial implementations with smaller targets in mind.
It can also help simplify JSON elements because schematic and pcb information is not contained
in the same object.

A single `<resistor />` (in tscircuit) will have a corresponding `source_component`, `schematic_component` and `pcb_component`, as well as other elements that may be necessary
to represent it.

There are 3 main element prefixes:

- `source_` - e.g. `source_component` An element that contains information from whatever originally defined the entity. You can think of this as a non-target representations.
  - For example, you might have `supplier_part_numbers` as a property here, since that is
    not strictly related to the `pcb` or the `schematic`.
  - This category sometimes contains information that is relevant to both the `pcb` and the `schematic`
  - This is a somewhat a "Miscellaneous" category, because it contains things from the source
    definition that we wouldn't want to lose.
- `pcb_` - e.g. `pcb_component`, `pcb_port`. Anything required to render the PCB
- `schematic_` - e.g. `schematic_component`. Anything required to render the Schematic

<!-- circuit-json-docs:start -->

## Source Components

### SourceAmbiguousPortReference

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_ambiguous_port_reference.ts)

```typescript
/** Error emitted when a port hint matches multiple non-overlapping pads,
 * making the port reference ambiguous (e.g. multiple pads all named "SH" */
interface SourceAmbiguousPortReference extends BaseCircuitJsonError {
  type: "source_ambiguous_port_reference"
  source_ambiguous_port_reference_id: string
  error_type: "source_ambiguous_port_reference"
  source_port_id?: string
  source_component_id?: string
}
```

### SourceBoard

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_board.ts)

Defines a board in the source domain

```typescript
/** Defines a board in the source domain */
interface SourceBoard {
  type: "source_board"
  source_board_id: string
  source_group_id: string
  title?: string
}
```

### SourceBus

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_bus.ts)

A group of resolved source traces with a maximum routed-length difference.

```typescript
/** A group of resolved source traces with a maximum routed-length difference. */
interface SourceBus {
  type: "source_bus"
  source_bus_id: string
  name?: string
  source_trace_ids: string[]
  /** Maximum difference between the longest and shortest member, in millimeters. */
  max_length_skew?: number
  subcircuit_id?: string
}
```

### SourceComponentBase

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/base/source_component_base.ts)

```typescript
interface SourceComponentBase {
  type: "source_component"
  ftype?: string
  source_component_id: string
  name: string
  manufacturer_part_number?: string
  supplier_part_numbers?: Partial<Record<SupplierName, string[]>>
  display_value?: string
  display_name?: string
  are_pins_interchangeable?: boolean
  internally_connected_source_port_ids?: string[][]
  source_group_id?: string
  subcircuit_id?: string
}
```

### SourceComponentInternalConnection

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_component_internal_connection.ts)

```typescript
interface SourceComponentInternalConnection {
  type: "source_component_internal_connection"
  source_component_internal_connection_id: string
  source_component_id: string
  source_port_ids: string[]
  subcircuit_id?: string
}
```

### SourceComponentMisconfiguredError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_component_misconfigured_error.ts)

Error emitted when one or more source components have an invalid or conflicting configuration

```typescript
/** Error emitted when one or more source components have an invalid or conflicting configuration */
interface SourceComponentMisconfiguredError extends BaseCircuitJsonError {
  type: "source_component_misconfigured_error"
  source_component_misconfigured_error_id: string
  error_type: "source_component_misconfigured_error"
  source_component_ids: string[]
  source_port_ids?: string[]
}
```

### SourceComponentPinsUnderspecifiedWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_component_pins_underspecified_warning.ts)

Warning emitted when all ports on a source component are underspecified

```typescript
/** Warning emitted when all ports on a source component are underspecified */
interface SourceComponentPinsUnderspecifiedWarning {
  type: "source_component_pins_underspecified_warning"
  source_component_pins_underspecified_warning_id: string
  warning_type: "source_component_pins_underspecified_warning"
  message: string
  source_component_id: string
  source_port_ids: string[]
  subcircuit_id?: string
}
```

### SourceConfusingNetNameWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_confusing_net_name_warning.ts)

Warning emitted when electrically disconnected source nets share a name

```typescript
/** Warning emitted when electrically disconnected source nets share a name */
interface SourceConfusingNetNameWarning {
  type: "source_confusing_net_name_warning"
  source_confusing_net_name_warning_id: string
  warning_type: "source_confusing_net_name_warning"
  message: string
  source_net_ids: string[]
  net_name: string
  subcircuit_id?: string
}
```

### SourceFailedToCreateComponentError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_failed_to_create_component_error.ts)

```typescript
/** Error emitted when a component fails to be constructed.
 * Contains details about the failure and prevents the component from being rendered. */
interface SourceFailedToCreateComponentError extends BaseCircuitJsonError {
  type: "source_failed_to_create_component_error"
  source_failed_to_create_component_error_id: string
  error_type: "source_failed_to_create_component_error"
  component_name?: string
  subcircuit_id?: string
  parent_source_component_id?: string
  pcb_center?: {
    x?: number
    y?: number
  }
  schematic_center?: {
    x?: number
    y?: number
  }
}
```

### SourceGroup

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_group.ts)

```typescript
interface SourceGroup {
  type: "source_group"
  source_group_id: string
  subcircuit_id?: string
  parent_subcircuit_id?: string
  parent_source_group_id?: string
  is_subcircuit?: boolean
  show_as_schematic_box?: boolean
  name?: string
  was_automatically_named?: boolean
}
```

### SourceI2cMisconfiguredError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_i2c_misconfigured_error.ts)

Error emitted when incompatible I2C pins (e.g. SDA and SCL) are connected to the same net

```typescript
/** Error emitted when incompatible I2C pins (e.g. SDA and SCL) are connected to the same net */
interface SourceI2cMisconfiguredError extends BaseCircuitJsonError {
  type: "source_i2c_misconfigured_error"
  source_i2c_misconfigured_error_id: string
  error_type: "source_i2c_misconfigured_error"
  source_port_ids: string[]
}
```

### SourceInterconnect

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_interconnect.ts)

Defines a generic interconnect component

```typescript
/** Defines a generic interconnect component */
interface SourceInterconnect extends SourceComponentBase {
  ftype: "interconnect"
}
```

### SourceInvalidComponentPropertyError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_invalid_component_property_error.ts)

The source component property is invalid

```typescript
/** The source component property is invalid */
interface SourceInvalidComponentPropertyError extends BaseCircuitJsonError {
  type: "source_invalid_component_property_error"
  source_invalid_component_property_error_id: string
  source_component_id: string
  property_name: string
  property_value?: unknown
  expected_format?: string
  subcircuit_id?: string
  error_type: "source_invalid_component_property_error"
}
```

### SourceManuallyPlacedVia

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_manually_placed_via.ts)

Defines a via that is manually placed in the source domain

```typescript
/** Defines a via that is manually placed in the source domain */
interface SourceManuallyPlacedVia {
  type: "source_manually_placed_via"
  source_manually_placed_via_id: string
  source_group_id: string
  source_net_id?: string
  subcircuit_id?: string
  source_trace_id?: string
}
```

### SourceMissingManufacturerPartNumberWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_missing_manufacturer_part_number_warning.ts)

Warning emitted when a standard connector is missing manufacturer part number

```typescript
/** Warning emitted when a standard connector is missing manufacturer part number */
interface SourceMissingManufacturerPartNumberWarning {
  type: "source_missing_manufacturer_part_number_warning"
  source_missing_manufacturer_part_number_warning_id: string
  warning_type: "source_missing_manufacturer_part_number_warning"
  message: string
  source_component_id: string
  standard: string
  subcircuit_id?: string
}
```

### SourceMissingPropertyError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_missing_property_error.ts)

The source code is missing a property

```typescript
/** The source code is missing a property */
interface SourceMissingPropertyError extends BaseCircuitJsonError {
  type: "source_missing_property_error"
  source_missing_property_error_id: string
  source_component_id: string
  property_name: string
  subcircuit_id?: string
  error_type: "source_missing_property_error"
}
```

### SourceNet

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_net.ts)

```typescript
interface SourceNet {
  type: "source_net"
  source_net_id: string
  name: string
  member_source_group_ids: string[]
  is_power?: boolean
  is_ground?: boolean
  is_digital_signal?: boolean
  is_analog_signal?: boolean
  is_positive_voltage_source?: boolean
  trace_width?: number
  subcircuit_id?: string
  subcircuit_connectivity_map_key?: string
}
```

### SourceNoGroundPinDefinedWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_no_ground_pin_defined_warning.ts)

Warning emitted when a chip has no source ports marked as ground pins

```typescript
/** Warning emitted when a chip has no source ports marked as ground pins */
interface SourceNoGroundPinDefinedWarning {
  type: "source_no_ground_pin_defined_warning"
  source_no_ground_pin_defined_warning_id: string
  warning_type: "source_no_ground_pin_defined_warning"
  message: string
  source_component_id: string
  source_port_ids: string[]
  subcircuit_id?: string
}
```

### SourceNoPowerPinDefinedWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_no_power_pin_defined_warning.ts)

Warning emitted when a chip has no source ports with requires_power=true

```typescript
/** Warning emitted when a chip has no source ports with requires_power=true */
interface SourceNoPowerPinDefinedWarning {
  type: "source_no_power_pin_defined_warning"
  source_no_power_pin_defined_warning_id: string
  warning_type: "source_no_power_pin_defined_warning"
  message: string
  source_component_id: string
  source_port_ids: string[]
  subcircuit_id?: string
}
```

### SourcePartNotFoundWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_part_not_found_warning.ts)

Warning emitted when a requested part can not be found

```typescript
/** Warning emitted when a requested part can not be found */
interface SourcePartNotFoundWarning {
  type: "source_part_not_found_warning"
  source_part_not_found_warning_id: string
  warning_type: "source_part_not_found_warning"
  message: string
  source_component_id?: string
  subcircuit_id?: string
  supplier_name?: SupplierName
  manufacturer_part_number?: string
  supplier_part_number?: string
  part_name?: string
}
```

### SourcePcbGroundPlane

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_pcb_ground_plane.ts)

Defines a ground plane in the source domain

```typescript
/** Defines a ground plane in the source domain */
interface SourcePcbGroundPlane {
  type: "source_pcb_ground_plane"
  source_pcb_ground_plane_id: string
  source_group_id: string
  source_net_id: string
  subcircuit_id?: string
}
```

### SourcePinAttributes

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/properties/source_pin_attributes.ts)

```typescript
interface SourcePinAttributes {
  is_input?: boolean
  is_output?: boolean
  is_bidirectional?: boolean
  is_passive?: boolean
  can_use_tri_state?: boolean
  is_using_tri_state?: boolean
  can_use_open_collector?: boolean
  is_using_open_collector?: boolean
  can_use_open_emitter?: boolean
  is_using_open_emitter?: boolean
  is_gpio?: boolean
  highlight_color?: string
  must_be_connected?: boolean
  provides_power?: boolean
  requires_power?: boolean
  provides_ground?: boolean
  requires_ground?: boolean
  provides_voltage?: string | number
  requires_voltage?: string | number
  do_not_connect?: boolean
  include_in_board_pinout?: boolean
  can_use_internal_pullup?: boolean
  is_using_internal_pullup?: boolean
  needs_external_pullup?: boolean
  can_use_internal_pulldown?: boolean
  is_using_internal_pulldown?: boolean
  needs_external_pulldown?: boolean
  can_use_open_drain?: boolean
  is_using_open_drain?: boolean
  can_use_push_pull?: boolean
  is_using_push_pull?: boolean
  should_have_decoupling_capacitor?: boolean
  recommended_decoupling_capacitor_capacitance?: string | number
  is_configured_for_i2c_sda?: boolean
  is_configured_for_i2c_scl?: boolean
  is_configured_for_spi_mosi?: boolean
  is_configured_for_spi_miso?: boolean
  is_configured_for_spi_sck?: boolean
  is_configured_for_spi_cs?: boolean
  is_configured_for_uart_tx?: boolean
  is_configured_for_uart_rx?: boolean
  supports_i2c_sda?: boolean
  supports_i2c_scl?: boolean
  supports_spi_mosi?: boolean
  supports_spi_miso?: boolean
  supports_spi_sck?: boolean
  supports_spi_cs?: boolean
  supports_uart_tx?: boolean
  supports_uart_rx?: boolean
}
```

### SourcePinMissingTraceWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_pin_missing_trace_warning.ts)

Warning emitted when a source component pin is missing a trace connection

```typescript
/** Warning emitted when a source component pin is missing a trace connection */
interface SourcePinMissingTraceWarning {
  type: "source_pin_missing_trace_warning"
  source_pin_missing_trace_warning_id: string
  warning_type: "source_pin_missing_trace_warning"
  message: string
  source_component_id: string
  source_port_id: string
  subcircuit_id?: string
}
```

### SourcePinMustBeConnectedError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_pin_must_be_connected_error.ts)

Error emitted when a pin with mustBeConnected attribute is not connected to any trace

```typescript
/** Error emitted when a pin with mustBeConnected attribute is not connected to any trace */
interface SourcePinMustBeConnectedError extends BaseCircuitJsonError {
  type: "source_pin_must_be_connected_error"
  source_pin_must_be_connected_error_id: string
  error_type: "source_pin_must_be_connected_error"
  source_component_id: string
  source_port_id: string
  subcircuit_id?: string
}
```

### SourcePort

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_port.ts)

Defines a source port that can be connected to other components

```typescript
/** Defines a source port that can be connected to other components */
interface SourcePort extends SourcePinAttributes {
  type: "source_port"
  pin_number?: number
  port_hints?: string[]
  name: string
  source_port_id: string
  source_component_id?: string
  source_group_id?: string
  most_frequently_referenced_by_name?: string
  subcircuit_id?: string
  subcircuit_connectivity_map_key?: string
}
```

### SourceProjectMetadata

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_project_metadata.ts)

```typescript
interface SourceProjectMetadata {
  type: "source_project_metadata"
  name?: string
  software_used_string?: string
  project_url?: string
  source_filesystem_md5_hash?: string
  created_at?: string // ISO8601 timestamp
}
```

### SourcePropertyIgnoredWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_property_ignored_warning.ts)

The source property was ignored

```typescript
/** The source property was ignored */
interface SourcePropertyIgnoredWarning {
  type: "source_property_ignored_warning"
  source_property_ignored_warning_id: string
  source_component_id: string
  property_name: string
  subcircuit_id?: string
  error_type: "source_property_ignored_warning"
  message: string
}
```

### SourceRefdesConventionWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_refdes_convention_warning.ts)

Warning emitted when a source component reference designator does not match the component type convention

```typescript
/** Warning emitted when a source component reference designator does not match the component type convention */
interface SourceRefdesConventionWarning {
  type: "source_refdes_convention_warning"
  source_refdes_convention_warning_id: string
  warning_type: "source_refdes_convention_warning"
  message: string
  source_component_id: string
  refdes: string
  source_component_ftype: string
  expected_prefixes: string[]
  actual_prefix?: string
  subcircuit_id?: string
}
```

### SourceRuntimeError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_runtime_error.ts)

```typescript
interface SourceRuntimeError
  extends Pick<BaseCircuitJsonError, "message" | "error_type"> {
  type: "source_runtime_error"
  source_runtime_error_id: string
  error_type: "source_runtime_error"
  phase_name?: string
}
```

### SourceSimpleAmmeter

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_ammeter.ts)

Defines a simple ammeter component for simulation and measurement

```typescript
/** Defines a simple ammeter component for simulation and measurement */
interface SourceSimpleAmmeter extends SourceComponentBase {
  ftype: "simple_ammeter"
}
```

### SourceSimpleBattery

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_battery.ts)

Defines a simple battery component

```typescript
/** Defines a simple battery component */
interface SourceSimpleBattery extends SourceComponentBase {
  ftype: "simple_battery"
  capacity: number
}
```

### SourceSimpleCapacitor

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_capacitor.ts)

Defines a simple capacitor component

```typescript
/** Defines a simple capacitor component */
interface SourceSimpleCapacitor extends SourceComponentBase {
  ftype: "simple_capacitor"
  capacitance: number
  max_voltage_rating?: number
  display_capacitance?: string
  max_decoupling_trace_length?: number
}
```

### SourceSimpleChip

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_chip.ts)

Defines a simple integrated circuit component

```typescript
/** Defines a simple integrated circuit component */
interface SourceSimpleChip extends SourceComponentBase {
  ftype: "simple_chip"
}
```

### SourceSimpleConnector

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_connector.ts)

Defines a simple connector component

```typescript
/** Defines a simple connector component */
interface SourceSimpleConnector extends SourceComponentBase {
  ftype: "simple_connector"
  /** Connector interface or product family, such as usb_c, m2, or jst_ph */
  standard?: SourceSimpleConnectorStandard
  /** Number of electrical circuits in the connector */
  pin_count?: number
}

type SourceSimpleConnectorStandard =
  (typeof source_simple_connector_standards)[number]
```

### SourceSimpleCrystal

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_crystal.ts)

Defines a simple crystal oscillator component

```typescript
/** Defines a simple crystal oscillator component */
interface SourceSimpleCrystal extends SourceComponentBase {
  ftype: "simple_crystal"
  frequency: number
  load_capacitance?: number
  pin_variant?: "two_pin" | "four_pin"
}
```

### SourceSimpleCurrentSource

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_current_source.ts)

Defines a simple current source component

```typescript
/** Defines a simple current source component */
interface SourceSimpleCurrentSource extends SourceComponentBase {
  ftype: "simple_current_source"
  current: number
  frequency?: number
  peak_to_peak_current?: number
  wave_shape: "sine" | "square" | "triangle" | "sawtooth" | "dc"
  phase?: number
  duty_cycle?: number
}
```

### SourceSimpleDiode

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_diode.ts)

Defines a simple diode component

```typescript
/** Defines a simple diode component */
interface SourceSimpleDiode extends SourceComponentBase {
  ftype: "simple_diode"
}
```

### SourceSimpleFiducial

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_fiducial.ts)

Defines a simple fiducial component

```typescript
/** Defines a simple fiducial component */
interface SourceSimpleFiducial extends SourceComponentBase {
  ftype: "simple_fiducial"
}
```

### SourceSimpleFuse

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_fuse.ts)

```typescript
interface SourceSimpleFuse extends SourceComponentBase {
  ftype: "simple_fuse"
  current_rating_amps: number
  voltage_rating_volts: number
}
```

### SourceSimpleGround

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_ground.ts)

Defines a simple ground component

```typescript
/** Defines a simple ground component */
interface SourceSimpleGround extends SourceComponentBase {
  ftype: "simple_ground"
}
```

### SourceSimpleInductor

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_inductor.ts)

Defines a simple inductor component

```typescript
/** Defines a simple inductor component */
interface SourceSimpleInductor extends SourceComponentBase {
  ftype: "simple_inductor"
  inductance: number
  display_inductance?: string
  max_current_rating?: number
}
```

### SourceSimpleLed

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_led.ts)

Defines a simple led component

```typescript
/** Defines a simple led component */
interface SourceSimpleLed extends Omit<SourceSimpleDiode, "ftype"> {
  ftype: "simple_led"
  color?: string
  wavelength?: string
}
```

### SourceSimpleMosfet

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_mosfet.ts)

```typescript
/** Defines a simple mosfet component
 * This is a three-pin semiconductor device (source, gate, drain)
 * Pin configuration is handled by the schematic port system */
interface SourceSimpleMosfet extends SourceComponentBase {
  ftype: "simple_mosfet"
  channel_type: "n" | "p"
  mosfet_mode: "enhancement" | "depletion"
}
```

### SourceSimpleOpAmp

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_op_amp.ts)

Defines a simple op-amp component

```typescript
/** Defines a simple op-amp component */
interface SourceSimpleOpAmp extends SourceComponentBase {
  ftype: "simple_op_amp"
}
```

### SourceSimplePinHeader

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_pin_header.ts)

```typescript
interface SourceSimplePinHeader extends SourceComponentBase {
  ftype: "simple_pin_header"
  pin_count: number
  gender: "male" | "female"
}
```

### SourceSimplePinout

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_pinout.ts)

Defines a simple pinout component

```typescript
/** Defines a simple pinout component */
interface SourceSimplePinout extends SourceComponentBase {
  ftype: "simple_pinout"
}
```

### SourceSimplePotentiometer

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_potentiometer.ts)

```typescript
interface SourceSimplePotentiometer extends SourceComponentBase {
  ftype: "simple_potentiometer"
  max_resistance: number
  display_max_resistance?: string
}
```

### SourceSimplePowerSource

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_power_source.ts)

Defines a simple power source component

```typescript
/** Defines a simple power source component */
interface SourceSimplePowerSource extends SourceComponentBase {
  ftype: "simple_power_source"
  voltage: number
}
```

### SourceSimplePushButton

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_push_button.ts)

Defines a simple push button component

```typescript
/** Defines a simple push button component */
interface SourceSimplePushButton extends SourceComponentBase {
  ftype: "simple_push_button"
}
```

### SourceSimpleResistor

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_resistor.ts)

Defines a simple resistor component

```typescript
/** Defines a simple resistor component */
interface SourceSimpleResistor extends SourceComponentBase {
  ftype: "simple_resistor"
  resistance: number
  display_resistance?: string
}
```

### SourceSimpleResonator

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_resonator.ts)

Defines a simple resonator component

```typescript
/** Defines a simple resonator component */
interface SourceSimpleResonator extends SourceComponentBase {
  ftype: "simple_resonator"
  load_capacitance: number
  equivalent_series_resistance?: number
  frequency: number
}
```

### SourceSimpleSwitch

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_switch.ts)

Defines a simple switch component

```typescript
/** Defines a simple switch component */
interface SourceSimpleSwitch extends SourceComponentBase {
  ftype: "simple_switch"
}
```

### SourceSimpleTestPoint

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_test_point.ts)

```typescript
/** Defines a simple test point component
 * Can be surface-mount or through-hole.
 * Pad shape and dimensions configurable for different use cases. */
interface SourceSimpleTestPoint extends SourceComponentBase {
  ftype: "simple_test_point"
  footprint_variant?: "pad" | "through_hole"
  pad_shape?: "rect" | "circle"
  pad_diameter?: number | string
  hole_diameter?: number | string
  width?: number | string
  height?: number | string
}
```

### SourceSimpleTransistor

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_transistor.ts)

```typescript
/** Defines a simple transistor component
 * This is a three-pin semiconductor device (emitter, base, collector)
 * Pin configuration is handled by the schematic port system */
interface SourceSimpleTransistor extends SourceComponentBase {
  ftype: "simple_transistor"
  transistor_type: "npn" | "pnp"
}
```

### SourceSimpleVoltageProbe

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_voltage_probe.ts)

Defines a simple voltage probe component for simulation and measurement

```typescript
/** Defines a simple voltage probe component for simulation and measurement */
interface SourceSimpleVoltageProbe extends SourceComponentBase {
  ftype: "simple_voltage_probe"
}
```

### SourceSimpleVoltageSource

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_simple_voltage_source.ts)

Defines a simple voltage source component

```typescript
/** Defines a simple voltage source component */
interface SourceSimpleVoltageSource extends SourceComponentBase {
  ftype: "simple_voltage_source"
  voltage: number
  frequency?: number
  peak_to_peak_voltage?: number
  wave_shape?: "sinewave" | "square" | "triangle" | "sawtooth"
  phase?: number
  duty_cycle?: number
  pulse_delay?: number // ms
  rise_time?: number // ms
  fall_time?: number // ms
  pulse_width?: number // ms
  period?: number // ms
}
```

### SourceTrace

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_trace.ts)

```typescript
interface SourceTrace {
  type: "source_trace"
  source_trace_id: string
  connected_source_port_ids: string[]
  connected_source_net_ids: string[]
  subcircuit_id?: string
  subcircuit_connectivity_map_key?: string
  max_length?: number
  max_via_count?: number
  name?: string
  display_name?: string
  min_trace_thickness?: number
}
```

### SourceTraceNotConnectedError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_trace_not_connected_error.ts)

Occurs when a source trace selector does not match any ports

```typescript
/** Occurs when a source trace selector does not match any ports */
interface SourceTraceNotConnectedError extends BaseCircuitJsonError {
  type: "source_trace_not_connected_error"
  source_trace_not_connected_error_id: string
  error_type: "source_trace_not_connected_error"
  subcircuit_id?: string
  source_group_id?: string
  source_trace_id?: string
  connected_source_port_ids?: string[]
  selectors_not_found?: string[]
}
```

### SourceUnnamedTraceWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/source_unnamed_trace_warning.ts)

Warning emitted when a source trace is missing a name

```typescript
/** Warning emitted when a source trace is missing a name */
interface SourceUnnamedTraceWarning {
  type: "source_unnamed_trace_warning"
  source_unnamed_trace_warning_id: string
  warning_type: "source_unnamed_trace_warning"
  message: string
  source_trace_id: string
  subcircuit_id?: string
}
```

### UnknownErrorFindingPart

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/source/unknown_error_finding_part.ts)

```typescript
/** Error emitted when an unexpected error occurs while finding a part.
 * This includes cases where the API returns HTML instead of JSON,
 * network failures, or other unexpected responses. */
interface UnknownErrorFindingPart extends BaseCircuitJsonError {
  type: "unknown_error_finding_part"
  unknown_error_finding_part_id: string
  error_type: "unknown_error_finding_part"
  source_component_id?: string
  subcircuit_id?: string
}
```

## CAD Components

### CadCollisionError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/cad/cad_collision_error.ts)

Union silhouette of solid intersection, projected along face normal (mm²

```typescript
interface CadCollisionError extends BaseCircuitJsonError {
  type: "cad_collision_error"
  cad_collision_error_id: string
  error_type: "cad_collision_error"
  cad_component_ids: string[]
  pcb_component_ids?: string[]
  source_component_ids: string[]
  /** Union silhouette of solid intersection, projected along face normal (mm² */
  intersection_area_mm2: number
  threshold_area_mm2: number
}
```

### CadComponent

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/cad/cad_component.ts)

CAD geometry, optionally associated with a PCB component.

```typescript
/** CAD geometry, optionally associated with a PCB component. */
interface CadComponent {
  type: "cad_component"
  cad_component_id: string
  /** Omit for CAD geometry that has no corresponding PCB component. */
  pcb_component_id?: string
  source_component_id: string
  position: Point3
  rotation?: Point3
  /** True for assembled folded position/rotation; false or omitted for flat.
   * PCB records stay flat. pcb_component_id identifies the mount/owning board. */

  is_on_folded_board?: boolean
  size?: Point3
  layer?: LayerRef
  subcircuit_id?: string
  footprinter_string?: string
  model_obj_url?: string
  model_stl_url?: string
  model_3mf_url?: string
  model_gltf_url?: string
  model_glb_url?: string
  model_step_url?: string
  model_wrl_url?: string
  model_asset?: Asset
  model_unit_to_mm_scale_factor?: number
  model_board_normal_direction?: CadModelAxisDirection
  model_origin_position?: Point3
  model_origin_alignment?:
    | "unknown"
    | "center"
    | "center_of_component_on_board_surface"
    | "bottom_center_of_component"
  model_object_fit: "contain_within_bounds" | "fill_bounds"
  model_jscad?: any
  show_as_translucent_model?: boolean
  show_as_bounding_box?: boolean
  show_hidden_edges?: boolean
  anchor_alignment: CadComponentAnchorAlignment
}
```

## PCB Elements

### PcbAutoroutingError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_autorouting_error.ts)

```typescript
interface PcbAutoroutingErrorInterface extends BaseCircuitJsonError {
  type: "pcb_autorouting_error"
  pcb_error_id: string
  error_type: "pcb_autorouting_error"
  subcircuit_id?: string
}
```

### PcbBend

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_bend.ts)

Defines a bend without changing the flat PCB layout or stored CAD poses.

```typescript
/** Defines a bend without changing the flat PCB layout or stored CAD poses. */
interface PcbBend {
  type: "pcb_bend"
  pcb_bend_id: string
  pcb_board_id: string
  /** Ownership only; group transforms are already resolved into board coordinates. */
  pcb_group_id?: string
  subcircuit_id?: string
  name?: string
  /** Bend-zone centerline endpoints, relative to the flat board center, in mm. */
  start: Point
  end: Point
  /** Target angle in signed degrees; positive folds the moving side toward local top. Zero is flat. */
  bend_angle: Rotation
  /** Positive radius at the neutral surface, in mm. Zone width is radius times absolute angle in radians. */
  bend_radius: Length
  /** Moving side looking from start toward end in the flat top view. */
  bend_side: "left" | "right"
}
```

### PcbBoard

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_board.ts)

Defines the board outline of the PCB

```typescript
/** Defines the board outline of the PCB */
interface PcbBoard extends ManufacturingDrcProperties {
  type: "pcb_board"
  pcb_board_id: string
  pcb_panel_id?: string
  carrier_pcb_board_id?: string
  is_subcircuit?: boolean
  subcircuit_id?: string
  is_mounted_to_carrier_board?: boolean
  is_via_in_pad_allowed?: boolean
  default_via_tented_on_top?: boolean
  default_via_tented_on_bottom?: boolean
  default_via_plugged?: boolean
  width?: Length
  height?: Length
  display_offset_x?: string
  display_offset_y?: string
  thickness: Length
  num_layers: number
  /** Whether autorouters may generate blind and buried vias. */
  allow_blind_and_buried_vias?: boolean
  center: Point
  outline?: Point[]
  shape?: "rect" | "polygon"
  material: "fr4" | "fr1" | "flex"
  solder_mask_color?: string
  silkscreen_color?: string
  anchor_position?: Point
  anchor_alignment?: NinePointAnchor
  position_mode?: "relative_to_panel_anchor" | "none"
}
```

### PcbBreakoutPoint

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_breakout_point.ts)

Defines a routing target within a pcb_group for a source_trace or source_net

```typescript
/** Defines a routing target within a pcb_group for a source_trace or source_net */
interface PcbBreakoutPoint {
  type: "pcb_breakout_point"
  pcb_breakout_point_id: string
  pcb_group_id: string
  subcircuit_id?: string
  source_trace_id?: string
  source_port_id?: string
  source_net_id?: string
  layer?: LayerRef
  x: Distance
  y: Distance
}
```

### PcbBusLengthSkewError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_bus_length_skew_error.ts)

The routed lengths of a bus's members exceed its allowed skew.

```typescript
/** The routed lengths of a bus's members exceed its allowed skew. */
interface PcbBusLengthSkewError extends BaseCircuitJsonError {
  type: "pcb_bus_length_skew_error"
  pcb_bus_length_skew_error_id: string
  error_type: "pcb_bus_length_skew_error"
  source_bus_id: string
  source_trace_ids: string[]
  pcb_trace_ids: string[]
  actual_length_skew: number
  maximum_length_skew: number
  subcircuit_id?: string
}
```

### PcbComponent

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_component.ts)

```typescript
interface PcbComponentMetadata {
  kicad_footprint?: KicadFootprintMetadata
}

type SupplierPin1LocationMap = Partial<Record<SupplierName, PcbPin1Location>>
```

### PcbComponentInvalidLayerError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_component_invalid_layer_error.ts)

Error emitted when a component is placed on an invalid layer (components can only be on 'top' or 'bottom' layers)

```typescript
/** Error emitted when a component is placed on an invalid layer (components can only be on 'top' or 'bottom' layers) */
interface PcbComponentInvalidLayerError extends BaseCircuitJsonError {
  type: "pcb_component_invalid_layer_error"
  pcb_component_invalid_layer_error_id: string
  error_type: "pcb_component_invalid_layer_error"
  pcb_component_id?: string
  source_component_id: string
  layer: LayerRef
  subcircuit_id?: string
}
```

### PcbComponentMissingCourtyardWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_component_missing_courtyard_warning.ts)

Warning emitted when a PCB component has no courtyard geometry

```typescript
/** Warning emitted when a PCB component has no courtyard geometry */
interface PcbComponentMissingCourtyardWarning {
  type: "pcb_component_missing_courtyard_warning"
  pcb_component_missing_courtyard_warning_id: string
  warning_type: "pcb_component_missing_courtyard_warning"
  message: string
  pcb_component_id: string
  source_component_id?: string
  subcircuit_id?: string
}
```

### PcbComponentNotOnBoardEdgeError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_component_not_on_board_edge_error.ts)

Error emitted when a component that must be placed on the board edge is centered away from the edge

```typescript
/** Error emitted when a component that must be placed on the board edge is centered away from the edge */
interface PcbComponentNotOnBoardEdgeError extends BaseCircuitJsonError {
  type: "pcb_component_not_on_board_edge_error"
  pcb_component_not_on_board_edge_error_id: string
  error_type: "pcb_component_not_on_board_edge_error"
  pcb_component_id: string
  pcb_board_id: string
  component_center: Point
  pad_to_nearest_board_edge_distance: number
  source_component_id?: string
  subcircuit_id?: string
}
```

### PcbComponentOutsideBoardError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_component_outside_board_error.ts)

Error emitted when a PCB component is placed outside the board boundaries

```typescript
/** Error emitted when a PCB component is placed outside the board boundaries */
interface PcbComponentOutsideBoardError extends BaseCircuitJsonError {
  type: "pcb_component_outside_board_error"
  pcb_component_outside_board_error_id: string
  error_type: "pcb_component_outside_board_error"
  pcb_component_id: string
  pcb_board_id: string
  component_center: Point
  component_bounds: {
    min_x: number
    max_x: number
    min_y: number
    max_y: number
  }
  subcircuit_id?: string
  source_component_id?: string
}
```

### PcbConnectorNotInAccessibleOrientationWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_connector_not_in_accessible_orientation_warning.ts)

Warning emitted when a connector PCB component is facing inward toward the board and should be reoriented

```typescript
/** Warning emitted when a connector PCB component is facing inward toward the board and should be reoriented */
interface PcbConnectorNotInAccessibleOrientationWarning {
  type: "pcb_connector_not_in_accessible_orientation_warning"
  pcb_connector_not_in_accessible_orientation_warning_id: string
  warning_type: "pcb_connector_not_in_accessible_orientation_warning"
  message: string
  pcb_component_id: string
  source_component_id?: string
  pcb_board_id?: string
  facing_direction: ConnectorOrientationDirection
  recommended_facing_direction: ConnectorOrientationDirection
  subcircuit_id?: string
}
```

### PcbCopperPour

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_copper_pour.ts)

Defines a rectangular copper pour on the PCB.

```typescript
/** Defines a rectangular copper pour on the PCB. */
interface PcbCopperPourRect {
  type: "pcb_copper_pour"
  pcb_copper_pour_id: string
  covered_with_solder_mask: boolean
  pcb_group_id?: string
  subcircuit_id?: string
  layer: LayerRef
  source_net_id?: string
  shape: "rect"
  center: Point
  width: Length
  height: Length
  rotation?: Rotation
}
```

### PcbCopperText

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_copper_text.ts)

Defines copper text on the PCB

```typescript
/** Defines copper text on the PCB */
interface PcbCopperText {
  type: "pcb_copper_text"
  pcb_copper_text_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  font: "tscircuit2024"
  font_size: Length
  pcb_component_id: string
  text: string
  is_knockout?: boolean
  knockout_padding?: {
    left: Length
    top: Length
    bottom: Length
    right: Length
  }
  ccw_rotation?: number
  layer: LayerRef
  is_mirrored?: boolean
  anchor_position: Point
  anchor_alignment: NinePointAnchor
}
```

### PcbCourtyardCircle

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_courtyard_circle.ts)

Defines a courtyard circle on the PCB

```typescript
/** Defines a courtyard circle on the PCB */
interface PcbCourtyardCircle {
  type: "pcb_courtyard_circle"
  pcb_courtyard_circle_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  radius: Length
  layer: VisibleLayer
  color?: string
}
```

### PcbCourtyardOutline

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_courtyard_outline.ts)

Defines a courtyard outline on the PCB

```typescript
/** Defines a courtyard outline on the PCB */
interface PcbCourtyardOutline {
  type: "pcb_courtyard_outline"
  pcb_courtyard_outline_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  layer: VisibleLayer
  outline: Point[]
}
```

### PcbCourtyardOverlapError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_courtyard_overlap_error.ts)

Error emitted when the courtyard (CrtYd) of one PCB component overlaps with the courtyard of another

```typescript
/** Error emitted when the courtyard (CrtYd) of one PCB component overlaps with the courtyard of another */
interface PcbCourtyardOverlapError extends BaseCircuitJsonError {
  type: "pcb_courtyard_overlap_error"
  pcb_error_id: string
  error_type: "pcb_courtyard_overlap_error"
  pcb_component_ids: [string, string]
}
```

### PcbCourtyardPill

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_courtyard_pill.ts)

Defines a courtyard pill on the PCB

```typescript
/** Defines a courtyard pill on the PCB */
interface PcbCourtyardPill {
  type: "pcb_courtyard_pill"
  pcb_courtyard_pill_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  width: Length
  height: Length
  radius: Length
  layer: VisibleLayer
  color?: string
}
```

### PcbCourtyardPolygon

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_courtyard_polygon.ts)

Defines a courtyard polygon on the PCB

```typescript
/** Defines a courtyard polygon on the PCB */
interface PcbCourtyardPolygon {
  type: "pcb_courtyard_polygon"
  pcb_courtyard_polygon_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  layer: VisibleLayer
  points: Point[]
  color?: string
}
```

### PcbCourtyardRect

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_courtyard_rect.ts)

Defines a courtyard rectangle on the PCB

```typescript
/** Defines a courtyard rectangle on the PCB */
interface PcbCourtyardRect {
  type: "pcb_courtyard_rect"
  pcb_courtyard_rect_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  width: Length
  height: Length
  layer: VisibleLayer
  ccw_rotation?: Rotation
  color?: string
}
```

### PcbCutout

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_cutout.ts)

Defines a rectangular cutout on the PCB.

```typescript
/** Defines a rectangular cutout on the PCB. */
interface PcbCutoutRect {
  type: "pcb_cutout"
  pcb_cutout_id: string
  pcb_component_id?: string
  pcb_group_id?: string
  subcircuit_id?: string
  pcb_board_id?: string
  pcb_panel_id?: string
  shape: "rect"
  center: Point
  width: Length
  height: Length
  rotation?: Rotation
  corner_radius?: Length
}
```

### PcbDebugObject

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_debug_object.ts)

```typescript
type PcbDebugObject = PcbDebugRect | PcbDebugLine | PcbDebugPoint

interface PcbDebugRect {
  type: "pcb_debug_object"
  pcb_debug_object_id: string
  label?: string
  shape: "rect"
  center: Point
  size: Size
  subcircuit_id?: string
}

interface PcbDebugLine {
  type: "pcb_debug_object"
  pcb_debug_object_id: string
  label?: string
  shape: "line"
  start: Point
  end: Point
  subcircuit_id?: string
}

interface PcbDebugPoint {
  type: "pcb_debug_object"
  pcb_debug_object_id: string
  label?: string
  shape: "point"
  center: Point
  subcircuit_id?: string
}
```

### PcbFabricationNoteDimension

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_fabrication_note_dimension.ts)

Defines a measurement annotation within PCB fabrication notes

```typescript
/** Defines a measurement annotation within PCB fabrication notes */
interface PcbFabricationNoteDimension {
  type: "pcb_fabrication_note_dimension"
  pcb_fabrication_note_dimension_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  layer: VisibleLayer
  from: Point
  to: Point
  text?: string
  text_ccw_rotation?: number
  offset?: Length
  offset_distance?: Length
  offset_direction?: {
    x: number
    y: number
  }
  font: "tscircuit2024"
  font_size: Length
  color?: string
  arrow_size: Length
}
```

### PcbFabricationNotePath

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_fabrication_note_path.ts)

Defines a fabrication path on the PCB for fabricators or assemblers

```typescript
/** Defines a fabrication path on the PCB for fabricators or assemblers */
interface PcbFabricationNotePath {
  type: "pcb_fabrication_note_path"
  pcb_fabrication_note_path_id: string
  pcb_component_id: string
  subcircuit_id?: string
  layer: LayerRef
  route: Point[]
  stroke_width: Length
  color?: string
}
```

### PcbFabricationNoteRect

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_fabrication_note_rect.ts)

Defines a fabrication note rectangle on the PCB

```typescript
/** Defines a fabrication note rectangle on the PCB */
interface PcbFabricationNoteRect {
  type: "pcb_fabrication_note_rect"
  pcb_fabrication_note_rect_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  width: Length
  height: Length
  layer: VisibleLayer
  stroke_width: Length
  corner_radius?: Length
  is_filled?: boolean
  has_stroke?: boolean
  is_stroke_dashed?: boolean
  color?: string
}
```

### PcbFabricationNoteText

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_fabrication_note_text.ts)

Defines a fabrication note in text on the PCB, useful for leaving notes for assemblers or fabricators

```typescript
/** Defines a fabrication note in text on the PCB, useful for leaving notes for assemblers or fabricators */
interface PcbFabricationNoteText {
  type: "pcb_fabrication_note_text"
  pcb_fabrication_note_text_id: string
  subcircuit_id?: string
  pcb_group_id?: string
  font: "tscircuit2024"
  font_size: Length
  pcb_component_id: string
  text: string
  ccw_rotation?: number
  layer: VisibleLayer
  anchor_position: Point
  anchor_alignment:
    | "center"
    | "top_left"
    | "top_right"
    | "bottom_left"
    | "bottom_right"
  color?: string
}
```

### PcbFabricatorExtraChargeWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_fabricator_extra_charge_warning.ts)

Selected preset, for example jlcpcb_economy or jlcpcb_standard_20260912.

```typescript
/** Warning that a design feature incurs an extra charge for the selected
 * fabricator preset. For JLCPCB economy or standard presets (including dated
 * variants), via hole diameters below 0.3 mm are an intended use case.
 * The producer detects the condition; this record describes the warning. */
interface PcbFabricatorExtraChargeWarning {
  type: "pcb_fabricator_extra_charge_warning"
  pcb_fabricator_extra_charge_warning_id: string
  warning_type: "pcb_fabricator_extra_charge_warning"
  message: string
  /** Selected preset, for example jlcpcb_economy or jlcpcb_standard_20260912. */
  fabricator_preset: string
  pcb_board_id?: string
  /** Vias responsible for the extra charge, when the warning concerns vias. */
  pcb_via_ids?: string[]
  subcircuit_id?: string
}
```

### PcbFootprintOverlapError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_footprint_overlap_error.ts)

Error emitted when a pcb footprint overlaps with another element

```typescript
/** Error emitted when a pcb footprint overlaps with another element */
interface PcbFootprintOverlapError extends BaseCircuitJsonError {
  type: "pcb_footprint_overlap_error"
  pcb_error_id: string
  error_type: "pcb_footprint_overlap_error"
  pcb_smtpad_ids?: string[]
  pcb_plated_hole_ids?: string[]
  pcb_hole_ids?: string[]
  pcb_keepout_ids?: string[]
}
```

### PcbGroundPlane

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_ground_plane.ts)

Defines a ground plane on the PCB

```typescript
/** Defines a ground plane on the PCB */
interface PcbGroundPlane {
  type: "pcb_ground_plane"
  pcb_ground_plane_id: string
  source_pcb_ground_plane_id: string
  source_net_id: string
  pcb_group_id?: string
  subcircuit_id?: string
}
```

### PcbGroundPlaneRegion

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_ground_plane_region.ts)

Defines a polygon region of a ground plane

```typescript
/** Defines a polygon region of a ground plane */
interface PcbGroundPlaneRegion {
  type: "pcb_ground_plane_region"
  pcb_ground_plane_region_id: string
  pcb_ground_plane_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  layer: LayerRef
  points: Point[]
}
```

### PcbGroup

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_group.ts)

Defines a group of components on the PCB

```typescript
/** Defines a group of components on the PCB */
interface PcbGroup {
  type: "pcb_group"
  pcb_group_id: string
  source_group_id: string
  is_subcircuit?: boolean
  subcircuit_id?: string
  width?: Length
  height?: Length
  center: Point
  display_offset_x?: string
  display_offset_y?: string
  outline?: Point[]
  anchor_position?: Point
  anchor_alignment: NinePointAnchor
  position_mode?: "packed" | "relative_to_group_anchor" | "none"
  positioned_relative_to_pcb_group_id?: string
  positioned_relative_to_pcb_board_id?: string
  pcb_component_ids: string[]
  child_layout_mode?: "packed" | "none"
  name?: string
  description?: string
  layout_mode?: string
  autorouter_configuration?: {
    trace_clearance: Length
  }
  autorouter_used_string?: string
}
```

### PcbHole

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_hole.ts)

Defines a circular hole on the PCB

```typescript
/** Defines a circular hole on the PCB */
interface PcbHoleCircle {
  type: "pcb_hole"
  pcb_hole_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  pcb_component_id?: string
  hole_shape: "circle"
  hole_diameter: number
  x: Distance
  y: Distance
  is_covered_with_solder_mask?: boolean
  soldermask_margin?: number
}
```

### PcbKeepout

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_keepout.ts)

PCB components excluded from keepout DRC enforcement.

```typescript
interface PcbKeepoutOutline {
  type: "pcb_keepout"
  shape: "outline"
  pcb_group_id?: string
  subcircuit_id?: string
  outline: Point[]
  stroke_width: Length
  pcb_keepout_id: string
  layers: string[]
  description?: string
  /** PCB components excluded from keepout DRC enforcement. */
  excluded_pcb_component_ids?: string[]
  /** When true, this keepout is advisory: it does not block routing or copper
   * placement, and DRC reports overlaps as pcb_keepout_overlap_warning records.
   * False or omitted preserves normal enforcement. Component exclusions still apply. */

  warning_only?: boolean
  /** Allow trace crossings without keepout diagnostics; copper pours remain excluded. */
  allow_traces?: boolean
  /** Allow components and their pads/plated holes without keepout diagnostics; copper pours remain excluded. */
  allow_placements?: boolean
}

interface PCBKeepoutRect {
  type: "pcb_keepout"
  shape: "rect"
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  width: number
  height: number
  pcb_keepout_id: string
  layers: string[]
  description?: string
  /** PCB components excluded from keepout DRC enforcement. */
  excluded_pcb_component_ids?: string[]
  /** When true, this keepout is advisory: it does not block routing or copper
   * placement, and DRC reports overlaps as pcb_keepout_overlap_warning records.
   * False or omitted preserves normal enforcement. Component exclusions still apply. */

  warning_only?: boolean
  /** Allow trace crossings without keepout diagnostics; copper pours remain excluded. */
  allow_traces?: boolean
  /** Allow components and their pads/plated holes without keepout diagnostics; copper pours remain excluded. */
  allow_placements?: boolean
}

interface PCBKeepoutCircle {
  type: "pcb_keepout"
  shape: "circle"
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  radius: number
  pcb_keepout_id: string
  layers: string[]
  description?: string
  /** PCB components excluded from keepout DRC enforcement. */
  excluded_pcb_component_ids?: string[]
  /** When true, this keepout is advisory: it does not block routing or copper
   * placement, and DRC reports overlaps as pcb_keepout_overlap_warning records.
   * False or omitted preserves normal enforcement. Component exclusions still apply. */

  warning_only?: boolean
  /** Allow trace crossings without keepout diagnostics; copper pours remain excluded. */
  allow_traces?: boolean
  /** Allow components and their pads/plated holes without keepout diagnostics; copper pours remain excluded. */
  allow_placements?: boolean
}

type PCBKeepout = PCBKeepoutRect | PCBKeepoutCircle | PcbKeepoutOutline
```

### PcbKeepoutOverlapWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_keepout_overlap_warning.ts)

Warning emitted when copper overlaps a PCB keepout with warning_only enabled.

```typescript
/** Warning emitted when copper overlaps a PCB keepout with warning_only enabled. */
interface PcbKeepoutOverlapWarning {
  type: "pcb_keepout_overlap_warning"
  pcb_keepout_overlap_warning_id: string
  warning_type: "pcb_keepout_overlap_warning"
  message: string
  /** The advisory keepout that was overlapped. */
  pcb_keepout_id: string
  /** IDs of the components and copper primitives involved in the overlap. */
  pcb_component_ids?: string[]
  pcb_trace_ids?: string[]
  pcb_smtpad_ids?: string[]
  pcb_plated_hole_ids?: string[]
  pcb_via_ids?: string[]
  /** Optional overlap location in PCB coordinates, in millimeters. */
  center?: Point
  subcircuit_id?: string
}
```

### PcbManualEditConflictWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_manual_edit_conflict_warning.ts)

Warning emitted when a component has both manual placement (via manualEdits) and explicit pcbX/pcbY coordinates

```typescript
/** Warning emitted when a component has both manual placement (via manualEdits) and explicit pcbX/pcbY coordinates */
interface PcbManualEditConflictWarning {
  type: "pcb_manual_edit_conflict_warning"
  pcb_manual_edit_conflict_warning_id: string
  warning_type: "pcb_manual_edit_conflict_warning"
  message: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  source_component_id: string
}
```

### PcbMissingFootprintError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_missing_footprint_error.ts)

Defines a placement error on the PCB

```typescript
/** Defines a placement error on the PCB */
interface PcbMissingFootprintError extends BaseCircuitJsonError {
  type: "pcb_missing_footprint_error"
  pcb_missing_footprint_error_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  error_type: "pcb_missing_footprint_error"
  source_component_id: string
}
```

### PcbNet

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_net.ts)

Defines a net on the PCB

```typescript
/** Defines a net on the PCB */
interface PcbNet {
  type: "pcb_net"
  pcb_net_id: string
  source_net_id?: string
  highlight_color?: string
}
```

### PcbNoteDimension

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_note_dimension.ts)

Defines a measurement annotation within PCB documentation notes

```typescript
/** Defines a measurement annotation within PCB documentation notes */
interface PcbNoteDimension {
  type: "pcb_note_dimension"
  pcb_note_dimension_id: string
  pcb_component_id?: string
  pcb_group_id?: string
  subcircuit_id?: string
  name?: string
  from: Point
  to: Point
  text?: string
  text_ccw_rotation?: number
  offset_distance?: Length
  offset_direction?: {
    x: number
    y: number
  }
  font: "tscircuit2024"
  font_size: Length
  layer: VisibleLayer
  color?: string
  arrow_size: Length
}
```

### PcbNoteLine

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_note_line.ts)

Defines a straight documentation note line on the PCB

```typescript
/** Defines a straight documentation note line on the PCB */
interface PcbNoteLine {
  type: "pcb_note_line"
  pcb_note_line_id: string
  pcb_component_id?: string
  pcb_group_id?: string
  subcircuit_id?: string
  name?: string
  text?: string
  x1: Distance
  y1: Distance
  x2: Distance
  y2: Distance
  layer: VisibleLayer
  stroke_width: Distance
  color?: string
  is_dashed?: boolean
}
```

### PcbNotePath

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_note_path.ts)

Defines a polyline documentation note on the PCB

```typescript
/** Defines a polyline documentation note on the PCB */
interface PcbNotePath {
  type: "pcb_note_path"
  pcb_note_path_id: string
  pcb_component_id?: string
  pcb_group_id?: string
  subcircuit_id?: string
  name?: string
  text?: string
  route: Point[]
  layer: VisibleLayer
  stroke_width: Length
  color?: string
}
```

### PcbNoteRect

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_note_rect.ts)

Defines a rectangular documentation note on the PCB

```typescript
/** Defines a rectangular documentation note on the PCB */
interface PcbNoteRect {
  type: "pcb_note_rect"
  pcb_note_rect_id: string
  pcb_component_id?: string
  pcb_group_id?: string
  subcircuit_id?: string
  name?: string
  text?: string
  center: Point
  width: Length
  height: Length
  layer: VisibleLayer
  stroke_width: Length
  corner_radius?: Length
  is_filled?: boolean
  has_stroke?: boolean
  is_stroke_dashed?: boolean
  color?: string
}
```

### PcbNoteText

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_note_text.ts)

Defines a documentation note in text on the PCB

```typescript
/** Defines a documentation note in text on the PCB */
interface PcbNoteText {
  type: "pcb_note_text"
  pcb_note_text_id: string
  pcb_component_id?: string
  pcb_group_id?: string
  subcircuit_id?: string
  name?: string
  font: "tscircuit2024"
  font_size: Length
  text?: string
  anchor_position: Point
  anchor_alignment:
    | "center"
    | "top_left"
    | "top_right"
    | "bottom_left"
    | "bottom_right"
  layer: VisibleLayer
  is_mirrored_from_top_view?: boolean
  color?: string
}
```

### PcbPackingError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_packing_error.ts)

Defines a failure to pack PCB components within layout bounds

```typescript
/** Defines a failure to pack PCB components within layout bounds */
interface PcbPackingError extends BaseCircuitJsonError {
  type: "pcb_packing_error"
  pcb_packing_error_id: string
  error_type: "pcb_packing_error"
  pcb_group_id?: string
  subcircuit_id?: string
}
```

### PcbPadPadClearanceError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_pad_pad_clearance_error.ts)

Error emitted when pads are closer than the allowed clearance

```typescript
/** Error emitted when pads are closer than the allowed clearance */
interface PcbPadPadClearanceError extends BaseCircuitJsonError {
  type: "pcb_pad_pad_clearance_error"
  pcb_pad_pad_clearance_error_id: string
  error_type: "pcb_pad_pad_clearance_error"
  pcb_pad_ids: string[]
  minimum_clearance?: Distance
  actual_clearance?: Distance
  center?: {
    x?: number
    y?: number
  }
  subcircuit_id?: string
}
```

### PcbPadTraceClearanceError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_pad_trace_clearance_error.ts)

Error emitted when a pad and trace are closer than allowed clearance

```typescript
/** Error emitted when a pad and trace are closer than allowed clearance */
interface PcbPadTraceClearanceError extends BaseCircuitJsonError {
  type: "pcb_pad_trace_clearance_error"
  pcb_pad_trace_clearance_error_id: string
  error_type: "pcb_pad_trace_clearance_error"
  pcb_pad_id: string
  pcb_trace_id: string
  minimum_clearance?: Distance
  actual_clearance?: Distance
  center?: {
    x?: number
    y?: number
  }
  subcircuit_id?: string
}
```

### PcbPanel

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_panel.ts)

Defines a PCB panel that can contain multiple boards

```typescript
/** Defines a PCB panel that can contain multiple boards */
interface PcbPanel {
  type: "pcb_panel"
  pcb_panel_id: string
  width: Length
  height: Length
  center: Point
  thickness: Length
  covered_with_solder_mask: boolean
}
```

### PcbPanelizationPlacementError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_panelization_placement_error.ts)

Defines a panelization placement error on the PCB

```typescript
/** Defines a panelization placement error on the PCB */
interface PcbPanelizationPlacementError extends BaseCircuitJsonError {
  type: "pcb_panelization_placement_error"
  pcb_panelization_placement_error_id: string
  error_type: "pcb_panelization_placement_error"
  pcb_panel_id?: string
  pcb_board_id?: string
  subcircuit_id?: string
}
```

### PcbPin1Location

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/properties/pcb_pin1_location.ts)

```typescript
type PcbPin1Location =
  | "leftside_top"
  | "leftside_bottom"
  | "rightside_top"
  | "rightside_bottom"
  | "topside_left"
  | "topside_right"
  | "bottomside_left"
  | "bottomside_right"

type PcbPin1LocationRotation = 0 | 90 | 180 | 270
```

### PcbPlacementError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_placement_error.ts)

Defines a placement error on the PCB

```typescript
/** Defines a placement error on the PCB */
interface PcbPlacementError extends BaseCircuitJsonError {
  type: "pcb_placement_error"
  pcb_placement_error_id: string
  error_type: "pcb_placement_error"
  subcircuit_id?: string
}
```

### PcbPlatedHole

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_plated_hole.ts)

Defines a circular plated hole on the PCB

```typescript
/** Defines a circular plated hole on the PCB */
interface PcbPlatedHoleCircle {
  type: "pcb_plated_hole"
  shape: "circle"
  pcb_group_id?: string
  subcircuit_id?: string
  outer_diameter: number
  hole_diameter: number
  is_covered_with_solder_mask?: boolean
  x: Distance
  y: Distance
  layers: LayerRef[]
  port_hints?: string[]
  pcb_component_id?: string
  pcb_port_id?: string
  pcb_plated_hole_id: string
  soldermask_margin?: number
}

interface PcbHolePillWithRectPad {
  type: "pcb_plated_hole"
  shape: "pill_hole_with_rect_pad"
  pcb_group_id?: string
  subcircuit_id?: string
  hole_shape: "pill"
  pad_shape: "rect"
  hole_width: number
  hole_height: number
  rect_pad_width: number
  rect_pad_height: number
  rect_border_radius?: number
  hole_offset_x: Distance
  hole_offset_y: Distance
  is_covered_with_solder_mask?: boolean
  x: Distance
  y: Distance
  layers: LayerRef[]
  port_hints?: string[]
  pcb_component_id?: string
  pcb_port_id?: string
  pcb_plated_hole_id: string
  soldermask_margin?: number
}

interface PcbHoleRotatedPillWithRectPad {
  type: "pcb_plated_hole"
  shape: "rotated_pill_hole_with_rect_pad"
  pcb_group_id?: string
  subcircuit_id?: string
  hole_shape: "rotated_pill"
  pad_shape: "rect"
  hole_width: number
  hole_height: number
  hole_ccw_rotation: Rotation
  rect_pad_width: number
  rect_pad_height: number
  rect_border_radius?: number
  rect_ccw_rotation: Rotation
  hole_offset_x: Distance
  hole_offset_y: Distance
  is_covered_with_solder_mask?: boolean
  x: Distance
  y: Distance
  layers: LayerRef[]
  port_hints?: string[]
  pcb_component_id?: string
  pcb_port_id?: string
  pcb_plated_hole_id: string
  soldermask_margin?: number
}

interface PcbHoleCircularWithRectPad {
  type: "pcb_plated_hole"
  shape: "circular_hole_with_rect_pad"
  pcb_group_id?: string
  subcircuit_id?: string
  hole_shape: "circle"
  pad_shape: "rect"
  hole_diameter: number
  rect_pad_width: number
  rect_pad_height: number
  rect_border_radius?: number
  hole_offset_x: Distance
  hole_offset_y: Distance
  is_covered_with_solder_mask?: boolean
  x: Distance
  y: Distance
  layers: LayerRef[]
  port_hints?: string[]
  pcb_component_id?: string
  pcb_port_id?: string
  pcb_plated_hole_id: string
  soldermask_margin?: number
  rect_ccw_rotation?: Rotation
}

/** Defines a plated hole with a polygonal pad on the PCB */
interface PcbHoleWithPolygonPad {
  type: "pcb_plated_hole"
  shape: "hole_with_polygon_pad"
  pcb_group_id?: string
  subcircuit_id?: string
  hole_shape: "circle" | "oval" | "pill" | "rotated_pill"
  hole_diameter?: number
  hole_width?: number
  hole_height?: number
  pad_outline: { x: Distance; y: Distance }[]
  hole_offset_x: Distance
  hole_offset_y: Distance
  is_covered_with_solder_mask?: boolean
  x: Distance
  y: Distance
  layers: LayerRef[]
  port_hints?: string[]
  pcb_component_id?: string
  pcb_port_id?: string
  pcb_plated_hole_id: string
  soldermask_margin?: number
  ccw_rotation?: Rotation
}
```

### PcbPort

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_port.ts)

Defines a port on the PCB

```typescript
/** Defines a port on the PCB */
interface PcbPort {
  type: "pcb_port"
  pcb_port_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  source_port_id: string
  pcb_component_id?: string
  x: Distance
  y: Distance
  layers: LayerRef[]
  is_board_pinout?: boolean
}
```

### PcbPortNotConnectedError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_port_not_connected_error.ts)

Defines an error when a pcb port is not connected to any trace

```typescript
/** Defines an error when a pcb port is not connected to any trace */
interface PcbPortNotConnectedError extends BaseCircuitJsonError {
  type: "pcb_port_not_connected_error"
  pcb_port_not_connected_error_id: string
  error_type: "pcb_port_not_connected_error"
  pcb_port_ids: string[]
  pcb_component_ids: string[]
  subcircuit_id?: string
}
```

### PcbPortNotMatchedError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_port_not_matched_error.ts)

Defines a trace error on the PCB where a port is not matched

```typescript
/** Defines a trace error on the PCB where a port is not matched */
interface PcbPortNotMatchedError extends BaseCircuitJsonError {
  type: "pcb_port_not_matched_error"
  pcb_error_id: string
  error_type: "pcb_port_not_matched_error"
  pcb_component_ids: string[]
  subcircuit_id?: string
}
```

### PcbPreflightRoutingError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_preflight_routing_error.ts)

```typescript
interface PcbPreflightRoutingError extends BaseCircuitJsonError {
  type: "pcb_preflight_routing_error"
  pcb_preflight_routing_error_id: string
  error_type: "pcb_preflight_routing_error"
  error_code: string
  subcircuit_id?: string
  pcb_group_id?: string
  routing_phase_index?: number
  phase_name?: string
  source_trace_ids?: string[]
  pcb_component_ids?: string[]
  pcb_port_ids?: string[]
  related_error_ids?: string[]
  measurements?: Record<string, number>
}
```

### PcbRouteHints

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/properties/pcb_route_hints.ts)

```typescript
type PcbRouteHints = PcbRouteHint[]

interface PcbRouteHint {
  x: number
  y: number
  via?: boolean
  via_to_layer?: LayerRef
}
```

### PcbSilkscreenCircle

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_silkscreen_circle.ts)

Defines a silkscreen circle on the PCB

```typescript
/** Defines a silkscreen circle on the PCB */
interface PcbSilkscreenCircle {
  type: "pcb_silkscreen_circle"
  pcb_silkscreen_circle_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  radius: Length
  layer: VisibleLayer
  stroke_width: Length
  is_filled?: boolean
}
```

### PcbSilkscreenGraphic

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_silkscreen_graphic.ts)

Defines a BRep silkscreen graphic on the PCB

```typescript
/** Defines a BRep silkscreen graphic on the PCB */
interface PcbSilkscreenGraphicBRep {
  type: "pcb_silkscreen_graphic"
  pcb_silkscreen_graphic_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  layer: VisibleLayer
  image_asset?: Asset
  shape: "brep"
  brep_shape: BRepShape
}
```

### PcbSilkscreenLine

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_silkscreen_line.ts)

Defines a silkscreen line on the PCB

```typescript
/** Defines a silkscreen line on the PCB */
interface PcbSilkscreenLine {
  type: "pcb_silkscreen_line"
  pcb_silkscreen_line_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  stroke_width: Distance
  x1: Distance
  y1: Distance
  x2: Distance
  y2: Distance
  layer: VisibleLayer
}
```

### PcbSilkscreenOval

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_silkscreen_oval.ts)

Defines a silkscreen oval on the PCB

```typescript
/** Defines a silkscreen oval on the PCB */
interface PcbSilkscreenOval {
  type: "pcb_silkscreen_oval"
  pcb_silkscreen_oval_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  radius_x: Distance
  radius_y: Distance
  layer: VisibleLayer
  ccw_rotation?: number
}
```

### PcbSilkscreenPath

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_silkscreen_path.ts)

Defines a silkscreen path on the PCB

```typescript
/** Defines a silkscreen path on the PCB */
interface PcbSilkscreenPath {
  type: "pcb_silkscreen_path"
  pcb_silkscreen_path_id: string
  pcb_component_id?: string
  pcb_board_id?: string
  pcb_group_id?: string
  subcircuit_id?: string
  layer: VisibleLayerRef
  route: Point[]
  stroke_width: Length
}
```

### PcbSilkscreenPill

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_silkscreen_pill.ts)

Defines a silkscreen pill on the PCB

```typescript
/** Defines a silkscreen pill on the PCB */
interface PcbSilkscreenPill {
  type: "pcb_silkscreen_pill"
  pcb_silkscreen_pill_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  width: Length
  height: Length
  layer: LayerRef
  ccw_rotation?: number
}
```

### PcbSilkscreenRect

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_silkscreen_rect.ts)

Defines a silkscreen rect on the PCB

```typescript
/** Defines a silkscreen rect on the PCB */
interface PcbSilkscreenRect {
  type: "pcb_silkscreen_rect"
  pcb_silkscreen_rect_id: string
  pcb_component_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  center: Point
  width: Length
  height: Length
  layer: LayerRef
  stroke_width: Length
  corner_radius?: Length
  is_filled?: boolean
  has_stroke?: boolean
  is_stroke_dashed?: boolean
  ccw_rotation?: number
}
```

### PcbSilkscreenText

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_silkscreen_text.ts)

Defines silkscreen text on the PCB

```typescript
/** Defines silkscreen text on the PCB */
interface PcbSilkscreenText {
  type: "pcb_silkscreen_text"
  pcb_silkscreen_text_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  font: "tscircuit2024"
  font_size: Length
  pcb_component_id?: string
  pcb_board_id?: string
  text: string
  is_knockout?: boolean
  knockout_padding?: {
    left: Length
    top: Length
    bottom: Length
    right: Length
  }
  ccw_rotation?: number
  layer: LayerRef
  is_mirrored?: boolean
  anchor_position: Point
  anchor_alignment: NinePointAnchor
}
```

### PcbSolderPaste

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_solder_paste.ts)

Defines solderpaste on the PCB

```typescript
/** Defines solderpaste on the PCB */
interface PcbSolderPasteCircle {
  type: "pcb_solder_paste"
  shape: "circle"
  pcb_solder_paste_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  x: Distance
  y: Distance
  radius: number
  layer: LayerRef
  pcb_component_id?: string
  pcb_smtpad_id?: string
}
```

### PcbStiffener

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_stiffener.ts)

Common properties of bonded PCB reinforcement.

```typescript
/** Common properties of bonded PCB reinforcement. */
interface PcbStiffenerBase {
  type: "pcb_stiffener"
  pcb_stiffener_id: string
  pcb_board_id: string
  /** Ownership only; geometry is already resolved into board coordinates. */
  pcb_group_id?: string
  subcircuit_id?: string
  name?: string
  /** Attachment face, not an additional copper layer. */
  layer: "top" | "bottom"
  material: "fr4" | "polyimide" | "stainless_steel" | "aluminum"
  /** Material thickness in mm, excluding the PCB and adhesive. */
  thickness: Length
  /** Adhesive thickness in mm; omission means unspecified, not zero. */
  adhesive_thickness?: Length
}
```

### PcbText

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_text.ts)

Defines text on the PCB

```typescript
/** Defines text on the PCB */
interface PcbText {
  type: "pcb_text"
  pcb_text_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  text: string
  center: Point
  layer: LayerRef
  width: Length
  height: Length
  lines: number
  // @ts-ignore
  align: "bottom-left"
}
```

### PcbThermalSpoke

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_thermal_spoke.ts)

Pattern for connecting a ground plane to a plated hole

```typescript
/** Pattern for connecting a ground plane to a plated hole */
interface PcbThermalSpoke {
  type: "pcb_thermal_spoke"
  pcb_thermal_spoke_id: string
  pcb_ground_plane_id: string
  shape: string
  spoke_count: number
  spoke_thickness: Distance
  spoke_inner_diameter: Distance
  spoke_outer_diameter: Distance
  pcb_plated_hole_id?: string
  subcircuit_id?: string
}
```

### PcbTrace

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_trace.ts)

Outgoing segment taper; all three fields must be specified together.

```typescript
interface PcbTraceRoutePointWire {
  route_type: "wire"
  x: Distance
  y: Distance
  width: Distance
  /** Outgoing segment taper; all three fields must be specified together. */
  start_width?: Distance
  end_width?: Distance
  width_interpolation_mode?: "linear" | "quadratic"
  copper_pour_id?: string
  is_inside_copper_pour?: boolean
  start_pcb_port_id?: string
  end_pcb_port_id?: string
  layer: LayerRef
}

type PcbTraceRoutePoint =
  | PcbTraceRoutePointWire
  | PcbTraceRoutePointVia
  | PcbTraceRoutePointThroughPad
```

### PcbTraceError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_trace_error.ts)

Defines a trace error on the PCB

```typescript
/** Defines a trace error on the PCB */
interface PcbTraceError extends BaseCircuitJsonError {
  type: "pcb_trace_error"
  pcb_trace_error_id: string
  error_type: "pcb_trace_error"
  center?: Point
  pcb_trace_id: string
  source_trace_id: string
  pcb_component_ids: string[]
  pcb_port_ids: string[]
  subcircuit_id?: string
}
```

### PcbTraceHint

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_trace_hint.ts)

A hint that can be used during generation of a PCB trace.

```typescript
/** A hint that can be used during generation of a PCB trace. */
interface PcbTraceHint {
  type: "pcb_trace_hint"
  pcb_trace_hint_id: string
  pcb_port_id: string
  pcb_component_id: string
  route: RouteHintPoint[]
  subcircuit_id?: string
}
```

### PcbTraceMissingError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_trace_missing_error.ts)

Defines an error when a source trace has no corresponding PCB trace

```typescript
/** Defines an error when a source trace has no corresponding PCB trace */
interface PcbTraceMissingError extends BaseCircuitJsonError {
  type: "pcb_trace_missing_error"
  pcb_trace_missing_error_id: string
  error_type: "pcb_trace_missing_error"
  center?: Point
  source_trace_id: string
  pcb_component_ids: string[]
  pcb_port_ids: string[]
  subcircuit_id?: string
}
```

### PcbTraceTooLongError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_trace_too_long_error.ts)

Error emitted when a PCB trace is longer than its maximum allowed length

```typescript
/** Error emitted when a PCB trace is longer than its maximum allowed length */
interface PcbTraceTooLongError {
  type: "pcb_trace_too_long_error"
  pcb_trace_too_long_error_id: string
  error_type: "pcb_trace_too_long_error"
  message: string
  pcb_trace_id: string
  source_net_id?: string
  source_trace_id?: string
  actual_trace_length: Distance
  maximum_trace_length: Distance
  subcircuit_id?: string
}
```

### PcbTraceTooLongWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_trace_too_long_warning.ts)

Warning emitted when a PCB trace is longer than its maximum allowed length

```typescript
/** Warning emitted when a PCB trace is longer than its maximum allowed length */
interface PcbTraceTooLongWarning {
  type: "pcb_trace_too_long_warning"
  pcb_trace_too_long_warning_id: string
  warning_type: "pcb_trace_too_long_warning"
  message: string
  pcb_trace_id: string
  source_net_id?: string
  source_trace_id?: string
  actual_trace_length: Distance
  maximum_trace_length: Distance
  subcircuit_id?: string
}
```

### PcbTraceTooManyViasWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_trace_too_many_vias_warning.ts)

Warning emitted when a PCB trace has more vias than its maximum allowed count

```typescript
/** Warning emitted when a PCB trace has more vias than its maximum allowed count */
interface PcbTraceTooManyViasWarning {
  type: "pcb_trace_too_many_vias_warning"
  pcb_trace_too_many_vias_warning_id: string
  warning_type: "pcb_trace_too_many_vias_warning"
  message: string
  pcb_trace_id: string
  source_net_id?: string
  source_trace_id?: string
  actual_via_count: number
  maximum_via_count: number
  subcircuit_id?: string
}
```

### PcbTraceWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_trace_warning.ts)

Defines a trace warning on the PCB

```typescript
/** Defines a trace warning on the PCB */
interface PcbTraceWarning {
  type: "pcb_trace_warning"
  pcb_trace_warning_id: string
  warning_type: "pcb_trace_warning"
  message: string
  center?: Point
  pcb_trace_id: string
  source_trace_id: string
  pcb_component_ids: string[]
  pcb_port_ids: string[]
  subcircuit_id?: string
}
```

### PcbVia

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_via.ts)

Defines a via on the PCB

```typescript
/** Defines a via on the PCB */
interface PcbVia {
  type: "pcb_via"
  pcb_via_id: string
  pcb_group_id?: string
  subcircuit_id?: string
  subcircuit_connectivity_map_key?: string
  x: Distance
  y: Distance
  outer_diameter: Distance
  hole_diameter: Distance
  topmost_drill_layer?: LayerRef
  bottommost_drill_layer?: LayerRef
  through_hole?: boolean
  /** @deprecated */
  from_layer?: LayerRef
  /** @deprecated */
  to_layer?: LayerRef
  layers: LayerRef[]
  /** PCB ports belonging to this via, including layer ports and aliases. */
  pcb_port_ids?: string[]
  pcb_trace_id?: string
  source_trace_id?: string
  source_net_id?: string
  net_is_assignable?: boolean
  net_assigned?: boolean
  tented_on_top?: boolean
  tented_on_bottom?: boolean
}
```

### PcbViaClearanceError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_via_clearance_error.ts)

Error emitted when vias are closer than the allowed clearance

```typescript
/** Error emitted when vias are closer than the allowed clearance */
interface PcbViaClearanceError extends BaseCircuitJsonError {
  type: "pcb_via_clearance_error"
  pcb_error_id: string
  error_type: "pcb_via_clearance_error"
  pcb_via_ids: string[]
  minimum_clearance?: Distance
  actual_clearance?: Distance
  pcb_center?: {
    x?: number
    y?: number
  }
  subcircuit_id?: string
}
```

### PcbViaTraceClearanceError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/pcb/pcb_via_trace_clearance_error.ts)

Error emitted when a via and trace are closer than the allowed clearance

```typescript
/** Error emitted when a via and trace are closer than the allowed clearance */
interface PcbViaTraceClearanceError extends BaseCircuitJsonError {
  type: "pcb_via_trace_clearance_error"
  pcb_via_trace_clearance_error_id: string
  error_type: "pcb_via_trace_clearance_error"
  pcb_via_id: string
  pcb_trace_id: string
  minimum_clearance?: Distance
  actual_clearance?: Distance
  center?: {
    x?: number
    y?: number
  }
  subcircuit_id?: string
}
```

## Schematic Elements

### SchematicArc

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_arc.ts)

Draws a styled arc on the schematic

```typescript
/** Draws a styled arc on the schematic */
interface SchematicArc {
  type: "schematic_arc"
  schematic_arc_id: string
  schematic_sheet_id?: string
  schematic_component_id?: string
  schematic_symbol_id?: string
  center: Point
  radius: number
  start_angle_degrees: number
  end_angle_degrees: number
  direction: "clockwise" | "counterclockwise"
  stroke_width?: number | null
  color: string
  is_dashed: boolean
  subcircuit_id?: string
}
```

### SchematicBox

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_box.ts)

```typescript
interface SchematicBox {
  type: "schematic_box"
  schematic_sheet_id?: string
  schematic_component_id?: string
  schematic_symbol_id?: string
  width: number
  height: number
  is_dashed: boolean
  x: number
  y: number
  subcircuit_id?: string
}
```

### SchematicCircle

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_circle.ts)

Draws a styled circle on the schematic

```typescript
/** Draws a styled circle on the schematic */
interface SchematicCircle {
  type: "schematic_circle"
  schematic_circle_id: string
  schematic_sheet_id?: string
  schematic_component_id?: string
  schematic_symbol_id?: string
  center: Point
  radius: number
  stroke_width?: number | null
  color: string
  is_filled: boolean
  fill_color?: string
  is_dashed: boolean
  subcircuit_id?: string
}
```

### SchematicComponent

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_component.ts)

```typescript
interface SchematicComponent {
  type: "schematic_component"
  size: Size
  center: Point
  source_component_id?: string
  schematic_component_id: string
  schematic_sheet_id?: string
  schematic_symbol_id?: string
  pin_spacing?: number
  pin_styles?: Record<
    string,
    {
      left_margin?: number
      right_margin?: number
      top_margin?: number
      bottom_margin?: number
    }
  >
  box_width?: number
  symbol_name?: string
  port_arrangement?: SchematicPortArrangement
  port_labels?: Record<string, string>
  symbol_display_value?: string
  subcircuit_id?: string
  schematic_group_id?: string
  is_schematic_group?: boolean
  source_group_id?: string
  is_box_with_pins: boolean
}

interface SchematicPortArrangementBySize {
  left_size: number
  right_size: number
  top_size?: number
  bottom_size?: number
}

interface SchematicPortArrangementBySides {
  left_side?: { pins: number[]; direction?: "top-to-bottom" | "bottom-to-top" }
  right_side?: { pins: number[]; direction?: "top-to-bottom" | "bottom-to-top" }
  top_side?: { pins: number[]; direction?: "left-to-right" | "right-to-left" }
  bottom_side?: {
    pins: number[]
    direction?: "left-to-right" | "right-to-left"
  }
}

type SchematicPortArrangement =
  | SchematicPortArrangementBySize
  | SchematicPortArrangementBySides
```

### SchematicComponentOverlapWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_component_overlap_warning.ts)

Warning emitted when the rendered bounds of two schematic components overlap

```typescript
/** Warning emitted when the rendered bounds of two schematic components overlap */
interface SchematicComponentOverlapWarning {
  type: "schematic_component_overlap_warning"
  schematic_component_overlap_warning_id: string
  warning_type: "schematic_component_overlap_warning"
  message: string
  schematic_component_ids: [string, string]
  schematic_sheet_id?: string
}
```

### SchematicComponentStylingWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_component_styling_warning.ts)

Warning emitted when a schematic component has a visual styling issue

```typescript
/** Warning emitted when a schematic component has a visual styling issue */
interface SchematicComponentStylingWarning {
  type: "schematic_component_styling_warning"
  schematic_component_styling_warning_id: string
  warning_type: "schematic_component_styling_warning"
  message: string
  schematic_component_id: string
  styling_issue_type: string
  schematic_port_ids?: string[]
  source_component_id?: string
  schematic_sheet_id?: string
  subcircuit_id?: string
}
```

### SchematicDebugObject

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_debug_object.ts)

```typescript
type SchematicDebugObject =
  | SchematicDebugRect
  | SchematicDebugLine
  | SchematicDebugPoint

interface SchematicDebugRect {
  type: "schematic_debug_object"
  label?: string
  shape: "rect"
  center: Point
  size: Size
  subcircuit_id?: string
}

interface SchematicDebugLine {
  type: "schematic_debug_object"
  label?: string
  shape: "line"
  start: Point
  end: Point
  subcircuit_id?: string
}

interface SchematicDebugPoint {
  type: "schematic_debug_object"
  label?: string
  shape: "point"
  center: Point
  subcircuit_id?: string
}
```

### SchematicElementOutsideSheetWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_element_outside_sheet_warning.ts)

Warning emitted when a schematic component, net label, or trace extends outside its schematic sheet

```typescript
/** Warning emitted when a schematic component, net label, or trace extends outside its schematic sheet */
interface SchematicElementOutsideSheetWarning {
  type: "schematic_element_outside_sheet_warning"
  schematic_element_outside_sheet_warning_id: string
  warning_type: "schematic_element_outside_sheet_warning"
  message: string
  schematic_sheet_id: string
  schematic_element_type:
    | "schematic_component"
    | "schematic_net_label"
    | "schematic_trace"
  schematic_element_id: string
}
```

### SchematicError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_error.ts)

```typescript
interface SchematicError extends BaseCircuitJsonError {
  type: "schematic_error"
  schematic_error_id: string
  error_type: "schematic_port_not_found"
  subcircuit_id?: string
}
```

### SchematicGraphic

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_graphic.ts)

References a graphic asset or inline SVG content on a schematic sheet.

```typescript
/** References a graphic asset or inline SVG content on a schematic sheet. */
interface SchematicGraphic {
  type: "schematic_graphic"
  schematic_graphic_id: string
  schematic_sheet_id?: string
  /** Optional canonical source asset; at least one graphic source is required. */
  asset?: Asset
  /** Optional inline SVG source or materialized fallback content. */
  svg_content?: string
  /** Positive centered layout width in schematic units. */
  width?: number
  /** Positive centered layout height in schematic units. */
  height?: number
}
```

### SchematicGroup

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_group.ts)

Defines a group of components on the schematic

```typescript
/** Defines a group of components on the schematic */
interface SchematicGroup {
  type: "schematic_group"
  schematic_group_id: string
  schematic_sheet_id?: string
  source_group_id: string
  is_subcircuit?: boolean
  subcircuit_id?: string
  width: Length
  height: Length
  center: Point
  schematic_component_ids: string[]
  show_as_schematic_box?: boolean
  name?: string
  description?: string
}
```

### SchematicLayoutError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_layout_error.ts)

```typescript
interface SchematicLayoutError extends BaseCircuitJsonError {
  type: "schematic_layout_error"
  schematic_layout_error_id: string
  error_type: "schematic_layout_error"
  source_group_id: string
  schematic_group_id: string
  subcircuit_id?: string
}
```

### SchematicLine

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_line.ts)

Draws a styled line on the schematic

```typescript
/** Draws a styled line on the schematic */
interface SchematicLine {
  type: "schematic_line"
  schematic_line_id: string
  schematic_sheet_id?: string
  schematic_component_id?: string
  schematic_symbol_id?: string
  x1: number
  y1: number
  x2: number
  y2: number
  stroke_width?: number | null
  color: string
  is_dashed: boolean
  dash_length?: number
  dash_gap?: number
  subcircuit_id?: string
}
```

### SchematicManualEditConflictWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_manual_edit_conflict_warning.ts)

Warning emitted when a component has both manual placement (via manualEdits) and explicit schX/schY coordinates

```typescript
/** Warning emitted when a component has both manual placement (via manualEdits) and explicit schX/schY coordinates */
interface SchematicManualEditConflictWarning {
  type: "schematic_manual_edit_conflict_warning"
  schematic_manual_edit_conflict_warning_id: string
  warning_type: "schematic_manual_edit_conflict_warning"
  message: string
  schematic_component_id: string
  schematic_group_id?: string
  subcircuit_id?: string
  source_component_id: string
}
```

### SchematicMissingSheetWarning

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_missing_sheet_warning.ts)

Circuit-wide warning that a schematic has no sheet; has no component target.

```typescript
/** Circuit-wide warning that a schematic has no sheet; has no component target. */
interface SchematicMissingSheetWarning {
  type: "schematic_missing_sheet_warning"
  schematic_missing_sheet_warning_id: string
  warning_type: "schematic_missing_sheet_warning"
  message: string
}
```

### SchematicNetLabel

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_net_label.ts)

Display-only superscript suffix, e.g. "1" in GND¹. Does not change net identity.

```typescript
interface SchematicNetLabel {
  type: "schematic_net_label"
  schematic_net_label_id: string
  schematic_sheet_id?: string
  schematic_trace_id?: string
  source_trace_id?: string
  source_net_id: string
  center: Point
  anchor_position?: Point | undefined
  anchor_side: "top" | "bottom" | "left" | "right"
  text: string
  /** Display-only superscript suffix, e.g. "1" in GND¹. Does not change net identity. */
  display_superscript?: string
  symbol_name?: string | undefined
  /** When true the net label can be repositioned. When false the label's
   * position is fixed by the element it is attached to. */

  is_movable?: boolean
  subcircuit_id?: string
}
```

### SchematicPath

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_path.ts)

```typescript
interface SchematicPath {
  type: "schematic_path"
  schematic_path_id: string
  schematic_sheet_id?: string
  schematic_component_id?: string
  schematic_symbol_id?: string
  fill_color?: string
  is_filled?: boolean
  is_dashed: boolean
  stroke_width?: number | null
  stroke_color?: string
  dash_length?: number
  dash_gap?: number
  points: Point[]
  subcircuit_id?: string
}
```

### SchematicPort

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_port.ts)

```typescript
interface SchematicPort {
  type: "schematic_port"
  schematic_port_id: string
  source_port_id: string
  schematic_sheet_id?: string
  schematic_component_id?: string
  center: Point
  facing_direction?: "up" | "down" | "left" | "right"
  distance_from_component_edge?: number
  side_of_component?: "top" | "bottom" | "left" | "right"
  true_ccw_index?: number
  pin_number?: number
  display_pin_label?: string
  /** Ordered parts of the pin label with per-part styling.
   * For example, `A~{BC}D` is represented as `A`, overlined `BC`, then `D`.
   * Consumers that do not support styled text can use `display_pin_label`. */

  display_pin_label_text_parts?: SchematicTextPart[]
  display_pin_label_font_size?: number
  subcircuit_id?: string
  is_connected?: boolean
  is_internal_circuit_port?: boolean
  is_overlapping_internal_circuit_port?: boolean
  has_input_arrow?: boolean
  has_output_arrow?: boolean
  is_drawn_with_inversion_circle?: boolean
}
```

### SchematicRect

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_rect.ts)

Draws a styled rectangle on the schematic

```typescript
/** Draws a styled rectangle on the schematic */
interface SchematicRect {
  type: "schematic_rect"
  schematic_rect_id: string
  schematic_sheet_id?: string
  schematic_component_id?: string
  schematic_symbol_id?: string
  center: Point
  width: number
  height: number
  rotation: number
  stroke_width?: number | null
  color: string
  is_filled: boolean
  fill_color?: string
  is_dashed: boolean
  subcircuit_id?: string
}
```

### SchematicSheet

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_sheet.ts)

Defines a schematic sheet or page that components can be placed on.

```typescript
/** Defines a schematic sheet or page that components can be placed on. */
interface SchematicSheet {
  type: "schematic_sheet"
  schematic_sheet_id: string
  name?: string
  display_name?: string
  /** Centre in schematic coordinates, X right and Y up. */
  center?: Point
  sheet_index?: number
  sheet_size?: SchematicSheetSize
  sheet_width?: number
  sheet_height?: number
  subcircuit_id?: string
  outline_color?: string
}
```

### SchematicSymbol

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_symbol.ts)

```typescript
interface SchematicSymbol {
  type: "schematic_symbol"
  schematic_symbol_id: string
  name?: string
  metadata?: SchematicSymbolMetadata
}
```

### SchematicTable

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_table.ts)

Defines a table on the schematic, useful for displaying data in a structured format.

```typescript
/** Defines a table on the schematic, useful for displaying data in a structured format. */
interface SchematicTable {
  type: "schematic_table"
  schematic_table_id: string
  schematic_sheet_id?: string
  anchor_position: Point
  column_widths: Length[]
  row_heights: Length[]
  cell_padding?: Length
  border_width?: Length
  subcircuit_id?: string
  schematic_component_id?: string
  anchor?: NinePointAnchor
}
```

### SchematicTableCell

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_table_cell.ts)

Defines a cell within a schematic_table

```typescript
/** Defines a cell within a schematic_table */
interface SchematicTableCell {
  type: "schematic_table_cell"
  schematic_table_cell_id: string
  schematic_sheet_id?: string
  schematic_table_id: string
  start_row_index: number
  end_row_index: number
  start_column_index: number
  end_column_index: number
  text?: string
  center: Point
  width: Length
  height: Length
  horizontal_align?: "left" | "center" | "right"
  vertical_align?: "top" | "middle" | "bottom"
  font_size?: Length
  subcircuit_id?: string
}
```

### SchematicText

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_text.ts)

Display-only superscript suffix, e.g. "1" in GND¹ for an inline net label.

```typescript
interface SchematicText {
  type: "schematic_text"
  schematic_sheet_id?: string
  schematic_component_id?: string
  schematic_symbol_id?: string
  schematic_text_id: string
  /** Set when the text annotates a trace rather than a component, as an inline
   * net label does - the net name drawn alongside a point-to-point wire instead
   * of as an anchored `schematic_net_label`. Lets consumers tell such a label
   * apart from free-standing text and resolve the net it belongs to. */

  source_trace_id?: string
  text: string
  /** Ordered parts with per-part display options.
   * Consumers that do not support styled text can use `text`. */

  text_parts?: SchematicTextPart[]
  /** Display-only superscript suffix, e.g. "1" in GND¹ for an inline net label. */
  display_superscript?: string
  font_size: number
  position: {
    x: number
    y: number
  }
  rotation: number
  anchor: NinePointAnchor | FivePointAnchor
  color: string
  subcircuit_id?: string
}
```

### SchematicTextPart

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_text_part.ts)

One part of schematic text with its display options.

```typescript
/** One part of schematic text with its display options. */
interface SchematicTextPart {
  /** The literal text displayed for this part. */
  text: string
  /** Draw a line above this part, typically indicating an active-low signal. */
  is_overlined?: boolean
}
```

### SchematicTrace

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_trace.ts)

```typescript
interface SchematicTraceEdge {
  from: {
    x: number
    y: number
  }
  to: {
    x: number
    y: number
  }
  is_crossing?: boolean
  from_schematic_port_id?: string
  to_schematic_port_id?: string
}
```

### SchematicVoltageProbe

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/schematic/schematic_voltage_probe.ts)

```typescript
interface SchematicVoltageProbe {
  type: "schematic_voltage_probe"
  schematic_voltage_probe_id: string
  schematic_sheet_id?: string
  source_component_id?: string
  name?: string
  position: Point
  schematic_trace_id: string
  voltage?: number
  subcircuit_id?: string
  color?: string
  label_alignment?: NinePointAnchor
}
```

## Simulation Elements

### SimulationAcSweepCurrentGraph

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_ac_sweep_current_graph.ts)

```typescript
interface SimulationAcSweepCurrentGraph {
  type: "simulation_ac_sweep_current_graph"
  simulation_ac_sweep_current_graph_id: string
  simulation_experiment_id: string
  simulation_parameter_sweep_coordinate?: SimulationParameterSweepCoordinate
  simulation_current_probe_id: string
  frequencies_hz: number[]
  complex_currents: SimulationComplexSample[]
  name?: string
  color?: string
}
```

### SimulationAcSweepVoltageGraph

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_ac_sweep_voltage_graph.ts)

```typescript
interface SimulationAcSweepVoltageGraph {
  type: "simulation_ac_sweep_voltage_graph"
  simulation_ac_sweep_voltage_graph_id: string
  simulation_experiment_id: string
  simulation_parameter_sweep_coordinate?: SimulationParameterSweepCoordinate
  simulation_voltage_probe_id: string
  frequencies_hz: number[]
  complex_voltages: SimulationComplexSample[]
  name?: string
  color?: string
}
```

### SimulationAnalysisResult

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_analysis_result.ts)

```typescript
type SimulationAnalysisResult =
  | SimulationVoltageAnalysisResult
  | SimulationCurrentAnalysisResult

type SimulationNonTransientVoltageAnalysisResult =
  | SimulationDcOperatingPointVoltage
  | SimulationDcSweepVoltageGraph
  | SimulationAcSweepVoltageGraph

type SimulationNonTransientCurrentAnalysisResult =
  | SimulationDcOperatingPointCurrent
  | SimulationDcSweepCurrentGraph
  | SimulationAcSweepCurrentGraph

type SimulationVoltageAnalysisResult =
  | SimulationTransientVoltageGraph
  | SimulationNonTransientVoltageAnalysisResult

type SimulationCurrentAnalysisResult =
  | SimulationTransientCurrentGraph
  | SimulationNonTransientCurrentAnalysisResult
```

### SimulationComplexSample

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_complex_sample.ts)

```typescript
interface SimulationComplexSample {
  re: number
  im: number
}
```

### SimulationCurrentProbe

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_current_probe.ts)

```typescript
/** Defines a current probe for simulation. It measures current flowing from the
 * positive endpoint to the negative endpoint. */
interface SimulationCurrentProbe {
  type: "simulation_current_probe"
  simulation_current_probe_id: string
  source_component_id?: string
  name?: string
  positive_source_port_id?: string
  negative_source_port_id?: string
  positive_source_net_id?: string
  negative_source_net_id?: string
  subcircuit_id?: string
  color?: string
}
```

### SimulationCurrentSource

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_current_source.ts)

```typescript
type SimulationCurrentSource =
  | SimulationDcCurrentSource
  | SimulationAcCurrentSource

/** Defines a DC current source for simulation purposes. It forces a current
 * between two source ports. */
interface SimulationDcCurrentSource {
  type: "simulation_current_source"
  simulation_current_source_id: string
  is_dc_source: true
  positive_source_port_id?: string
  positive_source_net_id?: string
  negative_source_port_id?: string
  negative_source_net_id?: string
  current: number
  ac_magnitude?: number
  ac_phase?: number
}

/** Defines an AC current source for simulation purposes. */
interface SimulationAcCurrentSource {
  type: "simulation_current_source"
  simulation_current_source_id: string
  is_dc_source: false
  terminal1_source_port_id?: string
  terminal2_source_port_id?: string
  terminal1_source_net_id?: string
  terminal2_source_net_id?: string
  current?: number
  frequency?: number
  peak_to_peak_current?: number
  wave_shape?: WaveShape
  phase?: number
  duty_cycle?: number
  ac_magnitude?: number
  ac_phase?: number
}
```

### SimulationDcOperatingPointCurrent

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_dc_operating_point_current.ts)

```typescript
interface SimulationDcOperatingPointCurrent {
  type: "simulation_dc_operating_point_current"
  simulation_dc_operating_point_current_id: string
  simulation_experiment_id: string
  simulation_parameter_sweep_coordinate?: SimulationParameterSweepCoordinate
  simulation_current_probe_id: string
  current: number
  name?: string
  color?: string
}
```

### SimulationDcOperatingPointVoltage

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_dc_operating_point_voltage.ts)

```typescript
interface SimulationDcOperatingPointVoltage {
  type: "simulation_dc_operating_point_voltage"
  simulation_dc_operating_point_voltage_id: string
  simulation_experiment_id: string
  simulation_parameter_sweep_coordinate?: SimulationParameterSweepCoordinate
  simulation_voltage_probe_id: string
  voltage: number
  name?: string
  color?: string
}
```

### SimulationDcSweepCurrentGraph

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_dc_sweep_current_graph.ts)

```typescript
interface SimulationDcSweepCurrentGraph {
  type: "simulation_dc_sweep_current_graph"
  simulation_dc_sweep_current_graph_id: string
  simulation_experiment_id: string
  simulation_parameter_sweep_coordinate?: SimulationParameterSweepCoordinate
  simulation_current_probe_id: string
  sweep_values: number[]
  sweep_unit: SimulationDcSweepUnit
  current_levels: number[]
  name?: string
  color?: string
}
```

### SimulationDcSweepVoltageGraph

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_dc_sweep_voltage_graph.ts)

```typescript
interface SimulationDcSweepVoltageGraph {
  type: "simulation_dc_sweep_voltage_graph"
  simulation_dc_sweep_voltage_graph_id: string
  simulation_experiment_id: string
  simulation_parameter_sweep_coordinate?: SimulationParameterSweepCoordinate
  simulation_voltage_probe_id: string
  sweep_values: number[]
  sweep_unit: SimulationDcSweepUnit
  voltage_levels: number[]
  name?: string
  color?: string
}
```

### SimulationExperiment

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_experiment.ts)

```typescript
interface SimulationExperiment {
  type: "simulation_experiment"
  simulation_experiment_id: string
  name: string
  experiment_type: ExperimentType
  time_per_step?: number // ms
  start_time_ms?: number // ms
  end_time_ms?: number // ms
  spice_options?: SpiceSimulationOptions
  dc_sweep_voltage_source_id?: string
  dc_sweep_current_source_id?: string
  dc_sweep_start?: number
  dc_sweep_stop?: number
  dc_sweep_step?: number
  dc_sweep_unit?: "V" | "A"
  ac_sweep_type?: "linear" | "decade" | "octave"
  ac_samples_per_interval?: number
  ac_sample_count?: number
  ac_start_frequency_hz?: number
  ac_stop_frequency_hz?: number
}

interface SpiceSimulationOptions {
  method?: "trap" | "gear"
  reltol?: number | string
  abstol?: number | string
  vntol?: number | string
}
```

### SimulationOpAmp

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_op_amp.ts)

Defines a simple ideal operational amplifier for simulation.

```typescript
/** Defines a simple ideal operational amplifier for simulation. */
interface SimulationOpAmp {
  type: "simulation_op_amp"
  simulation_op_amp_id: string
  source_component_id?: string
  inverting_input_source_port_id: string
  non_inverting_input_source_port_id: string
  output_source_port_id: string
  positive_supply_source_port_id: string
  negative_supply_source_port_id: string
}
```

### SimulationOscilloscopeTrace

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_oscilloscope_trace.ts)

```typescript
/** Defines how a simulation measurement is rendered as an oscilloscope-style
 * trace. Display fields live here because they describe the relationship
 * between measurement data and a graph, not the probe itself.
 *
 * Scope display fields map measured values into display divisions using
 * display_div = display_center_offset_divs + (raw_value - display_center_value) / units_per_div.
 * Use volts_per_div for voltage traces and amps_per_div for current traces. */
interface SimulationOscilloscopeTrace {
  type: "simulation_oscilloscope_trace"
  simulation_oscilloscope_trace_id: string
  simulation_transient_voltage_graph_id?: string
  simulation_transient_current_graph_id?: string
  simulation_voltage_probe_id?: string
  simulation_current_probe_id?: string
  display_name?: string
  color?: string
  display_center_value?: number
  display_center_offset_divs?: number
  volts_per_div?: number
  amps_per_div?: number
}
```

### SimulationParameterSweep

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_parameter_sweep.ts)

```typescript
type SimulationParameterSweep =
  | SimulationResistanceParameterSweep
  | SimulationCapacitanceParameterSweep
  | SimulationInductanceParameterSweep
  | SimulationVoltageParameterSweep
  | SimulationCurrentParameterSweep

interface SimulationResistanceParameterSweep
  extends SimulationParameterSweepBase {
  parameter_type: "resistance"
  resistor_source_component_id: string
}

interface SimulationCapacitanceParameterSweep
  extends SimulationParameterSweepBase {
  parameter_type: "capacitance"
  capacitor_source_component_id: string
}

interface SimulationInductanceParameterSweep
  extends SimulationParameterSweepBase {
  parameter_type: "inductance"
  inductor_source_component_id: string
}

interface SimulationVoltageParameterSweep extends SimulationParameterSweepBase {
  parameter_type: "voltage"
  source_net_id: string
}

interface SimulationCurrentParameterSweep extends SimulationParameterSweepBase {
  parameter_type: "current"
  current_source_component_id: string
}
```

### SimulationParameterSweepCoordinate

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_parameter_sweep_coordinate.ts)

```typescript
interface SimulationParameterSweepCoordinate {
  simulation_parameter_sweep_id: string
  sweep_index: number
  parameter_value: number
  parameter_unit: SimulationParameterUnit
}
```

### SimulationSpiceSubcircuit

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_spice_subcircuit.ts)

Defines a custom SPICE subcircuit model for simulation.

```typescript
/** Defines a custom SPICE subcircuit model for simulation. */
interface SimulationSpiceSubcircuit {
  type: "simulation_spice_subcircuit"
  simulation_spice_subcircuit_id: string
  /** Source component this SPICE subcircuit models. */

  source_component_id: string
  /** Maps SPICE subcircuit pin names to source port ids. */

  spice_pin_to_source_port_map: Record<string, string>
  /** Full SPICE subcircuit source text. */

  subcircuit_source: string
}
```

### SimulationSwitch

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_switch.ts)

```typescript
interface SimulationSwitch {
  type: "simulation_switch"
  simulation_switch_id: string
  source_component_id?: string
  closes_at?: number
  opens_at?: number
  starts_closed?: boolean
  switching_frequency?: number
}
```

### SimulationTransientCurrentGraph

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_transient_current_graph.ts)

```typescript
interface SimulationTransientCurrentGraph {
  type: "simulation_transient_current_graph"
  simulation_transient_current_graph_id: string
  simulation_experiment_id: string
  simulation_parameter_sweep_coordinate?: SimulationParameterSweepCoordinate
  timestamps_ms?: number[]
  current_levels: number[]
  source_component_id?: string
  subcircuit_connectivity_map_key?: string
  time_per_step: number
  start_time_ms: number
  end_time_ms: number
  name?: string
  color?: string
}
```

### SimulationTransientVoltageGraph

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_transient_voltage_graph.ts)

```typescript
interface SimulationTransientVoltageGraph {
  type: "simulation_transient_voltage_graph"
  simulation_transient_voltage_graph_id: string
  simulation_experiment_id: string
  simulation_parameter_sweep_coordinate?: SimulationParameterSweepCoordinate
  timestamps_ms?: number[]
  voltage_levels: number[]
  source_component_id?: string
  subcircuit_connectivity_map_key?: string
  time_per_step: number
  start_time_ms: number
  end_time_ms: number
  name?: string
  color?: string
}
```

### SimulationUnknownExperimentError

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_unknown_experiment_error.ts)

An unknown error occurred during the simulation experiment.

```typescript
/** An unknown error occurred during the simulation experiment. */
interface SimulationUnknownExperimentError extends BaseCircuitJsonError {
  type: "simulation_unknown_experiment_error"
  simulation_unknown_experiment_error_id: string
  error_type: "simulation_unknown_experiment_error"
  simulation_experiment_id?: string
  subcircuit_id?: string
}
```

### SimulationVoltageProbe

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_voltage_probe.ts)

```typescript
/** Defines a voltage probe for simulation. If a reference input is not provided,
 * it measures against ground. If a reference input is provided, it measures
 * the differential voltage between two points. */
interface SimulationVoltageProbe {
  type: "simulation_voltage_probe"
  simulation_voltage_probe_id: string
  source_component_id?: string
  name?: string
  signal_input_source_port_id?: string
  signal_input_source_net_id?: string
  reference_input_source_port_id?: string
  reference_input_source_net_id?: string
  subcircuit_id?: string
  color?: string
}
```

### SimulationVoltageSource

[Source](https://github.com/tscircuit/circuit-json/blob/main/src/simulation/simulation_voltage_source.ts)

```typescript
type SimulationVoltageSource =
  | SimulationDcVoltageSource
  | SimulationAcVoltageSource

/** Defines a DC voltage source for simulation purposes. It applies a voltage
 * difference between two source ports. */
interface SimulationDcVoltageSource {
  type: "simulation_voltage_source"
  simulation_voltage_source_id: string
  is_dc_source: true
  positive_source_port_id?: string
  positive_source_net_id?: string
  negative_source_port_id?: string
  negative_source_net_id?: string
  voltage: number
  ac_magnitude?: number
  ac_phase?: number
}

/** Defines an AC voltage source for simulation purposes. */
interface SimulationAcVoltageSource {
  type: "simulation_voltage_source"
  simulation_voltage_source_id: string
  is_dc_source: false
  terminal1_source_port_id?: string
  terminal2_source_port_id?: string
  terminal1_source_net_id?: string
  terminal2_source_net_id?: string
  voltage?: number
  frequency?: number
  peak_to_peak_voltage?: number
  wave_shape?: WaveShape
  phase?: number
  duty_cycle?: number
  pulse_delay?: number // ms
  rise_time?: number // ms
  fall_time?: number // ms
  pulse_width?: number // ms
  period?: number // ms
  ac_magnitude?: number
  ac_phase?: number
}
```

<!-- circuit-json-docs:end -->
