# R8 camera-grip enclosure —0.3.18 fit prototype

![Actual native CAD](closed.png)
![Actual exploded CAD](exploded.png)
![Phone-facing CAD](phone-facing.png)

The enclosure follows the approved camera-grip reference: a narrower rounded
lower handle, long finger pad, curved waist, bronze side shutter and circular
back blended into the upper shoulder. These are renders of actual native CAD.
The reference image supplies styling, not measured dimensions or material tests;
the44×56mm PCB requires a wider upper shoulder than the illustration.

The unchanged routed PCB is rigidly rotated180° in the enclosure. Its four
mounting holes, all44 supplier components and every trace keep their original
relative positions. The side plunger drives the real TS24CA horizontally toward
product−X at Y8.5/Z14.86mm, with0.15mm nominal free gap. Switch stroke, return,
overtravel and print tolerance still require a physical fit test.

| Envelope | CAD dimensions, mm |
| --- | --- |
| PCB |44×56×1 |
| Printed remote body including finger pad |52.4×105×23.6 |
| Remote including shutter cap |54.1×105×23.6 |
| Docked assembly including cap |105.4×106×33.6 |
| Protected battery maximum envelope, rotated in plane |32×43×8.5 |
| MagSafe phone contact disk |Ø59 |

These dimensions exclude unqualified screw heads and leads. The phone-facing
plane is Z0; the remote floor is Z10. Printed geometry outside the30mm contact
radius stays at least6mm above the phone plane. This is a common contact datum,
not proof of compatibility with every iPhone/case/camera.

## Source and reproduction

`../product.assembly.tsx` and `../product.exploded.tsx` use supported native
`assembly.device/subassembly` APIs. Editable plans/dimensions live in
`assembly.tsx`, `geometry.ts` and `dimensions.ts`. Eight optional fit-print STLs
are generated from the same plans: base, lid, battery support, shutter plunger,
finger insert, MagSafe cradle and its front/rear covers.

The seven bounded PCB GLBs contain the actual board and all44 supplier models.
Their flattened standard glTF scene records preserve binary geometry/materials,
expand shared mesh instances and express the assembly loader coordinate frame.
The native Y-up declaration prevents unwanted size fitting. Independent checks
verify every original triangle and fragment bounds in both built GLBs, in
addition to original CAD anchors. No supplier import or circuit JSON is edited.

From the repository root with pinned Node/Bun activated, run serially. The
Python3.14 optional printing venv is already configured; setup/start stays light:

```sh
python3 cloud/run-heavy.py -- bun scripts/export-product-pcb.ts
python3 cloud/run-heavy.py -- bun scripts/review-product-model.ts
python3 cloud/run-heavy.py -- bun scripts/check-product-geometry.ts
python3 cloud/run-heavy.py -- tooling/gerber-review-venv/bin/python scripts/export-product-prints.py
python3 cloud/run-heavy.py -- tsci build product.assembly.tsx --glbs
python3 cloud/run-heavy.py -- tsci build product.exploded.tsx --glbs
python3 cloud/run-heavy.py -- tooling/gerber-review-venv/bin/python scripts/review-native-product.py --output evidence/R8-enclosure18-2026-10-07/native-view-review.json
python3 cloud/run-heavy.py -- bun scripts/render-product.ts product.assembly
python3 cloud/run-heavy.py -- bun scripts/render-product.ts product.exploded
python3 cloud/run-heavy.py -- bun scripts/render-product.ts product.assembly phone-facing
```

`print-requirements.txt` pins the optional Python mesh tools. Native geometry,
mesh and actual readback receipts are retained; failed candidates remain in
historical evidence. The assembly creates no second PCB, circuit or routing.

## Mounting and service

Lower seats and upper lid pillars capture the existing four2.2mm holes at PCB
XY(−19,25),(19,25),(−19,−14),(19,−14); the entire arrangement rotates together.
No printed post passes through a PCB hole. M2 fasteners enter from the
underside through2.2mm base/PCB clearances into blind1.7mm lid pilots, leaving
the visible lid smooth. Exact nylon hardware/thread retention is unqualified;
detach the remote to reach the underside screws before removing the lid.

The same protected ASR00012 pack is rotated90° lengthwise into the lower grip,
away from the antenna end. Its32×43×8.5mm maximum envelope has2.1mm nominal
clearance beneath the roof. Support-to-tallest-connector clearance is0.54mm;
cell-to-U5 clearance is4.79mm, with actual XY overlap. Specify and test a thermal
bridge so sensing tracks the cell. Harness insertion/bends, polarity, swelling,
insulation and strain relief require physical verification.

USB-C opens through the curved wall. The power slider remains recessed; use an
insulated plastic tool for the initial fit prototype. A slider lever is not
qualified. Remove the lid and lift the pack/support to reach PAIR/BOOT/RESET/J3,
keeping the correctly polarized pack connected without tension. Use standard
JST programmerJ5→remoteJ3, battery powerON and remoteUSB-C unplugged.

The detached remote retains its docking rails. Magnet/DC shield installation
is from the phone-facing side before bonding the0.6mm front cover. The new rear
cover closes the hollow upper shoulder. Bonding, retention and print tolerances
remain unqualified. The finger insert is candidate printedTPU with0.3mm lateral
and0.1mm adhesive allocation; material and bonding still need selection/testing.

## Remaining physical gates

The magnetic annulus is AppleR31 reference46/54.1×1.1mm geometry only. Exact array,
pole arrangement, DC shield, cover materials/adhesives and anti-rotation remain
unselected. This is not an LED ring or a purchased magnet model.

Qualify phone/case/camera fit, pull force, dock retention, docked/detached RF,
assembled programming/charging/thermal/BLE/iPhoneCamera operation and durability.
Supplier-processed board/assembly preview remains pending. No complete-product
ordering approval follows from CAD checks. Electronics, frozen baselines,
lightweight setup/start and memory guards are unchanged; no RGB torch is added.

[Current review](../evidence/R8-enclosure18-2026-10-07/REVIEW.md).
The rejected0.3.17 shape and its incomplete native upload remain preserved.
