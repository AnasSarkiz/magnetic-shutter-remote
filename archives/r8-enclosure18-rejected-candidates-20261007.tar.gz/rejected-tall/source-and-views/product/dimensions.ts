import {
	applyToPoint,
	compose,
	rotateDEG,
	translate,
} from "transformation-matrix";
/** Millimetres; original PCB XY and +Z away from the phone. */
export const dimensions = {
	pcb: { widthMm: 44, lengthMm: 56, thicknessMm: 1, centerZMm: 13.5 },
	remote: {
		widthMm: 52.4,
		lengthMm: 105,
		heightMm: 23.6,
		bottomZMm: 10,
		wallMm: 1.6,
		centerXMm: -48,
		centerYMm: 0,
		ccwRotationDegrees: 180,
	},
	battery: {
		widthMm: 32,
		lengthMm: 43,
		heightMm: 8.5,
		centerXMm: 0,
		centerYMm: 26.5,
		bottomZMm: 19.4,
	},
	magsafe: {
		contactDiameterMm: 59,
		ringOuterDiameterMm: 54.1,
		ringInnerDiameterMm: 46,
		magnetThicknessMm: 1.1,
	},
	shutter: {
		actuatorXMm: 22.474,
		centerYMm: -8.5,
		centerZMm: 14.86,
		freeGapMm: 0.15,
	},
} as const;
export const pcbToProductTransform = compose(
	translate(dimensions.remote.centerXMm, dimensions.remote.centerYMm),
	rotateDEG(dimensions.remote.ccwRotationDegrees),
);
export function pcbPointInProduct(point: { x: number; y: number }) {
	return applyToPoint(pcbToProductTransform, point);
}
export const mountingHolesMm = [
	[-19, 25],
	[19, 25],
	[-19, -14],
	[19, -14],
] as const;
