import type { JscadOperation } from "jscad-planner";
import { dimensions as d, mountingHolesMm } from "./dimensions";
export type ProductPart = {
	name: string;
	description: string;
	plan: JscadOperation;
	explodeZMm: number;
	referenceOnly?: boolean;
};
export function box({
	size,
	center,
}: {
	size: [number, number, number];
	center: [number, number, number];
}): JscadOperation {
	return { type: "translate", vector: center, shape: { type: "cuboid", size } };
}
function cylinder({
	radiusMm,
	heightMm,
	center,
}: {
	radiusMm: number;
	heightMm: number;
	center: [number, number, number];
}): JscadOperation {
	return {
		type: "cylinder",
		radius: radiusMm,
		height: heightMm,
		center,
		resolution: 32,
	};
}
function subtract(shapes: JscadOperation[]): JscadOperation {
	return { type: "subtract", shapes };
}
function union(shapes: JscadOperation[]): JscadOperation {
	return { type: "union", shapes };
}
function color(
	plan: JscadOperation,
	rgb: [number, number, number],
): JscadOperation {
	return { type: "colorize", color: rgb, shape: plan };
}
function roundBox({
	widthMm,
	lengthMm,
	heightMm,
	center,
	radiusMm = 3,
}: {
	widthMm: number;
	lengthMm: number;
	heightMm: number;
	center: [number, number, number];
	radiusMm?: number;
}): JscadOperation {
	return {
		type: "hull",
		shapes: [-1, 1].flatMap((x) =>
			[-1, 1].map((y) =>
				cylinder({
					radiusMm,
					heightMm,
					center: [
						center[0] + x * (widthMm / 2 - radiusMm),
						center[1] + y * (lengthMm / 2 - radiusMm),
						center[2],
					],
				}),
			),
		),
	};
}
function cameraOutline({
	heightMm,
	zMm,
	palmWidthMm = 54,
	palmLengthMm = 64,
	handleWidthMm = 40,
	handleLengthMm = 58,
	radiusMm = 9,
}: {
	heightMm: number;
	zMm: number;
	palmWidthMm?: number;
	palmLengthMm?: number;
	handleWidthMm?: number;
	handleLengthMm?: number;
	radiusMm?: number;
}): JscadOperation {
	return {
		type: "hull",
		shapes: [
			roundBox({
				widthMm: palmWidthMm,
				lengthMm: palmLengthMm,
				heightMm,
				center: [-2, 0, zMm],
				radiusMm,
			}),
			roundBox({
				widthMm: handleWidthMm,
				lengthMm: handleLengthMm,
				heightMm,
				center: [0, 43, zMm],
				radiusMm: handleWidthMm / 2 - 1,
			}),
		],
	};
}
export function createRemoteOuterPlan(): JscadOperation {
	return {
		type: "hull",
		shapes: [
			cameraOutline({
				heightMm: 1,
				zMm: 6.5,
				palmWidthMm: 56,
				palmLengthMm: 66,
				handleWidthMm: 38,
				handleLengthMm: 56,
				radiusMm: 8,
			}),
			cameraOutline({
				heightMm: 1,
				zMm: 14.5,
				palmWidthMm: 58,
				palmLengthMm: 68,
				handleWidthMm: 42,
				handleLengthMm: 58,
				radiusMm: 10,
			}),
			cameraOutline({
				heightMm: 1,
				zMm: 25.5,
				palmWidthMm: 56,
				palmLengthMm: 66,
				handleWidthMm: 40,
				handleLengthMm: 56,
				radiusMm: 9,
			}),
		],
	};
}
export function createProductParts(): ProductPart[] {
	const caseBody = createRemoteOuterPlan();
	const cavity: JscadOperation = {
		type: "hull",
		shapes: [
			roundBox({
				widthMm: 50.8,
				lengthMm: 58.8,
				heightMm: 21,
				center: [-2, 0, 18.1],
				radiusMm: 1.8,
			}),
			roundBox({
				widthMm: 36.8,
				lengthMm: 52.8,
				heightMm: 21,
				center: [0, 43, 18.1],
				radiusMm: 16,
			}),
		],
	};
	const screwHoles = mountingHolesMm.map(([x, y]) =>
		cylinder({ radiusMm: 0.85, heightMm: 24, center: [x, y, 17] }),
	);
	const posts = mountingHolesMm.map(([x, y]) =>
		box({ size: [4.2, 4.2, 1.8], center: [x, y, 8.1] }),
	);
	const traySeats = [-1, 1].map((side) =>
		box({ size: [2.8, 43, 0.8], center: [side * 17.75, 26.5, 14.4] }),
	);
	const seatedTraySupports = subtract([
		union(traySeats),
		...mountingHolesMm.map(([x, y]) =>
			cylinder({ radiusMm: 3.3, heightMm: 2, center: [x, y, 14.4] }),
		),
	]);
	const apertures = [
		box({ size: [12, 14, 9.5], center: [0, 33.8, 11.48] }),
		box({
			size: [10, 3.4, 2.2],
			center: [26, d.shutter.centerYMm, d.shutter.centerZMm - 4],
		}),
		box({ size: [10, 8, 4], center: [26, 5, 10.8] }),
		box({ size: [14, 2.5, 2], center: [-29, -5, 10.2] }),
		box({ size: [2.5, 14, 2], center: [8, 34, 10.2] }),
	];
	const railGrooves = [-1, 1].map((side) =>
		box({ size: [5.2, 37, 4], center: [side === 1 ? 26 : -30, 0, 7.8] }),
	);
	const base = subtract([
		union([
			subtract([caseBody, cavity, ...apertures, ...railGrooves]),
			...posts,
			seatedTraySupports,
		]),
		...screwHoles,
	]);
	const gripPad = roundBox({
		widthMm: 32,
		lengthMm: 40,
		heightMm: 1.15,
		center: [0, 40, 29.025],
		radiusMm: 14,
	});
	const padPocket = roundBox({
		widthMm: 32.6,
		lengthMm: 40.6,
		heightMm: 1.5,
		center: [0, 40, 29.1],
		radiusMm: 14.3,
	});
	const lid = subtract([
		union([
			{
				type: "hull",
				shapes: [
					cameraOutline({
						heightMm: 0.4,
						zMm: 26.2,
						palmWidthMm: 54,
						palmLengthMm: 64,
						handleWidthMm: 40,
						handleLengthMm: 56,
						radiusMm: 9,
					}),
					cameraOutline({
						heightMm: 0.4,
						zMm: 27,
						palmWidthMm: 54,
						palmLengthMm: 64,
						handleWidthMm: 40,
						handleLengthMm: 56,
						radiusMm: 9,
					}),
					cameraOutline({
						heightMm: 0.4,
						zMm: 28,
						palmWidthMm: 50,
						palmLengthMm: 60,
						handleWidthMm: 36,
						handleLengthMm: 52,
						radiusMm: 11,
					}),
					cameraOutline({
						heightMm: 0.4,
						zMm: 29,
						palmWidthMm: 46,
						palmLengthMm: 56,
						handleWidthMm: 34,
						handleLengthMm: 50,
						radiusMm: 13,
					}),
				],
			},
			...mountingHolesMm.map(([x, y]) =>
				box({ size: [4.2, 4.2, 16.4], center: [x, y, 18.2] }),
			),
		]),
		...mountingHolesMm.map(([x, y]) =>
			cylinder({ radiusMm: 1.1, heightMm: 22, center: [x, y, 20] }),
		),
		padPocket,
	]);
	const tray = subtract([
		box({ size: [33, 44, 0.6], center: [0, 26.5, 15.1] }),
		box({ size: [29, 40, 2], center: [0, 26.5, 15.1] }),
	]);
	const cell = box({
		size: [d.battery.widthMm, d.battery.lengthMm, d.battery.heightMm],
		center: [
			d.battery.centerXMm,
			d.battery.centerYMm,
			d.battery.bottomZMm - 4 + d.battery.heightMm / 2,
		],
	});
	const stemStartXMm = d.shutter.actuatorXMm + d.shutter.freeGapMm;
	const stemEndXMm = 28.2;
	const plunger = union([
		box({
			size: [stemEndXMm - stemStartXMm, 3, 1.8],
			center: [
				(stemStartXMm + stemEndXMm) / 2,
				d.shutter.centerYMm,
				d.shutter.centerZMm - 4,
			],
		}),
		box({
			size: [0.6, 4.4, 3.2],
			center: [23.05, d.shutter.centerYMm, d.shutter.centerZMm - 4],
		}),
		roundBox({
			widthMm: 1.6,
			lengthMm: 7,
			heightMm: 3,
			center: [28.6, d.shutter.centerYMm, d.shutter.centerZMm - 4],
			radiusMm: 0.7,
		}),
	]);
	const contact = union([
		cylinder({ radiusMm: 29.5, heightMm: 2.6, center: [0, 0, 3.5] }),
		subtract([
			cylinder({ radiusMm: 29.5, heightMm: 1.8, center: [0, 0, 1.5] }),
			cylinder({ radiusMm: 27.3, heightMm: 2.2, center: [0, 0, 1.5] }),
		]),
		cylinder({ radiusMm: 22.75, heightMm: 1.8, center: [0, 0, 1.5] }),
	]);
	const ring = subtract([
		cylinder({ radiusMm: 27.05, heightMm: 1.1, center: [0, 0, 1.15] }),
		cylinder({ radiusMm: 23, heightMm: 2, center: [0, 0, 1.15] }),
	]);
	const riser = cylinder({ radiusMm: 27.5, heightMm: 4, center: [0, 0, 6.8] });
	const remoteFoot = {
		type: "translate",
		vector: [d.remote.centerXMm, d.remote.centerYMm, 0],
		shape: {
			type: "rotate",
			angles: [0, 0, Math.PI],
			shape: cameraOutline({
				heightMm: 2.4,
				zMm: 8.8,
				palmWidthMm: 58,
				palmLengthMm: 68,
				handleWidthMm: 44,
				handleLengthMm: 60,
				radiusMm: 11,
			}),
		},
	} satisfies JscadOperation;
	const shoulders: JscadOperation = {
		type: "hull",
		shapes: [
			cylinder({ radiusMm: 27.5, heightMm: 2.4, center: [0, 0, 7.6] }),
			remoteFoot,
		],
	};
	const remoteClearance: JscadOperation = {
		type: "translate",
		vector: [d.remote.centerXMm, d.remote.centerYMm, 0],
		shape: {
			type: "rotate",
			angles: [0, 0, Math.PI],
			shape: cameraOutline({
				heightMm: 30,
				zMm: 24.8,
				palmWidthMm: 58.6,
				palmLengthMm: 68.6,
				handleWidthMm: 42.6,
				handleLengthMm: 58.6,
				radiusMm: 9.8,
			}),
		},
	};
	const upperShoulder: JscadOperation = {
		type: "hull",
		shapes: [
			cylinder({ radiusMm: 29.5, heightMm: 23, center: [0, 0, 20] }),
			{
				type: "translate",
				vector: [d.remote.centerXMm, d.remote.centerYMm, 0],
				shape: {
					type: "rotate",
					angles: [0, 0, Math.PI],
					shape: cameraOutline({
						heightMm: 1.4,
						zMm: 30.8,
						palmWidthMm: 58,
						palmLengthMm: 68,
						handleWidthMm: 42,
						handleLengthMm: 58,
						radiusMm: 10,
					}),
				},
			},
			remoteFoot,
		],
	};
	const sculptedGrip = subtract([
		union([contact, riser, shoulders, upperShoulder]),
		remoteClearance,
		cylinder({ radiusMm: 27.3, heightMm: 28, center: [0, 0, 23.8] }),
	]);
	const rearCover = subtract([
		cylinder({ radiusMm: 27.1, heightMm: 1.4, center: [0, 0, 32.2] }),
		remoteClearance,
	]);
	const rails = [-1, 1].flatMap((side) => [
		{
			type: "translate",
			vector: [d.remote.centerXMm, d.remote.centerYMm, 0],
			shape: {
				type: "rotate",
				angles: [0, 0, Math.PI],
				shape: box({
					size: [2, 36, 4],
					center: [side === 1 ? 27 : -31, 0, 10.8],
				}),
			},
		} satisfies JscadOperation,
		{
			type: "translate",
			vector: [d.remote.centerXMm, d.remote.centerYMm, 0],
			shape: {
				type: "rotate",
				angles: [0, 0, Math.PI],
				shape: box({
					size: [3, 36, 1.2],
					center: [side === 1 ? 25.5 : -29.5, 0, 12.4],
				}),
			},
		} satisfies JscadOperation,
	]);
	return [
		{
			name: "RemoteBase",
			description:
				"Narrow lower camera palm grip; unchanged actual four PCB mounting points",
			plan: color(base, [0.06, 0.065, 0.07]),
			explodeZMm: 4,
		},
		{
			name: "BatterySupport",
			description:
				"Support for the retained protected battery rotated90degrees in the lower grip",
			plan: color(tray, [0.1, 0.11, 0.12]),
			explodeZMm: 34,
		},
		{
			name: "ASR00012_MaximumEnvelope",
			description:
				"Same protected pack32×43×8.5mm in-plane orientation; harness/thermal qualification pending",
			plan: color(cell, [0.7, 0.72, 0.75]),
			explodeZMm: 44,
		},
		{
			name: "SideShutterPlunger",
			description:
				"True horizontal side actuation; nominal0.15mm free gap to real switch",
			plan: color(plunger, [0.48, 0.29, 0.14]),
			explodeZMm: 4,
		},
		{
			name: "RemoteLid",
			description:
				"Domed camera-grip lid; upper PCB shoulder and narrow lower handle",
			plan: color(lid, [0.065, 0.07, 0.075]),
			explodeZMm: 74,
		},
		{
			name: "FingerGripInsert",
			description:
				"Printed flexible grip insert; candidateTPU, adhesive/material qualification pending",
			plan: color(gripPad, [0.025, 0.028, 0.03]),
			explodeZMm: 82,
		},
		{
			name: "MagSafeGrip",
			description:
				"Continuous sculpted circular back and camera handle shoulders; detachable docking geometry",
			plan: color(union([sculptedGrip, ...rails]), [0.06, 0.065, 0.07]),
			explodeZMm: 0,
		},
		{
			name: "MagSafeRearCover",
			description:
				"Circular camera-grip rear face over hollow sculpted shoulder; bond/fit qualification pending",
			plan: color(rearCover, [0.025, 0.028, 0.03]),
			explodeZMm: 45,
		},
		{
			name: "MagSafeFaceCover",
			description:
				"Flat phone contact face over reference magnetic array; material/bonding pending",
			plan: color(
				cylinder({ radiusMm: 29.5, heightMm: 0.6, center: [0, 0, 0.3] }),
				[0.055, 0.06, 0.065],
			),
			explodeZMm: -10,
		},
		{
			name: "MagSafeArrayReference",
			description:
				"AppleR31 reference46/54.1×1.1mm only; exact array/DCshield unselected",
			plan: color(ring, [0.8, 0.55, 0.15]),
			explodeZMm: -6,
			referenceOnly: true,
		},
	];
}
export function partInProduct(part: ProductPart): JscadOperation {
	if (part.name.startsWith("MagSafe")) return part.plan;
	return {
		type: "translate",
		vector: [d.remote.centerXMm, d.remote.centerYMm, 4],
		shape: {
			type: "rotate",
			angles: [0, 0, (d.remote.ccwRotationDegrees * Math.PI) / 180],
			shape: part.plan,
		},
	};
}
