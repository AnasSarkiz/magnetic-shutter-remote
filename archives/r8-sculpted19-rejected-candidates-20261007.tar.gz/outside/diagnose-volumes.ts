import modeling from "/workspace/magnetic-shutter-remote/node_modules/@jscad/modeling";
import {executeJscadOperations} from "/workspace/magnetic-shutter-remote/node_modules/jscad-planner";
import {createProductParts} from "/workspace/magnetic-shutter-remote/product/geometry";
const rows=[];
for(const part of createProductParts().filter(p=>["RemoteBase","RemoteLid","FingerGripInsert"].includes(p.name))){
const visit=(plan,path,depth)=>{const g=executeJscadOperations(modeling,plan);rows.push({path,plan,volume:modeling.measurements.measureVolume(g)});
if(depth<3)for(const [i,child] of (plan.shapes??(plan.shape?[plan.shape]:[])).entries())visit(child,path+"/"+i,depth+1);};visit(part.plan,part.name,0);}
await Bun.write("/workspace/r8-sculpted-reference19-review-20261007/node-volumes.json",JSON.stringify(rows));
