import importlib.util,json
from pathlib import Path
s=importlib.util.spec_from_file_location('exporter','scripts/export-product-prints.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
rows=json.loads(Path('/workspace/r8-sculpted-reference19-review-20261007/node-volumes.json').read_text())
for r in rows:
 d=m.solid_from_plan(r['plan']).volume()-r['volume']
 if abs(d)>1e-5:print(r['path'],r['plan']['type'],r['volume'],d,flush=True)
