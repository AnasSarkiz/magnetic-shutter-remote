"""Nominal routed power-path measurements, not a hardware current test."""
import importlib.util
import json
import argparse
import heapq
import math
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('power_geometry', ROOT/'scripts/manufacturing-audit.py')
GEOMETRY = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = GEOMETRY
SPEC.loader.exec_module(GEOMETRY)


def switching_current_budget(params):
    # Sunlord SWPA3015S1R5NT table: 1.5uH +/-30%, not +/-20%.
    # TI SLVS696D equations 2/3 and 2.2MHz minimum. Triangular ripple RMS.
    minimum_inductance_h = 1.5e-6*(1-0.30)
    boost_duty = 1 - params['input_floor_v']/3.533
    boost_ripple = params['input_floor_v']*boost_duty/(2_200_000*minimum_inductance_h)
    buck_duty = 3.169/4.1205
    buck_ripple = (4.1205-3.169)*buck_duty/(2_200_000*minimum_inductance_h)
    return {'minimum_inductance_h': minimum_inductance_h, 'minimum_frequency_hz': 2_200_000,
            'nominal_inductance_h': 1.5e-6, 'inductance_tolerance_fraction': 0.30,
            'boost_ripple_peak_to_peak_amps': boost_ripple,
            'buck_ripple_peak_to_peak_amps': buck_ripple,
            'rms_design_amps': max(math.hypot(params['input_amps'],boost_ripple/math.sqrt(12)),
                                   math.hypot(0.5,buck_ripple/math.sqrt(12))),
            'peak_design_amps': max(params['input_amps']+boost_ripple/2,0.5+buck_ripple/2)}


def inductor_rating_failures(switching):
    failures = []
    if switching['rms_design_amps'] >= 1.7:
        failures.append('Normal switching-current estimate exceeds qualified inductor RMS rating')
    if switching['peak_design_amps']*1.2 >= 2.3:
        failures.append('Inductor saturation rating does not retain TI recommended 20% peak-current headroom')
    return failures


def width_budget_failures(paths, budgets):
    return [f'{name}: nominal power neck is insufficient for its current budget'
            for name,current in budgets.items()
            if paths[name]['ipc2221_external_estimate_10c_amps'] < current]


def shared_battery_budget(params):
    """Solve two constant-power branches sharing measured battery copper."""
    temperature_factor = 1 + 0.00393*30
    common = params['common_resistance_20c_ohm']*temperature_factor
    radio = params['radio_resistance_20c_ohm']*temperature_factor - common
    light = params['light_resistance_20c_ohm']*temperature_factor - common
    if min(common, radio, light) < -1e-12:
        raise ValueError('Shared copper resistance exceeds a complete branch')
    radio_power = 3.533*0.5/0.8
    light_power = 5.1801925*(params['light_output_amps']+0.005)/0.8
    radio_current, light_current = radio_power/3.003, light_power/3.003
    for iteration in range(100):
        radio_voltage = 3.003-(radio_current+light_current)*common-radio_current*radio
        light_voltage = 3.003-(radio_current+light_current)*common-light_current*light
        if min(radio_voltage, light_voltage) <= 0:
            raise ValueError('No positive shared battery operating point')
        next_radio, next_light = radio_power/radio_voltage, light_power/light_voltage
        if max(abs(next_radio-radio_current), abs(next_light-light_current)) < 1e-12:
            return {'radio_input_amps':next_radio, 'light_input_amps':next_light,
                    'shared_battery_amps':next_radio+next_light,
                    'radio_input_floor_v':radio_voltage, 'light_input_floor_v':light_voltage,
                    'iterations':iteration+1, 'efficiency_assumption_fraction':0.8,
                    'copper_temperature_assumption_c':50, 'buffer_overhead_assumption_amps':0.005}
        radio_current, light_current = next_radio, next_light
    raise ValueError('Shared battery operating point did not converge')


def light_switching_current_budget(operating):
    # TPS61023 specifies 1MHz typical, without a guaranteed minimum. This
    # analytical model is conditional; physical switching/thermal tests remain.
    input_voltage = operating['light_input_floor_v']
    input_current = operating['light_input_amps']
    duty = 1-input_voltage/5.1801925
    ripple = input_voltage*duty/(1_000_000*0.7e-6)
    inductor_rms = math.hypot(input_current, ripple/math.sqrt(12))
    return {'minimum_inductance_h':0.7e-6, 'frequency_assumption_hz':1_000_000,
            'frequency_is_guaranteed_minimum':False, 'duty_fraction':duty,
            'ripple_peak_to_peak_amps':ripple, 'inductor_rms_amps':inductor_rms,
            'inductor_peak_amps':input_current+ripple/2,
            'rectifier_rms_amps':inductor_rms*math.sqrt(1-duty),
            'switch_ground_rms_amps':inductor_rms*math.sqrt(duty)}


def light_buffer_power_domain(circuit):
    """The data driver must share the latch-off supply with its accessory."""
    owners = {e['source_component_id']:e['name'] for e in circuit if e['type']=='source_component'}
    terminals = [('J4',2),('U8',5),('R21',1),('C19',1)]
    memberships = {}
    for reference,pin in [('U7',6),*terminals]:
        # Passive ports legitimately omit pin_number in the native schema.
        # Select their explicit numbered port hint, with unique coverage.
        ports = [e for e in circuit if e['type']=='source_port' and
                 owners[e['source_component_id']]==reference and
                 (e.get('pin_number')==pin or f'pin{pin}' in e.get('port_hints',[]))]
        if len(ports)!=1:
            raise ValueError(f'Light power-domain terminal is not unique: {reference}.pin{pin}')
        memberships[(reference,pin)] = ports[0].get('subcircuit_connectivity_map_key')
    switched = memberships[('U7',6)]
    if not switched or any(memberships[terminal]!=switched for terminal in terminals):
        raise ValueError('Light data buffer, OE pull-up and bypass must share the accessory latch-off supply')
    return {'load_switch_output':{'reference':'U7','pin':6},
            'same_switched_power_terminals':[{'reference':reference,'pin':pin} for reference,pin in terminals],
            'fault_state':'No separately powered data driver remains after the light supply latches off. Powered-off input leakage is specified; no output Ioff guarantee is invented.'}


def light_buffer_voltage_budget(params):
    # TI SLVS841F DBV rDS(on) maximum135mOhm across-40..125C.
    # Conservative maximum total-limiter current through both whole-track
    # resistance upper bounds, including copper shared with other branches.
    current = .469342
    trace_drop = current*1.1179*(params['raw_trace_resistance_20c_ohm']+params['buffer_trace_resistance_20c_ohm'])
    switch_drop = current*.135
    floor = 4.726742-trace_drop-switch_drop
    return {'minimum_pwm_boost_output_v':4.726742,'switch_resistance_max_ohm':.135,
            'limiter_current_max_amps':current,'trace_drop_upper_bound_v':trace_drop,
            'switch_drop_upper_bound_v':switch_drop,'buffer_supply_floor_budget_v':floor,
            'buffer_required_minimum_v':4.5,'within_static_voltage_budget':floor>=4.5,
            'scope':'PWM/static trace-only bound; excludes transient/PFM/ground-plane drops and is not a physical voltage measurement.'}


def supported_ground_corridors(params):
    """Find explicit wide, solid-copper escapes into a real ground pour."""
    start = params['start']
    paths = []
    for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
        end = (start[0]+dx*params['length_mm'],start[1]+dy*params['length_mm'])
        corridor = GEOMETRY.LineString([start,end]).buffer(params['width_mm']/2)
        landing = GEOMETRY.Point(end).buffer(params['width_mm']/2)
        # Negligible tolerance only absorbs floating-point polygon boundaries;
        # it does not waive a physical neck, gap, hole or copper clearance.
        if (params['ground_geometry'].buffer(1e-7).covers(corridor) and
                params['pour_geometry'].buffer(1e-7).covers(landing)):
            paths.append({'start_mm':list(start),'end_mm':list(end),
                          'verified_copper_width_lower_bound_mm':params['width_mm'],
                          'verified_escape_length_mm':params['length_mm']})
    return paths


def ground_connector_attachments(params):
    circuit,copper = params['circuit'],params['copper']
    components = {e['name']:e['source_component_id'] for e in circuit if e['type']=='source_component'}
    owners = {e['source_component_id']:e['pcb_component_id'] for e in circuit if e['type']=='pcb_component'}
    pads = {e['pcb_smtpad_id']:e for e in circuit if e['type']=='pcb_smtpad'}
    reports = []
    for reference,pin,width,current in [('J2','pin1',.9,params['battery_amps']),
                                       ('J4','pin1',.3,.469342),('J4','pin4',.3,.469342)]:
        matches = [f for f in copper if f.kind=='smt' and f.owner==owners[components[reference]] and pin in pads[f.id]['port_hints']]
        if len(matches)!=1:
            raise ValueError(f'Ground connector terminal is not unique: {reference}.{pin}')
        pad = matches[0]
        ground = [f for f in copper if f.layer==pad.layer and f.net==pad.net]
        pours = [f.geometry for f in ground if f.kind=='pour']
        if not pours:
            raise ValueError(f'No actual ground pour at {reference}.{pin}')
        corridors = supported_ground_corridors({'start':tuple(pad.geometry.centroid.coords[0]),
            'ground_geometry':GEOMETRY.unary_union([f.geometry for f in ground]),
            'pour_geometry':GEOMETRY.unary_union(pours),'width_mm':width,'length_mm':3})
        if not corridors:
            raise ValueError(f'No verified {width}mm solid-copper ground escape at {reference}.{pin}')
        capacity = .048*10**.44*((width/.0254)*(.035/.0254))**.725
        if current > capacity:
            raise ValueError(f'Ground connector attachment capacity is insufficient: {reference}.{pin}')
        reports.append({'reference':reference,'pin':pin,'layer':pad.layer,'actual_pad_id':pad.id,
            'current_budget_amps':current,'ipc2221_external_estimate_10c_amps':capacity,
            'solid_ground_escape_corridors':corridors,
            'scope':'Local pad-to-pour copper. Full ground connectivity is independently checked; this is not a measured temperature or global plane-flow result.'})
    return reports


def load_path(params):
    features = [f for f in params['copper'] if f.net == params['net']]
    circuit = params['circuit']
    owners = {e['pcb_component_id']: e['source_component_id'] for e in circuit if e['type'] == 'pcb_component'}
    components = {e['source_component_id']: e['name'] for e in circuit if e['type'] == 'source_component'}
    pads = {e['pcb_smtpad_id']: e for e in circuit if e['type'] == 'pcb_smtpad'}
    endpoints = []
    for reference, pin in params['terminals']:
        matches = [i for i,f in enumerate(features) if f.kind == 'smt' and components[owners[f.owner]] == reference and pin in pads[f.id]['port_hints']]
        if len(matches) != 1:
            raise ValueError(f'Power terminal is not unique: {reference}.{pin}')
        endpoints.append(matches[0])
    adjacent = [[] for _ in features]
    for i, first in enumerate(features):
        for k, second in enumerate(features[:i]):
            if (first.layer == second.layer and first.geometry.intersects(second.geometry)) or (first.id == second.id and first.kind == second.kind == 'annulus'):
                adjacent[i].append(k)
                adjacent[k].append(i)
    queue = [(0, endpoints[0], [endpoints[0]])]
    visited = set()
    while queue:
        resistance, i, route = heapq.heappop(queue)
        if i in visited:
            continue
        visited.add(i)
        if i == endpoints[1]:
            tracks = [features[k] for k in route if features[k].kind == 'track']
            minimum = min(params['track_widths'][t.id] for t in tracks)
            return {'terminals': params['terminals'], 'features': [{'id':features[k].id,'layer':features[k].layer} for k in route], 'trace_only_resistance_upper_bound_20c_ohm': resistance, 'minimum_trace_width_mm': minimum, 'ipc2221_external_estimate_10c_amps': 0.048*10**0.44*((minimum/0.0254)*(0.035/0.0254))**0.725}
        for k in adjacent[i]:
            weight = params['track_resistances'][features[k].id] if features[k].kind == 'track' else 0
            heapq.heappush(queue, (resistance+weight, k, route+[k]))
    raise ValueError('No physically connected power path')


def review(output=ROOT/'evidence/R8-prototype-2026-10-05/power-path-measurements.json'):
    source = ROOT/'dist/index/circuit.json'
    circuit = json.loads(source.read_text())
    if any(e['type'].endswith('_error') for e in circuit):
        raise ValueError('Power review requires an error-free routed circuit')
    copper, _, _ = GEOMETRY.make_features(circuit, 'gerber')
    membership = {e.id: e.net for e in copper if e.kind == 'track'}
    names = {e['subcircuit_connectivity_map_key']: e['name'] for e in circuit if e['type'] == 'source_net'}
    segments = []
    for trace in (e for e in circuit if e['type'] == 'pcb_trace'):
        if trace['pcb_trace_id'] not in membership:
            if len(trace['route']) == 1 and trace['route'][0]['route_type'] == 'wire':
                continue  # Two existing breakouts may already be the same point.
            raise ValueError('Unattributed nonzero routed trace')
        name = names[membership[trace['pcb_trace_id']]]
        if name not in ['USB5V', 'VBAT', 'V3', 'INDUCTOR_L1', 'INDUCTOR_L2', 'RING_SW', 'RING_5V_RAW', 'RING_5V', 'GND']:
            continue
        for a, b in zip(trace['route'], trace['route'][1:]):
            # Match the qualified converter's discrete start-aperture semantics.
            if a['route_type'] == 'wire':
                start, width = a, a['width']
                end = b['start'] if b['route_type'] == 'through_pad' else b
            elif b['route_type'] == 'wire':
                start = a['end'] if a['route_type'] == 'through_pad' else a
                end, width = b, b['width']
            else:
                continue
            length = math.hypot(end['x']-start['x'], end['y']-start['y'])
            if length:
                segments.append({'net': name, 'trace': trace['pcb_trace_id'],
                                 'length_mm': length, 'width_mm': width,
                                 'resistance_20c_ohm': 0.00001724*length/(width*0.035)})
    summaries = {}
    has_light = any(e['type']=='source_component' and e['name']=='U6' for e in circuit)
    required_nets = ['USB5V', 'VBAT', 'V3', 'INDUCTOR_L1', 'INDUCTOR_L2']
    if has_light:
        required_nets += ['RING_SW', 'RING_5V_RAW', 'RING_5V']
    for name in required_nets:
        subset = [s for s in segments if s['net'] == name]
        if not subset:
            raise ValueError(f'No measured segments for {name}')
        width = min(s['width_mm'] for s in subset)
        summaries[name] = {'minimum_width_mm': width,
                          'summed_branch_length_mm': sum(s['length_mm'] for s in subset),
                          'all_segments_series_resistance_20c_ohm': sum(s['resistance_20c_ohm'] for s in subset),
                          'ipc2221_external_estimate_10c_amps': 0.048*10**0.44*((width/0.0254)*(0.035/0.0254))**0.725}
    # Every branch in series overestimates the actual route resistance. Assume
    # 50C copper and a conservative -3% regulator budget; do not imply testing.
    resistance_factor = 1 + 0.00393*30
    track_resistances = {s['trace']: sum(row['resistance_20c_ohm'] for row in segments if row['trace'] == s['trace']) for s in segments}
    track_widths = {s['trace']: min(row['width_mm'] for row in segments if row['trace'] == s['trace']) for s in segments}
    paths = {}
    terminals_by_path = [
            ('V3', 'V3', [('U3','pin1'),('U1','pin8')]),
            ('VBAT', 'VBAT', [('J2','pin2'),('U3','pin5')]),
            ('USB_VBUS1', 'USB5V', [('J1','pin18'),('U2','pin10')]),
            ('USB_VBUS2', 'USB5V', [('J1','pin27'),('U2','pin10')]),
            ('BATTERY_CHARGE', 'VBAT', [('U2','pin2'),('J2','pin2')]),
            ('INDUCTOR_L1', 'INDUCTOR_L1', [('U3','pin4'),('L1','pin2')]),
            ('INDUCTOR_L2', 'INDUCTOR_L2', [('U3','pin2'),('L1','pin1')])]
    if has_light:
        terminals_by_path += [
            ('LIGHT_INPUT','VBAT',[('J2','pin2'),('L2','pin1')]),
            ('RING_SW','RING_SW',[('U6','pin5'),('L2','pin2')]),
            ('RAW_5V','RING_5V_RAW',[('U6','pin6'),('U7','pin1')]),
            ('LIGHT_5V','RING_5V',[('U7','pin6'),('J4','pin2')]),
            ('BUFFER_5V','RING_5V',[('U7','pin6'),('U8','pin5')])]
    for path_name, name, terminals in terminals_by_path:
        net = next(key for key,n in names.items() if n == name)
        paths[path_name] = load_path({'copper':copper,'circuit':circuit,'net':net,'terminals':terminals,'track_resistances':track_resistances,'track_widths':track_widths})
    module_floor = 3.169 - 0.5*resistance_factor*paths['V3']['trace_only_resistance_upper_bound_20c_ohm']
    # Retain the earlier static tolerance envelope and use 80% efficiency.
    # Solve I*(Vbattery-I*R)=P/efficiency, including the actual copper drop.
    input_resistance = resistance_factor*paths['VBAT']['trace_only_resistance_upper_bound_20c_ohm']
    input_power = 3.533*0.5/0.8
    discriminant = 3.003**2-4*input_resistance*input_power
    if discriminant <= 0:
        raise ValueError('No valid trace-only battery operating point')
    battery_input_current = 2*input_power/(3.003+math.sqrt(discriminant))
    regulator_input_floor = 3.003 - battery_input_current*resistance_factor*paths['VBAT']['trace_only_resistance_upper_bound_20c_ohm']
    switching = switching_current_budget({'input_floor_v':regulator_input_floor,
                                          'input_amps':battery_input_current})
    budgets = {'V3':0.5, 'VBAT':battery_input_current, 'USB_VBUS1':0.4,
               'USB_VBUS2':0.4, 'BATTERY_CHARGE':0.3333,
               'INDUCTOR_L1':switching['rms_design_amps'],
               'INDUCTOR_L2':switching['rms_design_amps']}
    light_review = None
    if has_light:
        buffer_domain = light_buffer_power_domain(circuit)
        buffer_voltage = light_buffer_voltage_budget({
            'raw_trace_resistance_20c_ohm':paths['RAW_5V']['trace_only_resistance_upper_bound_20c_ohm'],
            'buffer_trace_resistance_20c_ohm':paths['BUFFER_5V']['trace_only_resistance_upper_bound_20c_ohm']})
        radio_tracks = {f['id'] for f in paths['VBAT']['features'] if f['id'] in track_resistances}
        light_tracks = {f['id'] for f in paths['LIGHT_INPUT']['features'] if f['id'] in track_resistances}
        common_tracks = sorted(radio_tracks & light_tracks)
        if not common_tracks:
            raise ValueError('No measured common battery feed; shared-load audit requires an explicit common path')
        common_resistance = sum(track_resistances[identifier] for identifier in common_tracks)
        common_width = min(track_widths[identifier] for identifier in common_tracks)
        paths['COMMON_BATTERY'] = {'features':common_tracks,
            'trace_only_resistance_upper_bound_20c_ohm':common_resistance,
            'minimum_trace_width_mm':common_width,
            'ipc2221_external_estimate_10c_amps':0.048*10**0.44*((common_width/0.0254)*(0.035/0.0254))**0.725}
        resistance_params = {'common_resistance_20c_ohm':common_resistance,
            'radio_resistance_20c_ohm':paths['VBAT']['trace_only_resistance_upper_bound_20c_ohm'],
            'light_resistance_20c_ohm':paths['LIGHT_INPUT']['trace_only_resistance_upper_bound_20c_ohm']}
        operating = shared_battery_budget({**resistance_params, 'light_output_amps':0.469342})
        normal = shared_battery_budget({**resistance_params, 'light_output_amps':0.350})
        battery_input_current = operating['shared_battery_amps']
        regulator_input_floor = operating['radio_input_floor_v']
        switching = switching_current_budget({'input_floor_v':regulator_input_floor,'input_amps':operating['radio_input_amps']})
        light_switching = light_switching_current_budget(operating)
        budgets.update({'VBAT':operating['radio_input_amps'], 'COMMON_BATTERY':battery_input_current,
                        'LIGHT_INPUT':operating['light_input_amps'], 'RING_SW':light_switching['inductor_rms_amps'],
                        'RAW_5V':light_switching['rectifier_rms_amps'], 'LIGHT_5V':0.469342, 'BUFFER_5V':0.005,
                        'INDUCTOR_L1':switching['rms_design_amps'], 'INDUCTOR_L2':switching['rms_design_amps']})
        # Actual U6 ground escape: a short pin neck feeds two off-pad through
        # barrels and the independently checked ground plane. Do not infer its
        # capacity from the default net width or a broad plane elsewhere.
        owner = next(e['pcb_component_id'] for e in circuit if e['type']=='pcb_component' and
                     e['source_component_id']==next(s['source_component_id'] for s in circuit if s['type']=='source_component' and s['name']=='U6'))
        pad_id = next(e['pcb_smtpad_id'] for e in circuit if e['type']=='pcb_smtpad' and e['pcb_component_id']==owner and 'pin4' in e['port_hints'])
        ground_pad = next(f for f in copper if f.id==pad_id)
        escapes = [f for f in copper if f.kind=='track' and f.layer==ground_pad.layer and f.net==ground_pad.net and f.geometry.intersects(ground_pad.geometry)]
        if not escapes:
            raise ValueError('No measured boost ground pin escape')
        ground_width = min(track_widths[f.id] for f in escapes)
        paths['LIGHT_GROUND'] = {'features':[f.id for f in escapes], 'minimum_trace_width_mm':ground_width,
            'ipc2221_external_estimate_10c_amps':0.048*10**0.44*((ground_width/0.0254)*(0.035/0.0254))**0.725}
        budgets['LIGHT_GROUND'] = light_switching['switch_ground_rms_amps']
        via_groups = []
        for group_name, expected_points, current, share in [
            ('battery_shared',[(14.45,20.5),(15.45,20.5),(16.45,20.5)], battery_input_current, .55),
            ('light_input',[(-12.6,10),(-12.6,10.850017),(-12.6,11.7)], operating['light_input_amps'], .75),
            ('boost_ground',[(-5.5499858,15.5),(-5.5499858,16.35)], light_switching['switch_ground_rms_amps'], .8)]:
            vias = []
            for x,y in expected_points:
                matches = [e for e in circuit if e['type']=='pcb_via' and math.hypot(e['x']-x,e['y']-y)<1e-4]
                if len(matches)!=1:
                    raise ValueError(f'{group_name}: required parallel barrel is absent or duplicate')
                via = matches[0]
                if set(via['layers'])!={'top','bottom'} or abs(via['hole_diameter']-.30)>1e-7 or abs(via['outer_diameter']-.45)>1e-7:
                    raise ValueError(f'{group_name}: parallel barrel dimensions/span differ')
                annuli = [f for f in copper if f.id==via['pcb_via_id'] and f.kind=='annulus']
                feeds = {}
                for annulus in annuli:
                    feeds[annulus.layer] = [f.id for f in copper if f.kind in ('track','pour') and f.net==annulus.net and f.layer==annulus.layer and f.geometry.intersects(annulus.geometry)]
                if set(feeds)!={'top','bottom'} or any(not identifiers for identifiers in feeds.values()):
                    raise ValueError(f'{group_name}: parallel barrel lacks physical copper on both sides')
                vias.append({'id':via['pcb_via_id'],'x':x,'y':y,'physical_feeds':feeds})
            barrel_area_square_mils = math.pi*.30*.020/(.0254**2)
            capacity = .024*20**.44*barrel_area_square_mils**.725
            via_groups.append({'group':group_name,'vias':vias,'minimum_plating_assumption_mm':.020,
                'temperature_rise_assumption_c':20,'maximum_current_share_assumption_fraction':share,
                'single_barrel_ipc2221_internal_estimate_amps':capacity,
                'estimated_maximum_barrel_amps':current*share,'within_conditional_budget':current*share<capacity})
        # The shared feed enters/leaves the middle tap. Equal nominal barrel
        # resistances plus both measured 1mm/0.9mm wing buses predict ~52%
        # on the middle barrel, not an unjustified one-third equal split.
        board = next(e for e in circuit if e['type']=='pcb_board')
        barrel_resistance = .00001724*board['thickness']/(math.pi*.30*.020)
        wing_resistance = .00001724*1/(common_width*.035)
        middle_share = (1/barrel_resistance)/(1/barrel_resistance+2/(barrel_resistance+2*wing_resistance))
        via_groups[0]['nominal_center_feed_dc_model'] = {'barrel_resistance_20c_ohm':barrel_resistance,
            'one_wing_bus_resistance_20c_ohm':wing_resistance,'middle_barrel_current_fraction':middle_share,
            'physical_topology':'Center-fed top and bottom buses; each outer barrel adds two1mm bus sections.'}
        if middle_share > via_groups[0]['maximum_current_share_assumption_fraction']:
            raise ValueError('Center-feed barrel model exceeds the reserved current-share budget')
        light_review = {'normal_350ma_operating_budget':normal, 'maximum_limiter_operating_budget':operating,
                        'switching':light_switching,'parallel_barrel_groups':via_groups,
                        'inductor_rated_rms_amps':4.90,'inductor_rated_saturation_amps':7.35,
                        'required_saturation_amps_with_20pct_headroom':light_switching['inductor_peak_amps']*1.2,
                        'protected_battery_and_ph2_design_limit_amps':2.0,
                        'connector_ground_attachments':ground_connector_attachments({'circuit':circuit,'copper':copper,'battery_amps':battery_input_current}),
                        'buffer_power_domain':buffer_domain,'buffer_voltage_budget':buffer_voltage}
    report = {'circuit_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'nominal_copper_thickness_mm': 0.035, 'segments': segments, 'nets': summaries, 'physical_load_paths': paths,
              'module_design_supply_amps': 0.5, 'module_voltage_floor_budget_v': module_floor,
              'battery_input_design_amps_at_assumed_80pct_efficiency': battery_input_current,
              'regulator_input_voltage_floor_budget_v': regulator_input_floor,
              'switching_current_budget': switching, 'load_path_current_budgets_amps': budgets,
              'light_shared_power_review':light_review,
              'inductor_rating_budget': {'rated_rms_amps': 1.7, 'rated_saturation_amps': 2.3,
                                        'required_saturation_amps_with_20pct_headroom': switching['peak_design_amps']*1.2},
              'references': ['DOIT ESPC3-12 manual page7: startup exceeds400mA; supply>=500mA', 'TI SLVS696D: up to500mA boost at VIN>2.4V; section9.2.2.2 recommends20% saturation headroom', 'Sunlord SWPA3015S1R5NT:1.5uH+/-30%,1.7A RMS/2.3A saturation; evidence/R8-routing-2026-10-05/sunlord-page5.png', 'IPC-2221 external empirical estimate'],
              'limitations': ['Nominal trace-only resistance; excludes connector, via, battery and regulator transient drops.', 'Whole-track series resistance overestimates the selected path, but does not establish actual loaded voltage.', '35um copper, 50C copper, 3.169-3.533V static tolerance envelope and80% efficiency are design assumptions.', 'USB current budget400mA includes333.3mA worst charge current and control overhead; USB disables radio supply.', 'Switching estimate uses ideal steady-state triangular ripple; startup, faults, core losses and thermal spreading require hardware verification.', 'Ground return uses independently verified continuous EP planes; IPC trace estimates do not model plane bottlenecks or via/contact losses.', 'No current, temperature, transient, battery runtime or RF measurement is claimed.']}
    failures = []
    if module_floor <= 3.0 or regulator_input_floor <= 2.4:
        failures.append('Trace-only voltage budget does not retain module/regulator operating margin')
    failures.extend(width_budget_failures(paths,budgets))
    failures.extend(inductor_rating_failures(switching))
    if light_review:
        if not light_review['buffer_voltage_budget']['within_static_voltage_budget']:
            failures.append('Switched data buffer supply does not retain the4.5V manufacturer operating floor')
        if battery_input_current >= 2:
            failures.append('Combined battery current exceeds protected pack/PH2 design rating')
        if light_review['switching']['inductor_rms_amps'] >= 4.9 or light_review['required_saturation_amps_with_20pct_headroom'] >= 7.35:
            failures.append('Light inductor current rating/headroom is insufficient')
        if any(not group['within_conditional_budget'] for group in light_review['parallel_barrel_groups']):
            failures.append('Parallel via group exceeds conditional plating/current-share budget')
        report['references'] += ['TI TPS61023 SLVSF14B', 'TI TPS2553-1 SLVS841F: 63.4k +/-1% IOS maximum0.469342A', 'Sunlord SWPA5040S1R0NT:1uH +/-30%,4.90A RMS/7.35A saturation', 'JST PH catalogue:2A using AWG24 contacts']
        report['limitations'] += ['Light uses TPS61023 typical1MHz, not a guaranteed minimum; verify frequency/ripple/startup/temperature on hardware.', 'Protected1S pack and exact RGBW ring are unselected; require >=2A continuous pack and verified PH2 polarity/harness.', 'Parallel via model assumes >=20um barrel plating,20C temperature rise and stated current sharing; assembly/process and hardware measurements remain required.', 'Light output350mA is a proposed normal brightness cap; limiter maximum and buffer overhead are included in shared copper design. Firmware controls are not implemented.']
    report['failures'] = failures
    output.write_text(json.dumps(report, indent=2)+'\n')
    print('Nominal module voltage budget:', module_floor, 'regulator input budget:', regulator_input_floor)
    print('Measured power net minima:', {name: row['minimum_width_mm'] for name,row in summaries.items()})
    if failures:
        raise ValueError('; '.join(failures))


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=ROOT/'evidence/R8-prototype-2026-10-05/power-path-measurements.json')
    review(parser.parse_args().output)
