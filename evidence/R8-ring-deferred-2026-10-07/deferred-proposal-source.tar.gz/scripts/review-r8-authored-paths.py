"""Reject different-net collisions in authored light fanout copper before routing."""
import argparse
import hashlib
import json
import importlib.util
from pathlib import Path
import subprocess
import sys

from shapely.geometry import LineString, Point

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('authored_manufacturing_geometry', ROOT / 'scripts/manufacturing-audit.py')
MANUFACTURING = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MANUFACTURING
SPEC.loader.exec_module(MANUFACTURING)


def collision_review(paths, circuit):
    owners = {e['source_component_id']: e['name'] for e in circuit if e['type'] == 'source_component'}
    ports = [e for e in circuit if e['type'] == 'source_port']
    features = []
    for path in paths:
        selector = path['connection'].replace(' > port.', '.').replace(' port.', '.').lstrip('.')
        reference, pin = selector.split('.')
        selected = [e for e in ports if owners[e['source_component_id']] == reference and pin in e['port_hints']]
        if len(selected) != 1:
            raise ValueError(f"Nonunique authored connection: {path['connection']}")
        net = selected[0]['subcircuit_connectivity_map_key']
        previous = None
        for index, point in enumerate(path['route']):
            if point['route_type'] == 'via':
                for layer in (point['from_layer'], point['to_layer']):
                    features.append({'connection': path['connection'], 'index': index, 'layer': layer, 'net': net, 'kind': 'via', 'hole_radius_mm': point['via_hole_diameter'] / 2, 'geometry': Point(point['x'], point['y']).buffer(point['via_diameter'] / 2, quad_segs=256)})
                previous = None
            elif point['route_type'] == 'wire':
                if previous is not None and previous['layer'] == point['layer']:
                    segment = LineString([(previous['x'], previous['y']), (point['x'], point['y'])])
                    features.append({'connection': path['connection'], 'index': index, 'layer': point['layer'], 'net': net, 'kind': 'trace', 'geometry': segment.buffer(max(previous['width'], point['width']) / 2)})
                previous = point
            else:
                raise ValueError(f"Unsupported authored route type: {point['route_type']}")
    feature_bounds = [feature['geometry'].bounds for feature in features]
    via_centers = {index: feature['geometry'].centroid for index, feature in enumerate(features) if feature['kind'] == 'via'}
    collisions = []
    copper_clearance_failures = []
    drill_clearance_failures = []
    for index, first in enumerate(features):
        for second_index, second in enumerate(features[:index]):
            if first['layer'] != second['layer']:
                continue
            if first['kind'] == second['kind'] == 'via' and first['layer'] == 'top':
                gap = via_centers[index].distance(via_centers[second_index]) - first['hole_radius_mm'] - second['hole_radius_mm']
                minimum = 0.50 if first['net'] == second['net'] else 0.55
                # Repeated representations of one same-net barrel are one drill.
                same_barrel = first['net'] == second['net'] and via_centers[index].distance(via_centers[second_index]) < 1e-8
                if not same_barrel and gap < minimum - 1e-5:
                    drill_clearance_failures.append({'first': {k: v for k, v in first.items() if k != 'geometry'}, 'second': {k: v for k, v in second.items() if k != 'geometry'}, 'gap_mm': gap, 'minimum_mm': minimum})
            if first['net'] == second['net']:
                continue
            ax, ay, bx, by = feature_bounds[index]
            cx, cy, dx, dy = feature_bounds[second_index]
            if max(cx - bx, ax - dx, 0) ** 2 + max(cy - by, ay - dy, 0) ** 2 > 0.15 ** 2:
                continue
            gap = first['geometry'].distance(second['geometry'])
            if gap < 0.15 - 1e-5:
                copper_clearance_failures.append({'first': {k: v for k, v in first.items() if k != 'geometry'}, 'second': {k: v for k, v in second.items() if k != 'geometry'}, 'gap_mm': gap, 'minimum_mm': 0.15})
            overlap = first['geometry'].intersection(second['geometry']).area
            if overlap > 1e-10:
                collisions.append({'first': {k: v for k, v in first.items() if k != 'geometry'}, 'second': {k: v for k, v in second.items() if k != 'geometry'}, 'copper_overlap_mm2': overlap})
    copper, _, _ = MANUFACTURING.make_features(circuit, trace_geometry='gerber')
    pad_collisions = []
    pad_clearance_failures = []
    same_net_drill_pad_failures = []
    for first in features:
        for second in copper:
            if second.kind not in {'smt', 'annulus'} or first['layer'] != second.layer:
                continue
            if first['net'] == second.net:
                if first['kind'] == 'via' and second.kind == 'smt':
                    hole = first['geometry'].centroid.buffer(first['hole_radius_mm'], quad_segs=256)
                    clearance = hole.distance(second.geometry)
                    # Match the independent audit's project drill-to-SMT rule.
                    if clearance < 0.2:
                        same_net_drill_pad_failures.append({'connection': first['connection'], 'route_index': first['index'], 'pad_id': second.id, 'clearance_mm': clearance, 'minimum_mm': 0.2})
                continue
            minimum = 0.35 if first['kind'] == 'via' and second.kind == 'smt' else 0.15
            clearance = first['geometry'].distance(second.geometry)
            if clearance < minimum:
                pad_clearance_failures.append({'connection': first['connection'], 'route_index': first['index'], 'layer': first['layer'], 'pad_id': second.id, 'clearance_mm': clearance, 'minimum_mm': minimum})
            overlap = first['geometry'].intersection(second.geometry).area
            if overlap > 1e-10:
                pad_collisions.append({'connection': first['connection'], 'route_index': first['index'], 'layer': first['layer'], 'pad_id': second.id, 'pad_net': second.net, 'copper_overlap_mm2': overlap})
    return {'authored_paths': len(paths), 'copper_features': len(features), 'different_net_collisions': collisions, 'different_net_copper_clearance_failures': copper_clearance_failures, 'authored_drill_clearance_failures': drill_clearance_failures, 'different_net_pad_collisions': pad_collisions, 'different_net_pad_clearance_failures': pad_clearance_failures, 'same_net_drill_pad_failures': same_net_drill_pad_failures, 'scope': 'Exported source-authored paths against each other and all native SMT/PTH lands, including interpath copper/drill spacing, configured trace/pad and via/pad clearances and same-net via drill/SMT clearances. Excludes other authored feeds and automatic copper; full native and independent final audits remain mandatory.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    paths = json.loads(subprocess.check_output(['bun', 'scripts/export-r8-authored-paths.ts'], cwd=ROOT))
    circuit_path = ROOT / 'evidence/R8-rgbw-port-2026-10-06/unrouted/circuit.json'
    report = collision_review(paths, json.loads(circuit_path.read_text()))
    report['native_netlist_sha256'] = hashlib.sha256(circuit_path.read_bytes()).hexdigest()
    report['authored_source_sha256'] = hashlib.sha256((ROOT / 'src/r8-led-power-paths.ts').read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location('authored_source_closure', ROOT / 'scripts/stage-registry.py')
    source_closure = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = source_closure
    spec.loader.exec_module(source_closure)
    report['authored_source_files_sha256'] = {
        str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(source_closure.source_closure(ROOT / 'scripts/export-r8-authored-paths.ts'))
    }
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    raise SystemExit(any(report[name] for name in ['different_net_collisions', 'different_net_copper_clearance_failures', 'authored_drill_clearance_failures', 'different_net_pad_collisions', 'different_net_pad_clearance_failures', 'same_net_drill_pad_failures']))


if __name__ == '__main__':
    main()
