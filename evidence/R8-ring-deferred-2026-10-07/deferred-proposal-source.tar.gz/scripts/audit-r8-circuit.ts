import { any_circuit_element } from "circuit-json";
import { z } from "zod";

// Electrical safety contracts from the selected module, TI and battery data.
const circuit = any_circuit_element.array().parse(
	await Bun.file(
		z
			.string()
			.min(1)
			.parse(Bun.argv[2] ?? "dist/index/circuit.json"),
	).json(),
);
const components = circuit.filter((e) => e.type === "source_component");
const ports = circuit.filter((e) => e.type === "source_port");
const nets = circuit.filter((e) => e.type === "source_net");
// Repeated supplier lands use canonical explicit internal connections. Never
// infer a shared net from a component name or matching terminal label alone.
const memberships = ports.map((port) => ({
	sourcePortId: port.source_port_id,
	connectivityKey: port.subcircuit_connectivity_map_key,
}));
const internalConnections = circuit.filter(
	(e) => e.type === "source_component_internal_connection",
);
let changed = true;
while (changed) {
	changed = false;
	for (const connection of internalConnections) {
		const group = memberships.filter((m) =>
			connection.source_port_ids.includes(m.sourcePortId),
		);
		const keys = new Set(
			group.flatMap((m) => (m.connectivityKey ? [m.connectivityKey] : [])),
		);
		if (keys.size > 1)
			throw new Error("Conflicting internally connected terminal nets");
		const key = [...keys][0];
		if (!key) continue;
		for (const membership of group) {
			if (!membership.connectivityKey) {
				membership.connectivityKey = key;
				changed = true;
			}
		}
	}
}
const contracts = [
	{
		ref: "SW2",
		mpn: "TS24CA",
		part: "C393942",
		pins: { 1: "SHUTTER", 2: "GND", 3: "GND", 4: "GND" },
	},
	{
		ref: "Q1",
		mpn: "2N7002",
		part: "C8545",
		pins: { 1: "USB5V", 2: "GND", 3: "REG_EN" },
	},
	{
		ref: "Q2",
		mpn: "2N7002",
		part: "C8545",
		pins: { 1: "TEMP_OK", 2: "GND", 3: "CHARGE_DISABLE" },
	},
	{
		ref: "SW1",
		mpn: "MSK12C02",
		part: "C431540",
		pins: { 1: "BATTERY_OK", 2: "POWER_SWITCH", 3: "GND", 4: "GND" },
	},
	{
		ref: "U4",
		mpn: "TPS3839G33DBZR",
		part: "C485802",
		pins: { 1: "GND", 2: "BATTERY_OK", 3: "VBAT" },
	},
	{
		ref: "U1",
		mpn: "ESPC3-12-N4",
		part: "C19949072",
		pins: {
			1: "RING_DATA",
			2: "RING_ENABLE",
			5: "RING_FAULT",
			3: "EN",
			6: "SHUTTER",
			7: "PAIR",
			8: "V3",
			15: "GND",
			12: "STATUS_LED",
			18: "BOOT",
			21: "UART_RX",
			22: "UART_TX",
		},
	},
	{
		ref: "U3",
		mpn: "TPS63031DSKR",
		part: "C15516",
		pins: {
			1: "V3",
			2: "INDUCTOR_L2",
			3: "GND",
			4: "INDUCTOR_L1",
			5: "VBAT",
			6: "REG_EN",
			7: "GND",
			8: "VBAT",
			9: "GND",
			10: "V3",
			11: "GND",
		},
	},
	{
		ref: "J2",
		mpn: "B2B-PH-SM4-TBT(LF)(SN)",
		part: "C265003",
		pins: { 1: "GND", 2: "VBAT", 3: "GND", 4: "GND" },
	},
	{
		ref: "J3",
		mpn: "BM03B-SRSS-TB(LF)(SN)",
		part: "C160389",
		pins: { 1: "UART_RX", 2: "GND", 3: "UART_TX", 4: "GND", 5: "GND" },
	},
	{
		ref: "L1",
		mpn: "SWPA3015S1R5NT",
		part: "C56594",
		pins: { 1: "INDUCTOR_L2", 2: "INDUCTOR_L1" },
	},
	{
		ref: "U6",
		mpn: "TPS61023DRLR",
		part: "C919459",
		pins: {
			"1": "RING_FB",
			"2": "REG_EN",
			"3": "VBAT",
			"4": "GND",
			"5": "RING_SW",
			"6": "RING_5V_RAW",
		},
	},
	{
		ref: "U7",
		mpn: "TPS2553DBVR-1",
		part: "C111738",
		pins: {
			"1": "RING_5V_RAW",
			"2": "GND",
			"3": "RING_ENABLE",
			"4": "RING_FAULT",
			"5": "RING_ILIM",
			"6": "RING_5V",
		},
	},
	{
		ref: "U8",
		mpn: "SN74AHCT1G125DBVR",
		part: "C7484",
		pins: {
			"1": "RING_OE",
			"2": "RING_DATA",
			"3": "GND",
			"4": "RING_BUFFER_OUT",
			"5": "RING_5V",
		},
	},
	{
		ref: "J4",
		mpn: "B4B-PH-SM4-TB(LF)(SN)",
		part: "C160354",
		pins: {
			"1": "GND",
			"2": "RING_5V",
			"3": "RING_DI",
			"4": "GND",
			"5": "GND",
			"6": "GND",
		},
	},
	{
		ref: "L2",
		mpn: "SWPA5040S1R0NT",
		part: "C96921",
		pins: {
			"1": "VBAT",
			"2": "RING_SW",
		},
	},
	{
		ref: "Q3",
		mpn: "2N7002",
		part: "C8545",
		pins: {
			"1": "RING_ENABLE",
			"2": "GND",
			"3": "RING_OE",
		},
	},
	{
		ref: "R14",
		mpn: "0603WAF7323T5E",
		part: "C23239",
		pins: {
			"1": "RING_5V_RAW",
			"2": "RING_FB",
		},
	},
	{
		ref: "R16",
		mpn: "0603WAF6342T5E",
		part: "C23093",
		pins: {
			"1": "RING_ILIM",
			"2": "GND",
		},
	},
	{
		ref: "R19",
		mpn: "0603WAF3300T5E",
		part: "C23138",
		pins: {
			"1": "RING_BUFFER_OUT",
			"2": "RING_DI",
		},
	},
];
for (const contract of contracts) {
	const component = components.find((e) => e.name === contract.ref);
	if (
		!component ||
		component.manufacturer_part_number !== contract.mpn ||
		!component.supplier_part_numbers?.jlcpcb?.includes(contract.part)
	) {
		throw new Error(`${contract.ref}: exact manufacturer identity mismatch`);
	}
	for (const [pin, netName] of Object.entries(contract.pins)) {
		const port = ports.find(
			(e) =>
				e.source_component_id === component.source_component_id &&
				e.pin_number === Number(pin),
		);
		const net = nets.find((e) => e.name === netName);
		if (
			!port ||
			!net?.subcircuit_connectivity_map_key ||
			memberships.find((m) => m.sourcePortId === port.source_port_id)
				?.connectivityKey !== net.subcircuit_connectivity_map_key
		) {
			throw new Error(`${contract.ref}.pin${pin}: expected ${netName}`);
		}
	}
}
const r3 = components.find((e) => e.name === "R3");
const lightResistors = [
	{ ref: "R14", resistanceOhms: 732000, pinNets: ["RING_5V_RAW", "RING_FB"] },
	{ ref: "R15", resistanceOhms: 100000, pinNets: ["RING_FB", "GND"] },
	{ ref: "R16", resistanceOhms: 63400, pinNets: ["RING_ILIM", "GND"] },
	{ ref: "R17", resistanceOhms: 100000, pinNets: ["RING_ENABLE", "GND"] },
	{ ref: "R18", resistanceOhms: 100000, pinNets: ["RING_DATA", "GND"] },
	{ ref: "R19", resistanceOhms: 330, pinNets: ["RING_BUFFER_OUT", "RING_DI"] },
	{ ref: "R20", resistanceOhms: 100000, pinNets: ["V3", "RING_FAULT"] },
	{ ref: "R21", resistanceOhms: 100000, pinNets: ["RING_5V", "RING_OE"] },
];
const lightCapacitors = [
	{ ref: "C14", capacitanceFarads: 10e-6, supply: "VBAT" },
	{ ref: "C15", capacitanceFarads: 10e-6, supply: "VBAT" },
	{ ref: "C16", capacitanceFarads: 10e-6, supply: "RING_5V_RAW" },
	{ ref: "C17", capacitanceFarads: 10e-6, supply: "RING_5V_RAW" },
	{ ref: "C18", capacitanceFarads: 10e-6, supply: "RING_5V" },
	{ ref: "C19", capacitanceFarads: 100e-9, supply: "RING_5V" },
	{ ref: "C20", capacitanceFarads: 100e-9, supply: "RING_5V_RAW" },
];
for (const resistor of lightResistors) {
	const component = components.find((e) => e.name === resistor.ref);
	if (
		component?.ftype !== "simple_resistor" ||
		component.resistance !== resistor.resistanceOhms
	)
		throw new Error(`${resistor.ref}: qualified resistance changed`);
	for (const [index, netName] of resistor.pinNets.entries()) {
		const port = ports.find(
			(e) =>
				e.source_component_id === component.source_component_id &&
				e.pin_number === index + 1,
		);
		const net = nets.find((e) => e.name === netName);
		if (
			!port ||
			!net?.subcircuit_connectivity_map_key ||
			memberships.find((m) => m.sourcePortId === port.source_port_id)
				?.connectivityKey !== net.subcircuit_connectivity_map_key
		)
			throw new Error(`${resistor.ref}.pin${index + 1}: expected ${netName}`);
	}
}
for (const capacitor of lightCapacitors) {
	const component = components.find((e) => e.name === capacitor.ref);
	if (
		component?.ftype !== "simple_capacitor" ||
		Math.abs(component.capacitance - capacitor.capacitanceFarads) > 1e-15
	)
		throw new Error(`${capacitor.ref}: qualified capacitance changed`);
	for (const [index, netName] of [capacitor.supply, "GND"].entries()) {
		const port = ports.find(
			(e) =>
				e.source_component_id === component.source_component_id &&
				e.pin_number === index + 1,
		);
		const net = nets.find((e) => e.name === netName);
		if (
			!port ||
			!net?.subcircuit_connectivity_map_key ||
			memberships.find((m) => m.sourcePortId === port.source_port_id)
				?.connectivityKey !== net.subcircuit_connectivity_map_key
		)
			throw new Error(`${capacitor.ref}.pin${index + 1}: expected ${netName}`);
	}
}
if (
	r3?.ftype !== "simple_resistor" ||
	r3.resistance !== 1000 ||
	r3.supplier_part_numbers?.jlcpcb?.[0] !== "C21190"
) {
	throw new Error("Charge setting must be the qualified exact 1k resistor");
}
const radio = components.find((e) => e.name === "U1");
if (
	!ports.find(
		(p) =>
			p.source_component_id === radio?.source_component_id &&
			p.pin_number === 8,
	)?.requires_power
) {
	throw new Error("C3 supply metadata is missing");
}
const board = circuit.find((e) => e.type === "pcb_board");
if (board?.width !== 44 || board.height !== 56 || board.num_layers !== 2) {
	throw new Error("Board envelope differs from battery/antenna qualification");
}
console.log(
	`R8 electrical contracts PASS; ${components.length} fitted references`,
);
