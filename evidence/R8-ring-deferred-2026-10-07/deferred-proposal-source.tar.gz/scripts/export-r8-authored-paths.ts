import { r8LedPowerPaths } from "../src/r8-led-power-paths";
import { r8LightSwitchPaths } from "../src/r8-light-switch-paths";
import { r8LightSignalPaths } from "../src/r8-light-signal-paths";
import { r8LightIlimPaths } from "../src/r8-light-ilim-paths";
import { r8UsbDisablePaths } from "../src/r8-usb-disable-paths";
import { r8RegEnablePaths } from "../src/r8-reg-enable-paths";
import { r8ChargeDisablePaths } from "../src/r8-charge-disable-paths";
import { r8BatteryOkPaths } from "../src/r8-battery-ok-paths";
import { r8UartRxPaths } from "../src/r8-uart-rx-paths";
import { r8BootPaths } from "../src/r8-boot-paths";
import { r8TemperatureHotPaths } from "../src/r8-temperature-hot-paths";
import { r8MosfetPaths } from "../src/r8-mosfet-paths";
import { r8PowerPaths } from "../src/r8-power-paths";
import { chargerEscapePaths } from "../src/charger-escape-paths";
import { usbEscapePaths } from "../src/usb-escape-paths";
import { temperatureEscapePaths } from "../src/temperature-escape-paths";
import { sensorEscapePaths } from "../src/sensor-escape-paths";
import { sensorCapEscapePaths } from "../src/c7-escape-paths";
import {
	r8UsbCapEscapePaths,
	r8UsbGateEscapePaths,
	r8ChargeDisablePowerEscapePaths,
} from "../src/r8-usb-pad-escape-paths";
import { r8R12EscapePaths } from "../src/r8-temp-ok-feed-path";
import { r8SupervisorVbatPaths } from "../src/r8-supervisor-vbat-paths";
import { r8SupervisorGroundPaths } from "../src/r8-supervisor-ground-paths";
import { r8RadioGroundPaths } from "../src/r8-radio-ground-paths";
import { r8RadioVccPaths } from "../src/r8-radio-vcc-paths";
import { r8RadioCapPaths } from "../src/r8-radio-cap-paths";
import { r8BulkCapPaths } from "../src/r8-bulk-cap-paths";
import { r8CcPaths } from "../src/r8-cc-paths";
import { r8ProgRoutingPaths } from "../src/r8-prog-routing-paths";
import { r8ProgPaths } from "../src/r8-prog-paths";
import { r8BatteryCapEscapePaths } from "../src/r8-battery-cap-paths";
import { r8ShutterGroundPaths } from "../src/r8-shutter-ground-paths";
import { r8ResetPaths } from "../src/r8-reset-paths";
import { r8ColdGroundPaths } from "../src/r8-cold-ground-paths";
import { r8ConnectorPaths } from "../src/r8-connector-paths";
import { r8BatteryFeedPaths } from "../src/r8-battery-feed-paths";

// Source geometry only. This is an early collision check, not routed evidence.
console.log(
	JSON.stringify([
		...r8LedPowerPaths,
		...r8LightSwitchPaths,
		...r8LightSignalPaths,
		...r8LightIlimPaths,
		...r8UsbDisablePaths,
		...r8RegEnablePaths,
		...r8ChargeDisablePaths,
		...r8BatteryOkPaths,
		...r8UartRxPaths,
		...r8BootPaths,
		...r8TemperatureHotPaths,
		...r8MosfetPaths,
		...r8PowerPaths,
		...chargerEscapePaths,
		...usbEscapePaths,
		...temperatureEscapePaths,
		...sensorEscapePaths,
		...sensorCapEscapePaths,
		...r8UsbCapEscapePaths,
		...r8UsbGateEscapePaths,
		...r8ChargeDisablePowerEscapePaths,
		...r8R12EscapePaths,
		...r8SupervisorVbatPaths,
		...r8SupervisorGroundPaths,
		...r8RadioGroundPaths,
		...r8RadioVccPaths,
		...r8RadioCapPaths,
		...r8BulkCapPaths,
		...r8CcPaths,
		...r8ProgRoutingPaths,
		...r8ProgPaths,
		...r8BatteryCapEscapePaths,
		...r8ShutterGroundPaths,
		...r8ResetPaths,
		...r8ColdGroundPaths,
		...r8ConnectorPaths,
		...r8BatteryFeedPaths,
	]),
);
