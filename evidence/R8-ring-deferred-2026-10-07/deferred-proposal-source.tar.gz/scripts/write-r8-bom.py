"""Derive fitted R8 references from generated source identities and dated sourcing.

Does not infer sourcing success for missing or mismatched supplier identities.
"""
import csv
import json
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence/R8-rgbw-port-2026-10-06'

def verify_available_part(supplier, quantity):
    if not supplier['exact_identity_verified'] or not supplier['eligible_smt_listing']:
        raise ValueError(f'{supplier["lcsc"]}: exact identity and SMT eligibility required')
    available = supplier['inventory_fields']['canPresaleNumber']
    if not isinstance(available, int) or available < quantity:
        raise ValueError(f'{supplier["lcsc"]}: insufficient Available Order Qty for one prototype')
    return available

def write_bom(evidence_directory=EVIDENCE):
    evidence_directory=evidence_directory.resolve()
    circuit = json.loads((ROOT / 'dist/index/circuit.json').read_text())
    sourcing = json.loads((evidence_directory / 'sourcing-check.json').read_text())
    verified = {p['lcsc']: p for p in sourcing['parts']}
    old = {p['lcsc']: p for p in json.loads((ROOT / 'baselines/r7/bom.json').read_text())['parts']}
    groups = {}
    for component in circuit:
        if component['type'] != 'source_component':
            continue
        number, = component['supplier_part_numbers']['jlcpcb']
        group = groups.setdefault(number, [])
        group.append(component)
    parts = []
    for number, components in groups.items():
        supplier = verified[number]
        available = verify_available_part(supplier, len(components))
        mpns = {c['manufacturer_part_number'] for c in components}
        if mpns != {supplier['mpn']}:
            raise ValueError(f'{number}: supplier identity mismatch')
        sample = components[0]
        part = dict(old.get(number, {}))
        part.update(manufacturer=supplier.get('manufacturer',part.get('manufacturer')), reference_designators=[c['name'] for c in components],
                    quantity=len(components),
                    value=sample.get('display_capacitance') or sample.get('display_resistance') or sample.get('display_inductance') or supplier['mpn'],
                    manufacturer_part_number=supplier['mpn'], package=supplier['package'], lcsc=number,
                    assembly_category='Basic' if supplier['assembly_fields']['componentLibraryType']=='base' else 'Extended',
                    observed_stock=available, observed_available=available,
                    observed_headline_stock=supplier['inventory_fields']['overseasStockCount'],
                    availability_quantity_basis='One prototype, before supplier attrition/allocations',
                    five_board_parts_in_stock=available >= 5*len(components),
                    stock_allocation_confirmed=False,
                    availability_check_date=sourcing['checked_date'],
                    source_link=supplier['listing_url'],
                    lcsc_link=f'https://www.lcsc.com/product-detail/{number}.html',
                    qualification=f'Engineering prototype; see {evidence_directory.relative_to(ROOT)}/REVIEW.md and current validation; physical tests pending')
        parts.append(part)
    bom = {'revision':'R8-ESP32-C3-compact-'+json.loads((ROOT/'package.json').read_text())['version'],
           'status':f'{sum(p["quantity"] for p in parts)} fitted references / {len(parts)} exact supplier identities; engineering prototype; hardware unvalidated',
           'parts':parts}
    (ROOT / 'bom.json').write_text(json.dumps(bom, indent=2)+'\n')
    fields=['reference_designators','quantity','value','manufacturer_part_number','package','lcsc','assembly_category','observed_stock','availability_check_date','source_link','qualification']
    with (ROOT / 'BOM.csv').open('w',newline='') as output:
        writer=csv.DictWriter(output,fieldnames=fields,extrasaction='ignore',lineterminator='\n')
        writer.writeheader()
        for part in parts:
            writer.writerow({**part,'reference_designators':','.join(part['reference_designators'])})
    shortages=[p['lcsc'] for p in parts if not p['five_board_parts_in_stock']]
    (ROOT / 'BOM.md').write_text('# R8 ESP32-C3 fitted BOM\n\n'+bom['status']+'\n\nDerived from generated Circuit JSON and dated exact-C-number sourcing. Available Order Qty is distinct from headline stock; stock is not reserved and assembler attrition is not allocated. Supplier search prices are quantity-dependent and are not an assembly quote. External protected1S battery (>=2A continuous, verifiedPH harness) and compatible350mA5V RGBW ring are outside the PCBA BOM and remain unqualified. The old1A ASR00012 pack is inadequate for the light addition.\n\nFive-board parts unavailable from direct stock: '+(', '.join(shortages) if shortages else 'none observed')+'.\n\n| References | MPN | JLCPCB | Quantity | Available Order Qty |\n|---|---|---|---:|---:|\n'+''.join(f'| {", ".join(p["reference_designators"])} | {p["manufacturer_part_number"]} | {p["lcsc"]} | {p["quantity"]} | {p["observed_stock"]} |\n' for p in parts))
    print(bom['status'])

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--evidence',type=Path,default=EVIDENCE)
    write_bom(parser.parse_args().evidence)
