"""Run the pinned native CLI on a complete, byte-verified board source closure.

Invoke through cloud/run-heavy.py after the applicable qualification gates.
The clean task directory avoids loading archived evidence/SDK sources into
the CLI's whole-entrypoint-directory VFS. It changes no circuit or toolchain.
"""
import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run_native(options):
    stage = options.stage_dir.resolve()
    stage.relative_to((ROOT / '.codex/runtime').resolve())
    if stage.exists():
        raise ValueError('Inspect existing native build directory; never replace it')
    if not options.native_args or options.native_args[0] not in {'build', 'check'}:
        raise ValueError('Supply native build or source-check arguments after --')
    if options.copy_build_output and options.native_args[0] != 'build':
        raise ValueError('Output copying requires the native build command')
    specification = importlib.util.spec_from_file_location('r8_registry_sources', ROOT / 'scripts/stage-registry.py')
    registry = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = registry
    specification.loader.exec_module(registry)
    sources = registry.source_closure(ROOT / 'index.circuit.tsx')
    sources.update(ROOT / name for name in ['package.json', 'bun.lock', 'tsconfig.json', 'tscircuit.config.json'])
    package = json.loads((ROOT / 'package.json').read_text())
    for section in ['dependencies', 'devDependencies', 'overrides']:
        for dependency in package.get(section, {}).values():
            if dependency.startswith('file:'):
                sources.add(registry.resolve_import(dependency[5:], ROOT))
    stage.mkdir(parents=True)
    hashes = {}
    for source in sorted(sources):
        relative = source.relative_to(ROOT)
        target = stage / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise ValueError(f'Native source copy mismatch: {relative}')
        hashes[str(relative)] = digest
    (stage / 'node_modules').symlink_to(ROOT / 'node_modules', target_is_directory=True)
    orientation_cache_hashes = {}
    if options.orientation_cache:
        cache_source = options.orientation_cache.resolve()
        cache_source.relative_to(ROOT)
        manifest_path = cache_source.with_name(cache_source.name + '-manifest.json')
        manifest = json.loads(manifest_path.read_text())
        cache_target = stage / '.tscircuit/cache'
        cache_target.mkdir(parents=True)
        for name, digest in manifest['files_sha256'].items():
            if Path(name).name != name:
                raise ValueError('Native orientation cache must use flat filenames')
            source = cache_source / name
            if hashlib.sha256(source.read_bytes()).hexdigest() != digest:
                raise ValueError(f'Native orientation cache input mismatch: {name}')
            cached = json.loads(source.read_text())
            if set(cached) != {'pin1_location', 'pin1_polarity'}:
                raise ValueError(f'Input is not a native orientation cache entry: {name}')
            if any(value is not None and not isinstance(value, str) for value in cached.values()):
                raise ValueError(f'Invalid native orientation cache data: {name}')
            shutil.copy2(source, cache_target / name)
            orientation_cache_hashes[name] = digest
    command = ['bun', '--smol', str(ROOT / 'node_modules/tscircuit/cli.mjs'), *options.native_args]
    print(json.dumps({'native_cwd': str(stage), 'native_command': command,
                      'source_sha256': hashes, 'same_locked_dependencies': True,
                      'native_orientation_cache_sha256': orientation_cache_hashes}, indent=2), flush=True)
    environment = os.environ.copy()
    environment['PATH'] = str(ROOT / '.codex/runtime/node_modules/.bin') + ':' + str(ROOT / 'node_modules/.bin') + ':' + environment['PATH']
    environment.setdefault('XDG_CONFIG_HOME', str(ROOT / '.codex/runtime/config'))
    code = subprocess.run(command, cwd=stage, env=environment).returncode
    for relative, digest in hashes.items():
        if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != digest:
            raise ValueError(f'Root source changed during native run: {relative}')
    if options.copy_build_output:
        output = stage / 'dist/index'
        if not (output / 'circuit.json').is_file():
            raise ValueError('Native build did not produce fresh Circuit JSON')
        for source in output.rglob('*'):
            if source.is_file():
                target = ROOT / 'dist/index' / source.relative_to(output)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
    # A failed native candidate remains a failure, even if copied for review.
    return code if code >= 0 else 128 - code


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage-dir', type=Path, required=True)
    parser.add_argument('--copy-build-output', action='store_true')
    parser.add_argument('--orientation-cache', type=Path,
                        help='Retained native supplier-analysis cache directory with a SHA256 manifest')
    parser.add_argument('native_args', nargs=argparse.REMAINDER)
    arguments = parser.parse_args()
    if arguments.native_args[:1] == ['--']:
        arguments.native_args = arguments.native_args[1:]
    raise SystemExit(run_native(arguments))
