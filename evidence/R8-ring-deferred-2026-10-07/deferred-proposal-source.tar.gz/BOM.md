# R8 ESP32-C3 fitted BOM

65 fitted references / 33 exact supplier identities; engineering prototype; hardware unvalidated

Derived from generated Circuit JSON and dated exact-C-number sourcing. Available Order Qty is distinct from headline stock; stock is not reserved and assembler attrition is not allocated. Supplier search prices are quantity-dependent and are not an assembly quote. External protected1S battery (>=2A continuous, verifiedPH harness) and compatible350mA5V RGBW ring are outside the PCBA BOM and remain unqualified. The old1A ASR00012 pack is inadequate for the light addition.

Five-board parts unavailable from direct stock: C19949072.

| References | MPN | JLCPCB | Quantity | Available Order Qty |
|---|---|---|---:|---:|
| J1 | USB4215-03-A | C37616412 | 1 | 22 |
| R2, R1 | 0603WAF5101T5E | C23186 | 2 | 24103847 |
| U2 | BQ25185DLHR | C19725033 | 1 | 3518 |
| R3, R4, R7 | 0603WAF1001T5E | C21190 | 3 | 15798832 |
| C2, C1 | CL10A475KO8NNNC | C19666 | 2 | 1822745 |
| LED1, LED2 | KT-0603R | C2286 | 2 | 4172294 |
| J2 | B2B-PH-SM4-TBT(LF)(SN) | C265003 | 1 | 6527 |
| R8 | 0603WAF1303T5E | C22795 | 1 | 534375 |
| R9 | 0603WAF1002T5E | C25804 | 1 | 21567582 |
| C8, C10, C11, C12, C3, C4, C14, C15, C16, C17, C18 | CL21A106KAYNNNE | C15850 | 11 | 3444652 |
| C9 | TCC0603COG470J500CT | C282505 | 1 | 7987 |
| U1 | ESPC3-12-N4 | C19949072 | 1 | 3 |
| C5, C13, C6, C7, C20, C19 | CC0603KRX7R9BB104 | C14663 | 6 | 48408615 |
| SW2 | TS24CA | C393942 | 1 | 401276 |
| SW3, SW4, SW5 | TS-1088-AR02016 | C720477 | 3 | 716724 |
| J3 | BM03B-SRSS-TB(LF)(SN) | C160389 | 1 | 31596 |
| SW1 | MSK12C02 | C431540 | 1 | 185714 |
| R5, R6, R12, R13, R15, R17, R20, R18, R21 | 0603WAF1003T5E | C25803 | 9 | 20059693 |
| Q1, Q2, Q3 | 2N7002 | C8545 | 3 | 1425848 |
| U3 | TPS63031DSKR | C15516 | 1 | 13089 |
| L1 | SWPA3015S1R5NT | C56594 | 1 | 4041 |
| U4 | TPS3839G33DBZR | C485802 | 1 | 3360 |
| U5 | TMP390A2DRLR | C5219772 | 1 | 37521 |
| R10 | 0603WAF1621T5E | C22844 | 1 | 26869 |
| R11 | 0603WAF1872T5E | C22893 | 1 | 121574 |
| U6 | TPS61023DRLR | C919459 | 1 | 54077 |
| L2 | SWPA5040S1R0NT | C96921 | 1 | 595 |
| R14 | 0603WAF7323T5E | C23239 | 1 | 20280 |
| U7 | TPS2553DBVR-1 | C111738 | 1 | 13342 |
| R16 | 0603WAF6342T5E | C23093 | 1 | 32464 |
| U8 | SN74AHCT1G125DBVR | C7484 | 1 | 37943 |
| R19 | 0603WAF3300T5E | C23138 | 1 | 2774149 |
| J4 | B4B-PH-SM4-TB(LF)(SN) | C160354 | 1 | 30392 |
