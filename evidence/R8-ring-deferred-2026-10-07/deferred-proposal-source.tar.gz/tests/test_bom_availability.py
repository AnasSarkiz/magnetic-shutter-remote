import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('bom_availability',Path(__file__).resolve().parents[1]/'scripts/write-r8-bom.py')
bom=importlib.util.module_from_spec(spec)
spec.loader.exec_module(bom)


class BomAvailabilityTest(unittest.TestCase):
    def test_headline_stock_cannot_replace_available_order_quantity(self):
        supplier={'lcsc':'C19949072','exact_identity_verified':True,'eligible_smt_listing':True,
                  'inventory_fields':{'canPresaleNumber':3,'overseasStockCount':66}}
        self.assertEqual(bom.verify_available_part(supplier,1),3)
        with self.assertRaisesRegex(ValueError,'insufficient Available Order Qty'):
            bom.verify_available_part(supplier,5)

    def test_unknown_identity_and_ineligible_assembly_are_rejected(self):
        supplier={'lcsc':'C19949072','exact_identity_verified':False,'eligible_smt_listing':True,
                  'inventory_fields':{'canPresaleNumber':3}}
        with self.assertRaisesRegex(ValueError,'exact identity and SMT'):
            bom.verify_available_part(supplier,1)
        supplier.update(exact_identity_verified=True,eligible_smt_listing=False)
        with self.assertRaisesRegex(ValueError,'exact identity and SMT'):
            bom.verify_available_part(supplier,1)
