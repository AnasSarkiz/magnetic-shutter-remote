"""Detect switching-ripple width failures missed by a DC-only check."""
import importlib.util
import math
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('power_width_review',ROOT/'scripts/review-r8-power.py')
REVIEW = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = REVIEW
SPEC.loader.exec_module(REVIEW)


class PowerWidthBudgetTest(unittest.TestCase):
    def test_buffer_voltage_accounts_for_limiter_and_hot_copper(self):
        result = REVIEW.light_buffer_voltage_budget({'raw_trace_resistance_20c_ohm':.01,
            'buffer_trace_resistance_20c_ohm':.02})
        self.assertTrue(result['within_static_voltage_budget'])
        self.assertLess(result['buffer_supply_floor_budget_v'],4.726742-.469342*.135)
        excessive = REVIEW.light_buffer_voltage_budget({'raw_trace_resistance_20c_ohm':.4,
            'buffer_trace_resistance_20c_ohm':.2})
        self.assertFalse(excessive['within_static_voltage_budget'])

    def test_shared_feed_requires_combined_current_not_each_branch(self):
        operating = REVIEW.shared_battery_budget({'common_resistance_20c_ohm':.003,
            'radio_resistance_20c_ohm':.040,'light_resistance_20c_ohm':.030,'light_output_amps':.469342})
        capacity = lambda width: .048*10**.44*((width/.0254)*(.035/.0254))**.725
        # The radio and light branches each fit 0.4mm, but their shared feed
        # does not. A nominal-per-net or independent-load test misses this.
        self.assertLess(operating['radio_input_amps'],capacity(.4))
        self.assertLess(operating['light_input_amps'],capacity(.4))
        self.assertGreater(operating['shared_battery_amps'],capacity(.4))
        self.assertLess(operating['shared_battery_amps'],capacity(.9))
        self.assertLess(operating['radio_input_floor_v'],3.003)

    def test_light_dc_neck_can_fail_pulsed_current(self):
        operating = REVIEW.shared_battery_budget({'common_resistance_20c_ohm':.003,
            'radio_resistance_20c_ohm':.040,'light_resistance_20c_ohm':.030,'light_output_amps':.469342})
        switching = REVIEW.light_switching_current_budget(operating)
        capacity = lambda width: .048*10**.44*((width/.0254)*(.035/.0254))**.725
        self.assertLess(operating['light_input_amps'],capacity(.35))
        self.assertGreater(switching['inductor_rms_amps'],capacity(.35))
        self.assertLess(switching['inductor_rms_amps'],capacity(.39))
        self.assertFalse(switching['frequency_is_guaranteed_minimum'])
        self.assertAlmostEqual(switching['minimum_inductance_h'],.7e-6)

    def test_old_neck_passes_dc_but_fails_switching_rms(self):
        switching = REVIEW.switching_current_budget({'input_floor_v':2.971566710888736,
                                                      'input_amps':0.7430844449524722})
        old_capacity = 0.048*10**0.44*((0.2/0.0254)*(0.035/0.0254))**0.725
        self.assertGreater(old_capacity,0.7430844449524722)
        self.assertGreater(switching['rms_design_amps'],old_capacity)
        paths = {'L1':{'ipc2221_external_estimate_10c_amps':old_capacity}}
        self.assertEqual(len(REVIEW.width_budget_failures(paths,{'L1':switching['rms_design_amps']})),1)
        paths['L1']['ipc2221_external_estimate_10c_amps'] = 0.048*10**0.44*((0.3/0.0254)*(0.035/0.0254))**0.725
        self.assertEqual(REVIEW.width_budget_failures(paths,{'L1':switching['rms_design_amps']}),[])

    def test_ripple_uses_minimum_frequency_and_inductance(self):
        result = REVIEW.switching_current_budget({'input_floor_v':3,'input_amps':0.74})
        # Exact manufacturer row is 1.5uH +/-30% (minimum1.05uH).
        self.assertAlmostEqual(result['minimum_inductance_h'],1.05e-6,delta=1e-12)
        ripple = 3*(1-3/3.533)/(2_200_000*1.05e-6)
        self.assertAlmostEqual(result['boost_ripple_peak_to_peak_amps'],ripple)
        self.assertAlmostEqual(result['rms_design_amps'],math.hypot(0.74,ripple/math.sqrt(12)))
        self.assertAlmostEqual(result['peak_design_amps'],0.74+ripple/2)

    def test_saturation_rating_requires_recommended_headroom(self):
        # A2.0A peak is below the2.3A rating but needs2.4A with TI margin.
        failures = REVIEW.inductor_rating_failures({'rms_design_amps':1.0,'peak_design_amps':2.0})
        self.assertEqual(len(failures),1)
        self.assertIn('20%',failures[0])
        self.assertEqual(REVIEW.inductor_rating_failures({'rms_design_amps':1.0,'peak_design_amps':1.8}),[])

    def test_rms_rating_is_checked_independently_of_peak_headroom(self):
        failures = REVIEW.inductor_rating_failures({'rms_design_amps':1.8,'peak_design_amps':1.8})
        self.assertEqual(len(failures),1)
        self.assertIn('RMS',failures[0])
