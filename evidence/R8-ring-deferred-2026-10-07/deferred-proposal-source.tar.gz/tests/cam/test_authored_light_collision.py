"""Actual archived source via crossing must fail the early geometry check."""
import importlib.util
import json
from pathlib import Path
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('authored_paths_review', ROOT / 'scripts/review-r8-authored-paths.py')
REVIEW = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(REVIEW)


class AuthoredLightCollisionTest(unittest.TestCase):
    def review_source(self, module):
        script = f'import {{r8LedPowerPaths}} from "{module}"; console.log(JSON.stringify(r8LedPowerPaths))'
        paths = json.loads(subprocess.check_output(['bun', '-e', script], cwd=ROOT))
        circuit = json.loads((ROOT / 'evidence/R8-rgbw-port-2026-10-06/unrouted/circuit.json').read_text())
        return REVIEW.collision_review(paths, circuit)

    def test_actual_route11_enable_feedback_overlap_is_rejected(self):
        report = self.review_source('./evidence/R8-rgbw-port-2026-10-06/route11/source/src/r8-led-power-paths.ts')
        self.assertTrue(any({e['first']['connection'], e['second']['connection']} == {'U6.pin2', 'R15.pin1'} for e in report['different_net_collisions']))

    def test_corrected_authored_light_paths_have_no_cross_net_collisions(self):
        report = self.review_source('./src/r8-led-power-paths.ts')
        self.assertEqual(report['different_net_collisions'], [])

    def test_combined_current_boost_and_switch_paths_do_not_cross_nets(self):
        paths = json.loads(subprocess.check_output(['bun', 'scripts/export-r8-authored-paths.ts'], cwd=ROOT))
        circuit = json.loads((ROOT / 'evidence/R8-rgbw-port-2026-10-06/unrouted/circuit.json').read_text())
        report = REVIEW.collision_review(paths, circuit)
        self.assertEqual(report['different_net_collisions'], [])
        self.assertEqual(report['different_net_pad_collisions'], [])
        self.assertEqual(report['different_net_pad_clearance_failures'], [])
        self.assertEqual(report['same_net_drill_pad_failures'], [])
        self.assertEqual(report['different_net_copper_clearance_failures'], [])
        self.assertEqual(report['authored_drill_clearance_failures'], [])

    def test_retained_charger_wire_crossing_new_buffer_pads_is_rejected(self):
        script = 'import {r8ChargeDisablePaths} from "./evidence/R8-rgbw-port-2026-10-06/route26/source/src/r8-charge-disable-paths.ts"; console.log(JSON.stringify(r8ChargeDisablePaths))'
        paths = json.loads(subprocess.check_output(['bun', '-e', script], cwd=ROOT))
        circuit = json.loads((ROOT / 'evidence/R8-rgbw-port-2026-10-06/unrouted/circuit.json').read_text())
        report = REVIEW.collision_review(paths, circuit)
        collided = {entry['pad_id'] for entry in report['different_net_pad_collisions']}
        pads = {entry['pcb_smtpad_id']: entry for entry in circuit if entry['type'] == 'pcb_smtpad'}
        ports = {entry['pcb_port_id']: entry for entry in circuit if entry['type'] == 'pcb_port'}
        source_ports = {entry['source_port_id']: entry for entry in circuit if entry['type'] == 'source_port'}
        components = {entry['source_component_id']: entry['name'] for entry in circuit if entry['type'] == 'source_component'}
        affected = set()
        for pad_id in collided:
            source = source_ports[ports[pads[pad_id]['pcb_port_id']]['source_port_id']]
            if components[source['source_component_id']] == 'U8':
                affected.update(source['port_hints'])
        self.assertTrue({'pin4', 'pin5'}.issubset(affected))

    def test_retained_supervisor_via_touching_current_limit_pad_is_rejected(self):
        script = 'import {r8BatteryOkPaths} from "./evidence/R8-rgbw-port-2026-10-06/route26/source/src/r8-battery-ok-paths.ts"; console.log(JSON.stringify(r8BatteryOkPaths))'
        paths = json.loads(subprocess.check_output(['bun', '-e', script], cwd=ROOT))
        circuit = json.loads((ROOT / 'evidence/R8-rgbw-port-2026-10-06/unrouted/circuit.json').read_text())
        report = REVIEW.collision_review(paths, circuit)
        components = {entry['source_component_id']: entry['name'] for entry in circuit if entry['type'] == 'source_component'}
        by_id = {entry.get(entry['type'] + '_id'): entry for entry in circuit}
        affected = set()
        for entry in report['different_net_pad_collisions']:
            source = by_id[by_id[by_id[entry['pad_id']]['pcb_port_id']]['source_port_id']]
            affected.add(components[source['source_component_id']])
        self.assertIn('R16', affected)

    def test_archived_charger_ground_escape_spacing_is_rejected(self):
        script = 'import {chargerEscapePaths} from "./evidence/R8-rgbw-port-2026-10-06/unrouted-native63/src/charger-escape-paths.ts"; console.log(JSON.stringify(chargerEscapePaths))'
        paths = json.loads(subprocess.check_output(['bun', '-e', script], cwd=ROOT))
        circuit = json.loads((ROOT / 'evidence/R8-rgbw-port-2026-10-06/unrouted/circuit.json').read_text())
        report = REVIEW.collision_review(paths, circuit)
        self.assertTrue(any({entry['first']['connection'], entry['second']['connection']} == {'U2.pin11', 'U2.pin1'} for entry in report['different_net_copper_clearance_failures']))

    def test_archived_charger_via_drill_spacing_is_rejected(self):
        script = 'import {chargerEscapePaths} from "./evidence/R8-rgbw-port-2026-10-06/unrouted-native63/src/charger-escape-paths.ts"; console.log(JSON.stringify(chargerEscapePaths))'
        paths = json.loads(subprocess.check_output(['bun', '-e', script], cwd=ROOT))
        circuit = json.loads((ROOT / 'evidence/R8-rgbw-port-2026-10-06/unrouted/circuit.json').read_text())
        report = REVIEW.collision_review(paths, circuit)
        self.assertTrue(any({entry['first']['connection'], entry['second']['connection']} == {'U2.pin2', 'U2.pin3'} for entry in report['authored_drill_clearance_failures']))
