"""Reject connected but undersized or isolated connector ground escapes."""
import importlib.util
from pathlib import Path
import sys
import unittest
from shapely.geometry import box
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[2]
SPEC=importlib.util.spec_from_file_location('ground_power_review',ROOT/'scripts/review-r8-power.py')
REVIEW=importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name]=REVIEW
SPEC.loader.exec_module(REVIEW)

class GroundAttachmentTest(unittest.TestCase):
    def test_continuity_alone_does_not_qualify_a_narrow_bridge(self):
        pad=box(-.5,-1,.5,1)
        pour=box(2,-2,6,2)
        narrow=box(.5,-.1,2,.1)
        metal=unary_union([pad,narrow,pour])
        self.assertEqual(metal.geom_type,'Polygon')
        self.assertEqual(REVIEW.supported_ground_corridors({'start':(0,0),
            'ground_geometry':metal,'pour_geometry':pour,'width_mm':.9,'length_mm':3}),[])
        wide=box(.4,-.5,2.1,.5)
        paths=REVIEW.supported_ground_corridors({'start':(0,0),
            'ground_geometry':unary_union([pad,wide,pour]),'pour_geometry':pour,'width_mm':.9,'length_mm':3})
        self.assertEqual(len(paths),1)
        self.assertEqual(paths[0]['end_mm'],[3,0])

    def test_large_isolated_pad_is_not_a_ground_plane_connection(self):
        metal=box(-4,-4,4,4)
        self.assertEqual(REVIEW.supported_ground_corridors({'start':(0,0),
            'ground_geometry':metal,'pour_geometry':box(5,5,8,8),'width_mm':.9,'length_mm':3}),[])
