"""Reject an actual candidate whose data driver remains powered on latch-off."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('light_buffer_review',ROOT/'scripts/review-r8-power.py')
REVIEW = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = REVIEW
SPEC.loader.exec_module(REVIEW)


class LightBufferDomainTest(unittest.TestCase):
    def test_real_unswitched_candidate_is_rejected(self):
        candidate = json.loads((ROOT/'evidence/R8-rgbw-port-2026-10-06/unrouted-enable14-qualified/circuit.json').read_text())
        with self.assertRaisesRegex(ValueError,'latch-off supply'):
            REVIEW.light_buffer_power_domain(candidate)

    def test_current_native_output_shares_accessory_latch_off_supply(self):
        current = json.loads((ROOT/'evidence/R8-rgbw-port-2026-10-06/unrouted/circuit.json').read_text())
        result = REVIEW.light_buffer_power_domain(current)
        self.assertEqual(len(result['same_switched_power_terminals']),4)

