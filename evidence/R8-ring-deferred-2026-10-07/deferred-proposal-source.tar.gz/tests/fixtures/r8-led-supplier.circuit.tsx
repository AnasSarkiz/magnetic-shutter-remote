import { TPS61023DRLR } from "../../imports/r8-led-port/TPS61023DRLR/TPS61023DRLR";
import { TPS2553DBVR_1 } from "../../imports/r8-led-port/TPS2553DBVR_1/TPS2553DBVR_1";
import { SN74AHCT1G125DBVR } from "../../imports/r8-led-port/SN74AHCT1G125DBVR/SN74AHCT1G125DBVR";
import { SWPA5040S1R0NT } from "../../imports/r8-led-port/SWPA5040S1R0NT/SWPA5040S1R0NT";
import { B2B_PH_SM4_TBT_LF__SN_ } from "../../imports/r8-led-port/B2B_PH_SM4_TBT_LF__SN_/B2B_PH_SM4_TBT_LF__SN_";
import { B4B_PH_SM4_TB_LF__SN_ } from "../../imports/r8-led-port/B4B_PH_SM4_TB_LF__SN_/B4B_PH_SM4_TB_LF__SN_";
import { A_0603WAF7323T5E } from "../../imports/r8-led-port/A_0603WAF7323T5E/A_0603WAF7323T5E";
import { A_0603WAF6342T5E } from "../../imports/r8-led-port/A_0603WAF6342T5E/A_0603WAF6342T5E";
import { A_0603WAF3300T5E } from "../../imports/r8-led-port/A_0603WAF3300T5E/A_0603WAF3300T5E";

// Supplier geometry reference only: every package uses its native, unrotated
// frame. This fixture is deliberately unrouted and is not a functional board.
export default function R8LedSupplierReference() {
	return (
		<board width="60mm" height="60mm" routingDisabled>
			<net name="L2_A" /><net name="L2_B" />
			<net name="R14_A" /><net name="R14_B" />
			<net name="R16_A" /><net name="R16_B" />
			<net name="R19_A" /><net name="R19_B" />
			<schematicsheet name="SupplierReference" sheetIndex={0} sheetSize="A4">
				<TPS61023DRLR
					name="U6"
					pcbX={-18}
					pcbY={18}
					schX={-10}
					schY={5}
					noConnect={["pin1", "pin2", "pin3", "pin4", "pin5", "pin6"]}
				/>
				<TPS2553DBVR_1
					name="U7"
					pcbX={18}
					pcbY={18}
					schX={10}
					schY={5}
					noConnect={["pin1", "pin2", "pin3", "pin4", "pin5", "pin6"]}
				/>
				<SN74AHCT1G125DBVR
					name="U8"
					pcbX={18}
					pcbY={0}
					schX={10}
					schY={0}
					noConnect={["pin1", "pin2", "pin3", "pin4", "pin5"]}
				/>
				<SWPA5040S1R0NT
					name="L2"
					pcbX={-18}
					pcbY={0}
					schX={-10}
					schY={0}
					connections={{pin1:"net.L2_A",pin2:"net.L2_B"}}
				/>
				<B2B_PH_SM4_TBT_LF__SN_
					name="J2"
					pcbX={0}
					pcbY={0}
					schX={0}
					schY={0}
					noConnect={["pin1", "pin2", "pin3", "pin4"]}
				/>
				<B4B_PH_SM4_TB_LF__SN_
					name="J4"
					pcbX={0}
					pcbY={18}
					schX={0}
					schY={5}
					noConnect={["pin1", "pin2", "pin3", "pin4", "pin5", "pin6"]}
				/>
				<A_0603WAF7323T5E
					name="R14"
					pcbX={-18}
					pcbY={-18}
					schX={-10}
					schY={-5}
					connections={{pin1:"net.R14_A",pin2:"net.R14_B"}}
				/>
				<A_0603WAF6342T5E
					name="R16"
					pcbX={0}
					pcbY={-18}
					schX={0}
					schY={-5}
					connections={{pin1:"net.R16_A",pin2:"net.R16_B"}}
				/>
				<A_0603WAF3300T5E
					name="R19"
					pcbX={18}
					pcbY={-18}
					schX={10}
					schY={-5}
					connections={{pin1:"net.R19_A",pin2:"net.R19_B"}}
				/>
			</schematicsheet>
		</board>
	);
}
