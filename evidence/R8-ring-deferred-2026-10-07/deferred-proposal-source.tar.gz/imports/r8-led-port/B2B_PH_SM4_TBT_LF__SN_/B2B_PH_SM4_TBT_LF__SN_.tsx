import objPath from "./B2B_PH_SM4_TBT_LF__SN_.obj"
import stepPath from "./B2B_PH_SM4_TBT_LF__SN_.step"
import type { ConnectorProps } from "@tscircuit/props"

const pinLabels = {
  pin1: ["pin1"],
  pin2: ["pin2"],
  pin3: ["pin3"],
  pin4: ["pin4"]
} as const

export const B2B_PH_SM4_TBT_LF__SN_ = (props: ConnectorProps) => {
  return (
    <connector
      pinLabels={pinLabels}
      supplierPartNumbers={{
  "jlcpcb": [
    "C265003"
  ]
}}
      manufacturerPartNumber="B2B-PH-SM4-TBT(LF)(SN)"
      footprint={<footprint>
        <smtpad portHints={["pin1"]} pcbX="-1.000125mm" pcbY="-0.49996725mm" width="0.999998mm" height="5.499989mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
<smtpad portHints={["pin2"]} pcbX="0.999871mm" pcbY="-0.49996725mm" width="0.999998mm" height="5.499989mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
<smtpad portHints={["pin3"]} pcbX="3.499993mm" pcbY="1.74996475mm" width="1.999996mm" height="2.999994mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
<smtpad portHints={["pin4"]} pcbX="-3.499993mm" pcbY="1.74996475mm" width="1.999996mm" height="2.999994mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
<silkscreenpath route={[{"x":-4.000119000000041,"y":4.25001055000007},{"x":3.999864999999886,"y":4.25001055000007}]} />
<silkscreenpath route={[{"x":-4.000119000000041,"y":-0.7500048499999821},{"x":-1.7312640000001238,"y":-0.7500048499999821}]} />
<silkscreenpath route={[{"x":-0.2689860000000408,"y":-0.7500048499999821},{"x":0.26873199999999997,"y":-0.7500048499999821}]} />
<silkscreenpath route={[{"x":1.7310099999999693,"y":-0.7500048499999821},{"x":3.999864999999886,"y":-0.7500048499999821}]} />
<silkscreenpath route={[{"x":3.999864999999886,"y":-0.7500048499999821},{"x":3.999864999999886,"y":0.018878549999953975}]} />
<silkscreenpath route={[{"x":3.999864999999886,"y":3.4811525499999334},{"x":3.999864999999886,"y":4.25001055000007}]} />
<silkscreenpath route={[{"x":-4.000119000000041,"y":4.25001055000007},{"x":-4.000119000000041,"y":3.4811525499999334}]} />
<silkscreenpath route={[{"x":-4.000119000000041,"y":0.018878549999953975},{"x":-4.000119000000041,"y":-0.7500048499999821}]} />
<silkscreentext text="{NAME}" pcbX="-0.000127mm" pcbY="5.24983275mm" anchorAlignment="center" fontSize="1mm" />
<courtyardoutline outline={[{"x":-4.749991000000136,"y":4.501991750000116},{"x":4.749991000000023,"y":4.501991750000116},{"x":4.749991000000023,"y":-3.4999617500000113},{"x":-4.749991000000136,"y":-3.4999617500000113},{"x":-4.749991000000136,"y":4.501991750000116}]} />
      </footprint>}
      cadModel={{
        objUrl: objPath,
        stepUrl: stepPath,
        pcbRotationOffset: 0,
        modelOriginPosition: { x: 1, y: -1.9019987499999844, z: 0 },
      }}
      {...props}
    />
  )
}