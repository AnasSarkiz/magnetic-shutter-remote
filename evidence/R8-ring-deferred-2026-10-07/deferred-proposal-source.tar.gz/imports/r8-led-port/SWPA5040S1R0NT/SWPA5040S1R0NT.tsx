import objPath from "./SWPA5040S1R0NT.obj"
import stepPath from "./SWPA5040S1R0NT.step"
import type { InductorProps } from "@tscircuit/props"

export const SWPA5040S1R0NT = (props: Omit<InductorProps, "inductance">) => {
  return (
    <inductor
      inductance="1uH"
      supplierPartNumbers={{
  "jlcpcb": [
    "C96921"
  ]
}}
      manufacturerPartNumber="SWPA5040S1R0NT"
      footprint={<footprint>
        <smtpad portHints={["pin1"]} pcbX="-2.149983mm" pcbY="0mm" width="1.7999964mm" height="4.1999916mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
<smtpad portHints={["pin2"]} pcbX="2.149983mm" pcbY="0mm" width="1.7999964mm" height="4.1999916mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
<silkscreenpath route={[{"x":-2.499918799999932,"y":2.4999950000000126},{"x":2.5000711999998657,"y":2.4999950000000126}]} />
<silkscreenpath route={[{"x":-2.499918799999932,"y":-2.4999950000001263},{"x":2.5000711999998657,"y":-2.4999950000001263}]} />
<silkscreenpath route={[{"x":-2.499918799999932,"y":2.4999950000000126},{"x":-2.499918799999932,"y":2.33113579999997}]} />
<silkscreenpath route={[{"x":-2.499918799999932,"y":-2.33113579999997},{"x":-2.499918799999932,"y":-2.4999950000001263}]} />
<silkscreenpath route={[{"x":2.5000711999998657,"y":-2.4999950000001263},{"x":2.5000711999998657,"y":-2.33113579999997}]} />
<silkscreenpath route={[{"x":2.5000711999998657,"y":2.33113579999997},{"x":2.5000711999998657,"y":2.4999950000000126}]} />
<silkscreentext text="{NAME}" pcbX="-0.008509mm" pcbY="3.4892mm" anchorAlignment="center" fontSize="1mm" />
<courtyardoutline outline={[{"x":-3.299981199999934,"y":2.7499950000000126},{"x":3.299981199999934,"y":2.7499950000000126},{"x":3.299981199999934,"y":-2.7499950000001263},{"x":-3.299981199999934,"y":-2.7499950000001263},{"x":-3.299981199999934,"y":2.7499950000000126}]} />
      </footprint>}
      cadModel={{
        objUrl: objPath,
        stepUrl: stepPath,
        pcbRotationOffset: 0,
        modelOriginPosition: { x: 0, y: 0.00005000000011379235, z: 0 },
      }}
      {...props}
    />
  )
}