import type { FanoutTracePath } from "@tscircuit/core";

// Authored outer-layer power copper at exact supplier land centres.
export const r8BatteryFeedPaths: FanoutTracePath[] = [
	{
		connection: "J2.pin2",
		route: [
			{
				route_type: "wire",
				x: 13.249871,
				y: 22.50003275,
				width: 0.9,
				layer: "top",
			},
			{
				route_type: "wire",
				x: 15.45,
				y: 22.50003275,
				width: 0.9,
				layer: "top",
			},
			{
				route_type: "wire",
				x: 15.45,
				y: 20.5,
				width: 0.9,
				layer: "top",
			},
			{
				route_type: "wire",
				x: 14.45,
				y: 20.5,
				width: 0.9,
				layer: "top",
			},
			{
				route_type: "wire",
				x: 16.45,
				y: 20.5,
				width: 0.9,
				layer: "top",
			},
			{
				route_type: "via",
				x: 16.45,
				y: 20.5,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
			{
				route_type: "wire",
				x: 16.45,
				y: 20.5,
				width: 0.9,
				layer: "bottom",
			},
			{
				route_type: "wire",
				x: 14.45,
				y: 20.5,
				width: 0.9,
				layer: "bottom",
			},
			{
				route_type: "wire",
				x: 15.45,
				y: 20.5,
				width: 0.9,
				layer: "bottom",
			},
			{
				route_type: "wire",
				x: 15.45,
				y: 21.9,
				width: 0.9,
				layer: "bottom",
			},
			{
				route_type: "wire",
				x: 8,
				y: 20.5,
				width: 0.9,
				layer: "bottom",
			},
		],
	},
];
