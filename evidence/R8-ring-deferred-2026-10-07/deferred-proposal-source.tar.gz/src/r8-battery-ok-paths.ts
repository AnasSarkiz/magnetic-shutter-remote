import type { FanoutTracePath } from "@tscircuit/core";
// Complete native reset-supervisor path kept outside the switching-power loop.
export const r8BatteryOkPaths: FanoutTracePath[] = [
	{
		connection: ".U4 > port.pin2",
		route: [
			{
				route_type: "wire",
				x: -17.000002,
				y: 0.94996,
				width: 0.15,
				layer: "top",
			},
			{ route_type: "wire", x: -16, y: 0.94996, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -16, y: -3.4, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: -16,
				y: -3.4,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
			{ route_type: "wire", x: -16, y: -3.4, width: 0.15, layer: "bottom" },
			{ route_type: "wire", x: -16, y: -16, width: 0.15, layer: "bottom" },
			{ route_type: "wire", x: 16, y: -16, width: 0.15, layer: "bottom" },
			{
				route_type: "wire",
				x: 16,
				y: 0.7,
				width: 0.15,
				layer: "bottom",
			},
			{ route_type: "wire", x: 16.3, y: 0.7, width: 0.15, layer: "bottom" },
			{
				route_type: "via",
				x: 16.3,
				y: 0.7,
				from_layer: "bottom",
				to_layer: "top",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
			// Return south of R16; its ILIM land now occupies the old via site.
			{ route_type: "wire", x: 16.3, y: 0.7, width: 0.15, layer: "top" },
			{ route_type: "wire", x: 16.8, y: 0.7, width: 0.15, layer: "top" },
			{ route_type: "wire", x: 16.8, y: 2.3, width: 0.15, layer: "top" },
			{
				route_type: "wire",
				x: 17.50597835,
				y: 2.750068,
				width: 0.15,
				layer: "top",
			},
		],
	},
];
