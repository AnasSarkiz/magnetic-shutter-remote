import type { FanoutTracePath } from "@tscircuit/core";

// Complete port-to-port current-limit connection. Native38's automatic
// cleanup rejected duplicate endpoints; keep the native solver/rules intact.
export const r8LightIlimPaths: FanoutTracePath[] = [
	{
		connection: "U7.pin5",
		route: [
			{ route_type: "wire", x: 13.3, y: 3.749096, width: 0.15, layer: "top" },
			{ route_type: "wire", x: 13.3, y: 4.6, width: 0.15, layer: "top" },
			{ route_type: "wire", x: 15.75, y: 4.6, width: 0.15, layer: "top" },
			{ route_type: "wire", x: 15.75, y: 3.253364, width: 0.15, layer: "top" },
		],
	},
];
