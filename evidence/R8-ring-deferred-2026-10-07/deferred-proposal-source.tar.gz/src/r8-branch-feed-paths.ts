import type { PcbPath } from "@tscircuit/props";

// Ordinary native trace paths, in the respective imported component frames.
// C3 is translated(-10,0); L2 is translated(-9.5,13), rotated90deg.
export const r8RadioBatteryFeedPath: PcbPath = [
	{
		x: -1,
		y: -1.5,
	},
	{
		x: -1,
		y: -1.5,
		via: true,
		fromLayer: "top",
		toLayer: "bottom",
	},
	{
		x: -1,
		y: -1.5,
	},
	{
		x: 6.0,
		y: 8.0,
	},
	{
		x: 7.25,
		y: 8.25,
	},
	{
		x: 8.75,
		y: 9.75,
	},
	{
		x: 9.5,
		y: 11.0,
	},
	{
		x: 14.5,
		y: 14.0,
	},
	{
		x: 18,
		y: 20.5,
	},
];
export const r8LightBatteryFeedPath: PcbPath = [
	{
		x: -3,
		y: 3.1,
	},
	{
		x: -1.3,
		y: 3.1,
	},
	{
		x: -1.3,
		y: 3.1,
		via: true,
		fromLayer: "top",
		toLayer: "bottom",
	},
	{
		x: -1.3,
		y: 3.1,
	},
	{
		x: -3,
		y: 3.1,
	},
	{
		x: 3.75,
		y: -7.25,
	},
	{
		x: 3.75,
		y: -9.5,
	},
	{
		x: 7.5,
		y: -17.5,
	},
];
