import type { PcbPath } from "@tscircuit/props";

// R8 frame: translated(1,17), unrotated. End on the existing
// charger ILIM through-via at(0.9998075,15.8), using its top annulus.
export const r8VsetFeedPath: PcbPath = [
	{ x: -0.753364, y: -0.4 },
	{ x: -0.6, y: -0.6 },
	{ x: -0.0001925, y: -1.2 },
];

// R9 frame: translated(2.8,19.3), rotated90deg. Retain an off-pad
// transition and join the existing TS through-via at(1.9999325,15.8).
export const r8TsBiasFeedPath: PcbPath = [
	{ x: -2.2, y: 0 },
	{ x: -2.2, y: 0, via: true, fromLayer: "top", toLayer: "bottom" },
	{ x: -2.2, y: 0 },
	{ x: -2.8, y: 0.8 },
	{ x: -3.5, y: 0.8000675 },
];
