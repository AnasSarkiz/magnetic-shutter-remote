import type { FanoutTracePath } from "@tscircuit/core";
// Q1 and its gate pull-down share one off-pad ground via.
export const r8UsbDisablePaths: FanoutTracePath[] = [
	{
		connection: "Q1.pin3",
		route: [
			{ route_type: "wire", x: -4.999998, y: 1, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -5, y: 0, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: -5,
				y: 0,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
			// Join the existing same-net R5 escape on the bottom layer.
			{ route_type: "wire", x: -5, y: 0, width: 0.15, layer: "bottom" },
			{ route_type: "wire", x: 2, y: 3.6, width: 0.15, layer: "bottom" },
		],
	},
	{
		connection: "Q1.pin2",
		route: [
			{
				route_type: "wire",
				x: -3.000002,
				y: 1.94996,
				width: 0.15,
				layer: "top",
			},
			{ route_type: "wire", x: -1.5, y: 1.94996, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -1.5, y: 3.3, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: -1.5,
				y: 3.3,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "R6.pin2",
		route: [
			{ route_type: "wire", x: -0.753364, y: 1.5, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -0.753364, y: 3.3, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -1.5, y: 3.3, width: 0.15, layer: "top" },
		],
	},
	{
		connection: "R6.pin1",
		route: [
			{ route_type: "wire", x: 0.753364, y: 1.5, width: 0.3, layer: "top" },
			{ route_type: "wire", x: 3, y: 1.5, width: 0.3, layer: "top" },
			{
				route_type: "via",
				x: 3,
				y: 1.5,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
];
