import type { FanoutTracePath } from "@tscircuit/core";

// The shared regulated rail exits beside C12, outside its supplier land.
// All V3 endpoints in this fanout share the same existing top copper and
// one off-pad 0.30/0.45mm through via; final physical/width audits apply.
const regulatedOutputEscape: FanoutTracePath["route"] = [
	{ route_type: "wire", x: -10.999998, y: 8.5, width: 0.6, layer: "top" },
	{ route_type: "wire", x: -12.4, y: 8.5, width: 0.6, layer: "top" },
	{
		route_type: "via",
		x: -12.4,
		y: 8.5,
		from_layer: "top",
		to_layer: "bottom",
		via_diameter: 0.45,
		via_hole_diameter: 0.3,
	},
	{ route_type: "wire", x: -12.4, y: 8.5, width: 0.6, layer: "bottom" },
];

// Native switching-loop copper at measured, unchanged supplier pad centres.
// Narrow pin necks widen after clearing adjacent 0.5 mm-pitch terminals.
export const r8PowerPaths: FanoutTracePath[] = [
	{
		connection: "C13.pin2",
		route: [
			{ route_type: "wire", x: -7, y: 3.700024, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -7, y: 5, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -7.5, y: 5, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -7.5, y: 6, width: 0.15, layer: "top" },
			// Same physical GND barrel as the EP/decoupler path; core merges holes.
			{
				route_type: "via",
				x: -7.5,
				y: 6,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "U3.pin5",
		route: [
			{
				route_type: "wire",
				x: -11.157478,
				y: 2.000002,
				width: 0.3,
				layer: "top",
			},
			{ route_type: "wire", x: -11.157478, y: 1.5, width: 0.3, layer: "top" },
			{ route_type: "wire", x: -10.999998, y: 0, width: 0.6, layer: "top" },
		],
	},
	{
		connection: "U3.pin1",
		route: [
			{
				route_type: "wire",
				x: -11.157478,
				y: 3.999998,
				width: 0.2,
				layer: "top",
			},
			{ route_type: "wire", x: -11.157478, y: 4.5, width: 0.2, layer: "top" },
			{ route_type: "wire", x: -10.999998, y: 6, width: 0.6, layer: "top" },
			{ route_type: "wire", x: -10.999998, y: 8.5, width: 0.6, layer: "top" },
			...regulatedOutputEscape,
		],
	},
	{
		connection: "U3.pin2",
		route: [
			{
				route_type: "wire",
				x: -11.157478,
				y: 3.499872,
				width: 0.3,
				layer: "top",
			},
			{ route_type: "wire", x: -12, y: 3.55, width: 0.3, layer: "top" },
			{ route_type: "wire", x: -12.8, y: 4.35001, width: 0.4, layer: "top" },
			{ route_type: "wire", x: -14, y: 4.35001, width: 0.6, layer: "top" },
		],
	},
	{
		connection: "U3.pin4",
		route: [
			{
				route_type: "wire",
				x: -11.157478,
				y: 2.499874,
				width: 0.3,
				layer: "top",
			},
			{ route_type: "wire", x: -12, y: 2.45, width: 0.3, layer: "top" },
			{ route_type: "wire", x: -12.8, y: 1.64999, width: 0.4, layer: "top" },
			{ route_type: "wire", x: -14, y: 1.64999, width: 0.6, layer: "top" },
		],
	},
	{
		connection: "U3.pin8",
		route: [
			{ route_type: "wire", x: -8.842522, y: 3, width: 0.2, layer: "top" },
			{ route_type: "wire", x: -8, y: 3, width: 0.2, layer: "top" },
			{ route_type: "wire", x: -7, y: 2.299976, width: 0.3, layer: "top" },
			{ route_type: "wire", x: -7, y: -1.5, width: 0.3, layer: "top" },
			{ route_type: "wire", x: -10.999998, y: -1.5, width: 0.3, layer: "top" },
			{ route_type: "wire", x: -10.999998, y: 0, width: 0.3, layer: "top" },
		],
	},
	{
		connection: "C11.pin1",
		route: [
			{ route_type: "wire", x: -13.000002, y: -1, width: 0.5, layer: "top" },
			{ route_type: "wire", x: -12, y: -1, width: 0.5, layer: "top" },
			{ route_type: "wire", x: -10.999998, y: 0, width: 0.5, layer: "top" },
		],
	},
	{
		connection: "U3.pin10",
		route: [
			{
				route_type: "wire",
				x: -8.842522,
				y: 3.999998,
				width: 0.15,
				layer: "top",
			},
			{ route_type: "wire", x: -8.842522, y: 4.7, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -9, y: 5, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -10.999998, y: 5, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -10.999998, y: 6, width: 0.15, layer: "top" },
			...regulatedOutputEscape,
		],
	},
	{
		connection: "C4.pin1",
		route: [
			{ route_type: "wire", x: -10.999998, y: 6, width: 0.6, layer: "top" },
			...regulatedOutputEscape,
		],
	},
	{ connection: "C12.pin1", route: regulatedOutputEscape },

	{
		connection: "U3.pin3",
		route: [
			{ route_type: "wire", x: -11.157478, y: 3, width: 0.2, layer: "top" },
			{ route_type: "wire", x: -13, y: 3, width: 0.2, layer: "top" },
			// Same physical GND barrel as the EP/decoupler path; core merges holes.
			{
				route_type: "via",
				x: -13,
				y: 3,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "U3.pin9",
		route: [
			{
				route_type: "wire",
				x: -8.842522,
				y: 3.499872,
				width: 0.2,
				layer: "top",
			},
			{ route_type: "wire", x: -8, y: 3.499872, width: 0.2, layer: "top" },
			{ route_type: "wire", x: -8, y: 4.8, width: 0.2, layer: "top" },
			{
				route_type: "via",
				x: -8,
				y: 4.8,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "U3.pin7",
		route: [
			{
				route_type: "wire",
				x: -8.842522,
				y: 2.499874,
				width: 0.15,
				layer: "top",
			},
			{ route_type: "wire", x: -10, y: 2.499874, width: 0.15, layer: "top" },
			// Join the existing off-pad ground barrel through the solid EP copper.
			{ route_type: "wire", x: -10, y: 3, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -11.157478, y: 3, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -13, y: 3, width: 0.15, layer: "top" },
			// Same physical GND barrel as the EP/decoupler path; core merges holes.
			{
				route_type: "via",
				x: -13,
				y: 3,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "C3.pin2",
		route: [
			{ route_type: "wire", x: -9.000002, y: 0, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -7.8, y: 0, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: -7.8,
				y: 0,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "C4.pin2",
		route: [
			{ route_type: "wire", x: -9.000002, y: 6, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -7.5, y: 6, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: -7.5,
				y: 6,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "C12.pin2",
		route: [
			{ route_type: "wire", x: -9.000002, y: 8.5, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -8, y: 7.1, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: -8,
				y: 7.1,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "C11.pin2",
		route: [
			{ route_type: "wire", x: -14.999998, y: -1, width: 0.15, layer: "top" },
			{ route_type: "wire", x: -14.999998, y: -3, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: -14.999998,
				y: -3,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "U3.pin11",
		route: [
			{ route_type: "wire", x: -10, y: 3, width: 0.3, layer: "top" },
			{ route_type: "wire", x: -11.157478, y: 3, width: 0.3, layer: "top" },
			{ route_type: "wire", x: -13, y: 3, width: 0.3, layer: "top" },
			{
				route_type: "via",
				x: -13,
				y: 3,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
	{
		connection: "U3.pin6",
		route: [
			{
				route_type: "wire",
				x: -8.842522,
				y: 2.000002,
				width: 0.15,
				layer: "top",
			},
			{ route_type: "wire", x: -7.65, y: 0.95, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: -7.65,
				y: 0.95,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
		],
	},
];
