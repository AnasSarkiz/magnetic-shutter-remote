import { createR8LocalAutorouter } from "./r8-local-autorouter";

// Route power first, then signals, then ground. Previously generated copper
// becomes native obstacles for subsequent phases. USB5V/REG_EN stay together
// because their existing fanouts are linked by the supply-enable circuit.
export const r8AutomaticRoutingPhases = [
	["USB5V", "REG_EN"],
	["VBAT"],
	["INDUCTOR_L1"],
	["INDUCTOR_L2"],
	["V3"],
	["RING_SW"],
	["RING_5V_RAW"],
	["RING_5V"],
	["CHARGER_SYS"],
	["RING_FB"],
	["RING_ENABLE"],
	["RING_FAULT"],
	["RING_DATA"],
	["RING_BUFFER_OUT"],
	["RING_DI"],
	["CC1"],
	["CC2"],
	["TS_BIAS"],
	["PROG"],
	["CHARGE_LED_A"],
	["EN"],
	["SHUTTER"],
	["PAIR"],
	["STATUS_LED"],
	["UART_TX"],
	["STATUS_LED_A"],
	["POWER_SWITCH"],
	["TEMP_SET_COLD"],
	["TEMP_OK"],
	["CHARGE_STAT"],
	["VSET"],
	["GND"],
] as const;

export function R8AutomaticRoutingPhases() {
	return (
		<>
			{r8AutomaticRoutingPhases.map((names, index) => (
				<autoroutingphase
					key={index}
					phaseIndex={index + 3}
					algorithmFn={createR8LocalAutorouter}
					connections={names.map((name) => `net.${name}`)}
					minTraceToPadEdgeClearance="0.30mm"
					minViaEdgeToPadEdgeClearance="0.45mm"
					minTraceToHoleEdgeClearance="0.40mm"
					minViaHoleEdgeToViaHoleEdgeClearance="0.60mm"
					minPlatedHoleDrillEdgeToDrillEdgeClearance="0.65mm"
				/>
			))}
		</>
	);
}
