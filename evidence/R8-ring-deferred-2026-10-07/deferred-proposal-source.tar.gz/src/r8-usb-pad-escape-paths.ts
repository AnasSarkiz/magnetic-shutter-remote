import type { FanoutTracePath } from "@tscircuit/core";

// Native off-pad USB supply escapes preserve the supplier lands and keep
// the parent power connection on the bottom layer. Final copper audits
// still verify every clearance, through via and physical net connection.
function usbPowerPadEscape(escape: {
	connection: string;
	pad: { x: number; y: number };
	via: { x: number; y: number };
}): FanoutTracePath {
	return {
		connection: escape.connection,
		route: [
			{ route_type: "wire", ...escape.pad, width: 0.3, layer: "top" },
			{ route_type: "wire", ...escape.via, width: 0.3, layer: "top" },
			{
				route_type: "via",
				...escape.via,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
			{ route_type: "wire", ...escape.via, width: 0.3, layer: "bottom" },
		],
	};
}

export const r8UsbCapEscapePaths: FanoutTracePath[] = [
	usbPowerPadEscape({
		connection: "C1.pin1",
		pad: { x: -7.700024, y: 24.55 },
		via: { x: -9.25, y: 24.55 },
	}),
];

export const r8UsbGateEscapePaths: FanoutTracePath[] = [
	usbPowerPadEscape({
		connection: "Q1.pin1",
		pad: { x: -3.000002, y: 0.05004 },
		via: { x: -1.8, y: 0.05004 },
	}),
];

export const r8ChargeDisablePowerEscapePaths: FanoutTracePath[] = [
	usbPowerPadEscape({
		connection: "R13.pin1",
		pad: { x: 8.753364, y: 12 },
		via: { x: 9.3, y: 13.5 },
	}),
];
