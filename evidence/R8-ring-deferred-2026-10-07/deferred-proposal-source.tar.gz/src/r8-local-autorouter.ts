import type { GenericLocalAutorouter } from "@tscircuit/core";
import {
	AutoroutingPipelineSolver7_MultiGraph,
	type SimpleRouteJson,
} from "@tscircuit/capacity-autorouter";

type Solver = AutoroutingPipelineSolver7_MultiGraph;
type RoutingInput = GenericLocalAutorouter["input"];
type Complete = {
	type: "complete";
	traces: ReturnType<Solver["getOutputSimplifiedPcbTraces"]>;
};
type Failure = { type: "error"; error: Error };
type Progress = {
	type: "progress";
	steps: number;
	progress: number;
	phase: string;
	iterationsPerSecond: number;
};

// The locked native pipeline's early stages read defaultObstacleMargin,
// independently of phase DRC tolerances. Keep this source input explicit.
// This adapter only supplies solver inputs/events; native final DRC and the
// independent copper checks still decide whether the board is acceptable.
export async function createR8LocalAutorouter(
	input: RoutingInput,
): Promise<GenericLocalAutorouter> {
	return new R8LocalAutorouter(input);
}

class R8LocalAutorouter implements GenericLocalAutorouter {
	readonly input: RoutingInput;
	readonly solver: Solver;
	isRouting = false;
	private timer?: ReturnType<typeof setTimeout>;
	private steps = 0;
	private handlers = {
		complete: [] as Array<(event: Complete) => void>,
		error: [] as Array<(event: Failure) => void>,
		progress: [] as Array<(event: Progress) => void>,
	};

	constructor(input: RoutingInput) {
		this.input = {
			...input,
			defaultObstacleMargin: Math.max(input.defaultObstacleMargin ?? 0, 0.45),
		};
		console.info(
			"R8 native pipeline7: early obstacle margin",
			this.input.defaultObstacleMargin,
			"mm; effort 2x; final board rules unchanged",
			"; optional power expansion disabled; measured current/width checks required",
		);
		this.solver = new AutoroutingPipelineSolver7_MultiGraph(
			toNativeRoutingInput(this.input),
			{
				effort: 2,
				cacheProvider: null,
				// TraceWidthSolver and explicit source widths remain active.
				// Keep optional expansion from rewriting authored power escapes;
				// independent measured width/current checks remain mandatory.
				powerTraceExpansion: { onlyConnectionNames: [] },
			},
		);
	}

	on(event: "complete", callback: (event: Complete) => void): void;
	on(event: "error", callback: (event: Failure) => void): void;
	on(event: "progress", callback: (event: Progress) => void): void;
	on(
		event: "complete" | "error" | "progress",
		callback:
			| ((event: Complete) => void)
			| ((event: Failure) => void)
			| ((event: Progress) => void),
	) {
		if (event === "complete")
			this.handlers.complete.push(callback as (event: Complete) => void);
		else if (event === "error")
			this.handlers.error.push(callback as (event: Failure) => void);
		else this.handlers.progress.push(callback as (event: Progress) => void);
	}

	start() {
		if (this.isRouting) return;
		this.isRouting = true;
		this.cycle();
	}

	stop() {
		this.isRouting = false;
		if (this.timer !== undefined) clearTimeout(this.timer);
		this.timer = undefined;
	}

	private cycle() {
		if (!this.isRouting) return;
		try {
			const started = Date.now();
			const initialIterations = this.solver.iterations;
			while (
				Date.now() - started < 250 &&
				!this.solver.failed &&
				!this.solver.solved
			)
				this.solver.step();
			if (this.solver.failed)
				throw new Error(this.solver.error ?? "Native routing failed");
			if (this.solver.solved) {
				this.stop();
				const event: Complete = {
					type: "complete",
					traces: this.solver.getOutputSimplifiedPcbTraces(),
				};
				for (const handler of this.handlers.complete) handler(event);
				return;
			}
			const event: Progress = {
				type: "progress",
				steps: ++this.steps,
				progress: this.solver.progress,
				phase: this.solver.getCurrentPhase(),
				iterationsPerSecond:
					((this.solver.iterations - initialIterations) * 1000) /
					Math.max(1, Date.now() - started),
			};
			for (const handler of this.handlers.progress) handler(event);
			this.timer = setTimeout(() => this.cycle(), 0);
		} catch (error) {
			this.stop();
			const event: Failure = {
				type: "error",
				error: error instanceof Error ? error : new Error(String(error)),
			};
			for (const handler of this.handlers.error) handler(event);
		}
	}

	solveSync() {
		this.solver.solve();
		if (this.solver.failed)
			throw new Error(this.solver.error ?? "Native routing failed");
		return this.solver.getOutputSimplifiedPcbTraces();
	}
}

function toNativeRoutingInput(input: RoutingInput): SimpleRouteJson {
	return {
		...input,
		traces: input.traces?.map((trace) => {
			if (!trace.connection_name)
				throw new Error(
					`Native input trace ${trace.pcb_trace_id} lacks a net name`,
				);
			return { ...trace, connection_name: trace.connection_name };
		}),
	};
}
