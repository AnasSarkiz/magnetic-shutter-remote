import { TPS61023DRLR } from "../imports/r8-led-port/TPS61023DRLR/TPS61023DRLR";
import { TPS2553DBVR_1 } from "../imports/r8-led-port/TPS2553DBVR_1/TPS2553DBVR_1";
import { SN74AHCT1G125DBVR } from "../imports/r8-led-port/SN74AHCT1G125DBVR/SN74AHCT1G125DBVR";
import { SWPA5040S1R0NT } from "../imports/r8-led-port/SWPA5040S1R0NT/SWPA5040S1R0NT";
import { B4B_PH_SM4_TB_LF__SN_ } from "../imports/r8-led-port/B4B_PH_SM4_TB_LF__SN_/B4B_PH_SM4_TB_LF__SN_";
import { A_0603WAF7323T5E } from "../imports/r8-led-port/A_0603WAF7323T5E/A_0603WAF7323T5E";
import { A_0603WAF6342T5E } from "../imports/r8-led-port/A_0603WAF6342T5E/A_0603WAF6342T5E";
import { A_0603WAF3300T5E } from "../imports/r8-led-port/A_0603WAF3300T5E/A_0603WAF3300T5E";
import { A_0603WAF1003T5E } from "../imports/A_0603WAF1003T5E";
import { CL21A106KAYNNNE } from "../imports/CL21A106KAYNNNE";
import { CC0603KRX7R9BB104 } from "../imports/CC0603KRX7R9BB104";
import { A_2N7002 } from "../imports/A_2N7002";
import { SchematicComponentNotes } from "./schematic-component-notes";
import { r8LightSwitchPaths } from "./r8-light-switch-paths";
import { r8LightSignalPaths } from "./r8-light-signal-paths";
import { r8LightIlimPaths } from "./r8-light-ilim-paths";
import { r8LedPowerPaths } from "./r8-led-power-paths";
import { r8LightBatteryFeedPath } from "./r8-branch-feed-paths";

// All purchased components remain exact native JLCPCB imports. This port is for
// a compatible addressable RGBW accessory, not the historical R7 emitter board.
export function R8LedPort({ routingEnabled }: { routingEnabled: boolean }) {
	return (
		<>
			<net
				name="RING_5V_RAW"
				routingPhaseIndex={9}
				isPowerNet
				nominalTraceWidth="0.4mm"
			/>
			<net
				name="RING_5V"
				routingPhaseIndex={10}
				isPowerNet
				nominalTraceWidth="0.3mm"
			/>
			<net name="RING_SW" routingPhaseIndex={8} nominalTraceWidth="0.5mm" />
			<net name="RING_FB" routingPhaseIndex={12} />
			<net name="RING_ILIM" routingPhaseIndex={1} />
			{routingEnabled && (
				<autoroutingphase
					phaseIndex={1}
					connections={[".U7 > port.pin5", ".R16 > port.pin1"]}
					pcbTracePaths={r8LightIlimPaths}
				/>
			)}
			<net name="RING_ENABLE" routingPhaseIndex={13} />
			<net name="RING_FAULT" routingPhaseIndex={14} />
			<net name="RING_DATA" routingPhaseIndex={15} />
			<net name="RING_BUFFER_OUT" routingPhaseIndex={16} />
			<net name="RING_DI" routingPhaseIndex={17} />
			<net name="RING_OE" routingPhaseIndex={0} />
			{routingEnabled && (
				<autoroutingphase
					phaseIndex={0}
					connections={[
						".U8 > port.pin1",
						".R21 > port.pin2",
						".Q3 > port.pin3",
					]}
					pcbTracePaths={r8LightSignalPaths}
				/>
			)}
			<schematicsheet
				name="Light"
				displayName="Battery-powered RGBW accessory"
				sheetIndex={6}
				sheetSize="A4"
			>
				<schematictext
					text="Component explanations: LightGuide (sheet 8)."
					schX={-12.5}
					schY={9.5}
					anchor="left"
					fontSize={0.25}
				/>
				<fanout
					name="RING_POWER_LOOPS"
					pcbX={0}
					pcbY={0}
					pcbTracePaths={routingEnabled ? r8LedPowerPaths : []}
				>
					{routingEnabled && (
						<>
							<via
								name="LIGHT_INPUT_LOWER"
								pcbX={-12.6}
								pcbY={10}
								layers={["top", "bottom"]}
								holeDiameter="0.30mm"
								outerDiameter="0.45mm"
								connectsTo="net.VBAT"
							/>
							<via
								name="LIGHT_INPUT_CENTER"
								pcbX={-12.6}
								pcbY={10.850017}
								layers={["top", "bottom"]}
								holeDiameter="0.30mm"
								outerDiameter="0.45mm"
								connectsTo="net.VBAT"
							/>
							<via
								name="LIGHT_GROUND_LOWER"
								pcbX={-5.5499858}
								pcbY={15.5}
								layers={["top", "bottom"]}
								holeDiameter="0.30mm"
								outerDiameter="0.45mm"
								connectsTo="net.GND"
							/>
						</>
					)}
					<TPS61023DRLR
						name="U6"
						pcbX={-4.8}
						pcbY={14}
						schX={-7}
						schY={3}
						pcbSx={{ "& smtpad": { solderMaskMargin: "0.04mm" } }}
						pinAttributes={{
							FB: { isInput: true },
							EN: { isInput: true },
							VIN: { requiresPower: true },
							GND: { requiresGround: true },
							SW: { isOutput: true },
							VOUT: { isOutput: true },

							pin1: { isInput: true },
							pin2: { isInput: true },
							pin3: { requiresPower: true },
							pin4: { requiresGround: true },
							pin5: { isOutput: true },
							pin6: { isOutput: true },
						}}
						connections={{
							pin1: "net.RING_FB",
							pin2: "net.REG_EN",
							pin3: "net.VBAT",
							pin4: "net.GND",
							pin5: "net.RING_SW",
							pin6: "net.RING_5V_RAW",
						}}
					/>
					<SWPA5040S1R0NT
						name="L2"
						pcbX={-9.5}
						pcbY={13}
						pcbRotation={90}
						schX={-7}
						schY={6}
						connections={{ pin1: "net.VBAT", pin2: "net.RING_SW" }}
					/>
					<CL21A106KAYNNNE
						name="C14"
						pcbX={-2.7}
						pcbY={16.8}
						schX={-11}
						schY={3}
						schRotation={-90}
						connections={{ pin1: "net.VBAT", pin2: "net.GND" }}
					/>
					<CL21A106KAYNNNE
						name="C15"
						pcbX={-6}
						pcbY={8.7}
						schX={-12.8}
						schY={3}
						schRotation={-90}
						connections={{ pin1: "net.VBAT", pin2: "net.GND" }}
					/>
					<CL21A106KAYNNNE
						name="C16"
						pcbX={-3.4}
						pcbY={11.3}
						schX={-3}
						schY={3}
						schRotation={-90}
						connections={{ pin1: "net.RING_5V_RAW", pin2: "net.GND" }}
					/>
					<A_0603WAF7323T5E
						name="R14"
						pcbRotation={180}
						pcbX={-2.5}
						pcbY={9.4}
						schX={-4}
						schY={0}
						schRotation={-90}
						connections={{ pin1: "net.RING_5V_RAW", pin2: "net.RING_FB" }}
					/>
					<A_0603WAF1003T5E
						name="R15"
						pcbRotation={90}
						pcbX={-6.65}
						pcbY={18}
						schX={-4}
						schY={-3}
						schRotation={-90}
						connections={{ pin1: "net.RING_FB", pin2: "net.GND" }}
					/>
				</fanout>
				{routingEnabled && (
					<trace
						from="L2.pin1"
						to="net.VBAT"
						thickness="0.6mm"
						pcbPath={r8LightBatteryFeedPath}
					/>
				)}
				<fanout
					name="LIGHT_SWITCH_ESCAPE"
					pcbX={0}
					pcbY={0}
					pcbTracePaths={routingEnabled ? r8LightSwitchPaths : []}
				>
					<CL21A106KAYNNNE
						name="C17"
						pcbX={11}
						pcbY={-0.6}
						schX={-1.2}
						schY={3}
						schRotation={-90}
						connections={{ pin1: "net.RING_5V_RAW", pin2: "net.GND" }}
					/>
					<TPS2553DBVR_1
						name="U7"
						pcbX={13.3}
						pcbY={2.6}
						schX={5}
						schY={4}
						pinAttributes={{
							IN: { requiresPower: true },
							GND: { requiresGround: true },
							EN: { isInput: true },
							N_FAULT: { isOutput: true },
							ILIM: { isInput: true },
							OUT: { isOutput: true },

							pin1: { requiresPower: true },
							pin2: { requiresGround: true },
							pin3: { isInput: true },
							pin4: { isOutput: true },
							pin5: { isInput: true },
							pin6: { isOutput: true },
						}}
						connections={{
							pin1: "net.RING_5V_RAW",
							pin2: "net.GND",
							pin3: "net.RING_ENABLE",
							pin4: "net.RING_FAULT",
							pin5: "net.RING_ILIM",
							pin6: "net.RING_5V",
						}}
					/>
					<CL21A106KAYNNNE
						name="C18"
						pcbRotation={180}
						pcbX={9.55}
						pcbY={3.25}
						schX={10}
						schY={4}
						schRotation={-90}
						connections={{ pin1: "net.RING_5V", pin2: "net.GND" }}
					/>
					<CC0603KRX7R9BB104
						name="C20"
						pcbX={9.8}
						pcbY={1.325}
						pcbRotation={180}
						schX={0}
						schY={4}
						schRotation={-90}
						connections={{ pin1: "net.RING_5V_RAW", pin2: "net.GND" }}
					/>
				</fanout>
				<A_0603WAF6342T5E
					name="R16"
					pcbRotation={270}
					pcbX={15.75}
					pcbY={2.5}
					schX={2}
					schY={1}
					schRotation={-90}
					connections={{ pin1: "net.RING_ILIM", pin2: "net.GND" }}
				/>
				<A_0603WAF1003T5E
					name="R17"
					pcbX={14.6}
					pcbY={-5.9}
					schX={6}
					schY={1}
					schRotation={-90}
					connections={{ pin1: "net.RING_ENABLE", pin2: "net.GND" }}
				/>
				<A_0603WAF1003T5E
					name="R20"
					pcbX={15}
					pcbY={-8.5}
					schX={8}
					schY={7}
					schRotation={-90}
					connections={{ pin1: "net.V3", pin2: "net.RING_FAULT" }}
				/>
				<fanout
					name="LIGHT_OUTPUT_ENABLE_ESCAPE"
					pcbX={0}
					pcbY={0}
					pcbTracePaths={[]}
				>
					<SN74AHCT1G125DBVR
						name="U8"
						pcbX={13.3}
						pcbY={7.5}
						schX={2}
						schY={-3}
						pinAttributes={{
							N_OE: { isInput: true },
							A: { isInput: true },
							GND: { requiresGround: true },
							Y: { isOutput: true },
							VCC: { requiresPower: true },

							pin1: { isInput: true },
							pin2: { isInput: true },
							pin3: { requiresGround: true },
							pin4: { isOutput: true },
							pin5: { requiresPower: true },
						}}
						connections={{
							pin1: "net.RING_OE",
							pin2: "net.RING_DATA",
							pin3: "net.GND",
							pin4: "net.RING_BUFFER_OUT",
							pin5: "net.RING_5V",
						}}
					/>
				</fanout>
				<A_0603WAF1003T5E
					name="R18"
					pcbX={10.5}
					pcbY={-10.5}
					schX={-1}
					schY={-5}
					schRotation={-90}
					connections={{ pin1: "net.RING_DATA", pin2: "net.GND" }}
				/>
				<A_0603WAF3300T5E
					name="R19"
					pcbRotation={180}
					pcbX={-10.75}
					pcbY={20.8}
					schX={6}
					schY={-1}
					connections={{ pin1: "net.RING_BUFFER_OUT", pin2: "net.RING_DI" }}
				/>
				<fanout
					name="LIGHT_OUTPUT_PULLUP_ESCAPE"
					pcbX={0}
					pcbY={0}
					pcbTracePaths={[]}
				>
					<A_0603WAF1003T5E
						name="R21"
						pcbX={5.7}
						pcbY={-0.85}
						schX={-5}
						schY={-6}
						schRotation={-90}
						connections={{ pin1: "net.RING_5V", pin2: "net.RING_OE" }}
					/>
				</fanout>
				<fanout
					name="LIGHT_OUTPUT_MOSFET_ESCAPE"
					pcbX={0}
					pcbY={0}
					pcbTracePaths={[]}
				>
					<A_2N7002
						name="Q3"
						pcbX={7.8}
						pcbY={16.5}
						schX={-6}
						schY={-3}
						pinAttributes={{
							G: { isInput: true },
							S: { requiresGround: true },
							D: { isOutput: true },
							pin1: { isInput: true },
							pin2: { requiresGround: true },
							pin3: { isOutput: true },
						}}
						connections={{
							pin1: "net.RING_ENABLE",
							pin2: "net.GND",
							pin3: "net.RING_OE",
						}}
					/>
				</fanout>
				<CC0603KRX7R9BB104
					name="C19"
					pcbRotation={90}
					pcbX={10.2}
					pcbY={9.4}
					schX={11.8}
					schY={4}
					schRotation={-90}
					connections={{ pin1: "net.RING_5V", pin2: "net.GND" }}
				/>
				<B4B_PH_SM4_TB_LF__SN_
					name="J4"
					pcbRotation={270}
					pcbX={-17}
					pcbY={16.2}
					schX={12}
					schY={-2}
					connections={{
						pin1: "net.GND",
						pin2: "net.RING_5V",
						pin3: "net.RING_DI",
						pin4: "net.GND",
						pin5: "net.GND",
						pin6: "net.GND",
					}}
				/>
			</schematicsheet>
			<schematicsheet
				name="LightGuide"
				displayName="RGBW accessory: each component explained"
				sheetIndex={7}
				sheetSize="A4"
			>
				<SchematicComponentNotes sheet="Light" />
			</schematicsheet>
		</>
	);
}
