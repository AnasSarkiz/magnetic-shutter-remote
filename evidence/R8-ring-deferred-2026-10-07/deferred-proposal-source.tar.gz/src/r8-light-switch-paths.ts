import type { FanoutTracePath } from "@tscircuit/core";

// Shared off-pad native escapes retain the exact imported lands and local
// supply capacitors. Core merges duplicate barrels on the same net; actual
// routed hole, clearance, connectivity and current audits remain required.
const rawInputEscape: FanoutTracePath["route"] = [
	{ route_type: "wire", x: 8.65, y: -0.6, width: 0.4, layer: "top" },
	{
		route_type: "via",
		x: 8.65,
		y: -0.6,
		from_layer: "top",
		to_layer: "bottom",
		via_diameter: 0.45,
		via_hole_diameter: 0.3,
	},
	{ route_type: "wire", x: 8.65, y: -0.6, width: 0.4, layer: "bottom" },
];

const switchedOutputEscape: FanoutTracePath["route"] = [
	{ route_type: "wire", x: 10.549998, y: 3.25, width: 0.4, layer: "top" },
	{ route_type: "wire", x: 10.549998, y: 5, width: 0.4, layer: "top" },
	{
		route_type: "via",
		x: 10.549998,
		y: 5,
		from_layer: "top",
		to_layer: "bottom",
		via_diameter: 0.45,
		via_hole_diameter: 0.3,
	},
	{ route_type: "wire", x: 10.549998, y: 5, width: 0.4, layer: "bottom" },
];

export const r8LightSwitchPaths: FanoutTracePath[] = [
	{
		connection: "C17.pin1",
		route: [
			{ route_type: "wire", x: 10.000002, y: -0.6, width: 0.4, layer: "top" },
			...rawInputEscape,
		],
	},
	{
		connection: "C20.pin1",
		route: [
			{ route_type: "wire", x: 10.500024, y: 1.325, width: 0.4, layer: "top" },
			{ route_type: "wire", x: 10.500024, y: 0.5, width: 0.4, layer: "top" },
			{ route_type: "wire", x: 8.65, y: 0.5, width: 0.4, layer: "top" },
			...rawInputEscape,
		],
	},
	{
		connection: "U7.pin1",
		route: [
			{
				route_type: "wire",
				x: 12.35004,
				y: 1.450904,
				width: 0.4,
				layer: "top",
			},
			{ route_type: "wire", x: 10.500024, y: 1.325, width: 0.4, layer: "top" },
			{ route_type: "wire", x: 10.500024, y: 0.5, width: 0.4, layer: "top" },
			{ route_type: "wire", x: 8.65, y: 0.5, width: 0.4, layer: "top" },
			...rawInputEscape,
		],
	},
	{
		connection: "U7.pin6",
		route: [
			{
				route_type: "wire",
				x: 12.35004,
				y: 3.749096,
				width: 0.4,
				layer: "top",
			},
			...switchedOutputEscape,
		],
	},
	{ connection: "C18.pin1", route: switchedOutputEscape },
];
