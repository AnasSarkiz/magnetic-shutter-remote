import type { FanoutTracePath } from "@tscircuit/core";

// Actual supplier R12 lands at rotation270deg. Native fanout makes each
// off-pad through-via a bottom breakout, rather than retaining the top pad.
export const r8R12EscapePaths: FanoutTracePath[] = [
	{
		connection: "R12.pin2",
		route: [
			{ route_type: "wire", x: 18.7, y: 10.496636, width: 0.15, layer: "top" },
			{ route_type: "wire", x: 19.65, y: 10.496636, width: 0.15, layer: "top" },
			{
				route_type: "via",
				x: 19.65,
				y: 10.496636,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
			{
				route_type: "wire",
				x: 19.65,
				y: 10.496636,
				width: 0.15,
				layer: "bottom",
			},
		],
	},
	{
		connection: "R12.pin1",
		route: [
			{ route_type: "wire", x: 18.7, y: 12.003364, width: 0.3, layer: "top" },
			{ route_type: "wire", x: 19.65, y: 12.003364, width: 0.3, layer: "top" },
			{
				route_type: "via",
				x: 19.65,
				y: 12.003364,
				from_layer: "top",
				to_layer: "bottom",
				via_diameter: 0.45,
				via_hole_diameter: 0.3,
			},
			{
				route_type: "wire",
				x: 19.65,
				y: 12.003364,
				width: 0.3,
				layer: "bottom",
			},
		],
	},
];
