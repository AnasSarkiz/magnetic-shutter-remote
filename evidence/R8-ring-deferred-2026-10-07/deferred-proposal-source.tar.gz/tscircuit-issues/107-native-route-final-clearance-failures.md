#107 — Complete automatic routes fail final clearance checks

Classification: actual source-generated routed candidate fails native final DRC. This is a real fabrication blocker; it is separate from JLCPCB import/stock and missing3V3 power metadata.

Native source60 passed all12 qualification commands, including actual browser Style Analysis0, five canonical source checks,45CAM tests and assembly export. All33 automatic nets route in full native40 after supported authored phases. The solver reports120 traces/0 solver errors/no jumpers, but the native build exits1 with80 final errors. Counts: {"pcb_trace_error": 25, "pcb_pad_trace_clearance_error": 2, "pcb_via_trace_clearance_error": 27, "pcb_pad_pad_clearance_error": 4, "pcb_via_clearance_error": 18, "pcb_placement_error": 4}. No unconnected-port error is present; solver completion is not DRC approval. Retain route40/source, native inputs/outputs/circuit/error JSON, checks/native-route40.log and route40-resources.json. PeakRSS2798360KiB, noOOM.

Source61 proposes a supported explicit autoroutingphase3 with stronger routing-time clearance tolerances: trace/pad0.30mm, via/pad0.45mm, trace/hole0.40mm, via-hole/via-hole0.60mm, plated-drill/drill0.65mm. Parts, poses, connectivity, widths, two layers and0.30/0.45mm vias remain unchanged. Final board checks retain their original stricter-than-manufacturer project rules and are not weakened. Confirm emitted native phase input actually applies these source settings. Fresh qualifications, full native41 and independent/fabrication checks remain required; this proposal is not a passing board or demonstrated engine fix.

## Actual prerequisite/input verification61/41

All12 fresh source61 qualification commands pass, including actual latest browser Style Analysis0 and45CAM regressions. Both111authored/115combined source preflights pass. Exact emitted native41 phase3 input contains all33automatic nets and all five stronger margins above; retained supported-phase-margin-input-check.json binds its SHA. Fullnative41 is still running; final board approval remains pending.

## Actual native41 result / source62 early-stage margin proposal

Native41 also completes all33automatic nets but exits1 with156 final errors, including actual accidental copper contacts. Counts: {"pcb_trace_error": 42, "pcb_pad_trace_clearance_error": 9, "pcb_via_trace_clearance_error": 61, "pcb_pad_pad_clearance_error": 5, "pcb_via_clearance_error": 35, "pcb_placement_error": 4}. PeakRSS3119896KiB/noOOM. Its stronger phase DRC fields were actually applied, but the locked pipeline's early stages still read defaultObstacleMargin with an independent0.15mm default. This candidate is rejected, preserved and never published as a pass.

Source62 adds a supported algorithmFn event adapter instantiating the same locked native AutoroutingPipelineSolver9_PreloadedTraceGraph with effort2/cacheProvidernull and explicit defaultObstacleMargin0.45mm. It supplies native solver input/progress/complete/error/cancellation only; it does not edit generated copper, invoke a different router, change imports/dependencies/board limits or suppress errors. Full fresh qualifications/native42/final independent checks remain required. This is a proposed source-level configuration correction, not a demonstrated engine fix.

## Actual prerequisites63 and native42 invocation

All12 fresh source63 checks pass, including45CAM tests, all5 direct source checks, actual latest browser Style Analysis0 and65 supplier assembly frames.111authored/115combined paths pass preflight. Native42 actually invokes the supported factory: log prints early obstacle margin0.45mm/effort2 and core reports custom_algorithm cache disabled. The factory constructs the unchanged locked native pipeline9; no hand-written routing output is returned. This proves runtime configuration invocation, not a final DRC pass. Fullnative42 is running.

## Actual native42 result

Native42 applies0.45mm early-stage margin and completes connections, but exits1 with148 final errors: {"pcb_trace_error": 41, "pcb_pad_trace_clearance_error": 7, "pcb_via_trace_clearance_error": 59, "pcb_pad_pad_clearance_error": 5, "pcb_via_clearance_error": 32, "pcb_placement_error": 4}. PeakRSS3360680KiB/noOOM. This setting alone is not a fix; real contacts/clearances remain. Source64 additionally corrects proven authored copper spacing (108) and tests the supported powerTraceExpansion.onlyConnectionNames=[] setting to isolate optional rewriting of authored routes. Native TraceWidthSolver/source widths and unchanged final native/independent width/current/DRC checks remain mandatory. No guaranteed or passing-board claim; fresh qualification64/fullnative43 are pending.

## Actual native43 result / supported pipeline7 proposal65

Source64 all12 qualification commands/47CAM/browser0/111and115 expanded preflights pass. Fullnative43 still exits1 with165 native errors: {"pcb_trace_error": 45, "pcb_pad_trace_clearance_error": 13, "pcb_via_trace_clearance_error": 69, "pcb_pad_pad_clearance_error": 3, "pcb_via_clearance_error": 30, "pcb_placement_error": 5}. PeakRSS3396868KiB/noOOM. Authored clearances are now proven clean, but automatic copper has real contacts/spacing/SMT-drill failures. Disabling optional power expansion is not a fix; this unsuccessful candidate is preserved and not published.

Source65 tests supported beta_pipeline7 via the exported AutoroutingPipelineSolver7_MultiGraph in the same locked capacity-autorouter0.0.951 package. Native trace-width solver, explicit0.45mm early margin/stronger phase tolerances, effort2/noCPUprofiler, source-authored paths and unchanged board/final independent rules remain. No dependency/toolchain/import/component/net/pose/width/layer/via-size or resource-guard change. Fresh qualification65/fullnative44/final audits remain required. This is an explicit algorithm selection, not a hidden fallback or a passing-board claim.

## Actual source65 prerequisites / native44 start

All12 fresh current source65 prerequisites pass, including47CAM/browser0/all5 direct source checks/electrical contracts/65supplier assembly frames. Both111/115expanded authored preflights pass. Actual native44 complete source-closure build has started; constructor is the supported locked pipeline7, effort2, early0.45mm margin and optional power expansion disabled. No final DRC pass is implied; unchanged final native/independent measurements remain required.


## Actual native44 result / serial phase proposal66

Native44 exits1 with158 final native errors: {"pcb_trace_error": 36, "pcb_pad_trace_clearance_error": 11, "pcb_via_trace_clearance_error": 78, "pcb_pad_pad_clearance_error": 3, "pcb_via_clearance_error": 26, "pcb_placement_error": 4}. PeakRSS2410080KiB; no OOM counter increase. Source65 all12 prerequisites/47CAM/browser0 and111/115authored preflights were successful, but these automatic copper contacts/clearance/drill violations reject fullnative44. No fabrication/publication pass.

Source66 now explicitly partitions the33 automatic nets into32 supported native phases: USB5V/REG_EN together, remaining power before signals, GND last. Subsequent phases receive earlier generated copper as native obstacles. This tests whether inter-net simultaneous routing accounts for the rejected copper; it is a proposed routing order, not a demonstrated fix. Same locked pipeline7/public algorithmFn,65parts/poses/nets/widths/two layers/.30-.45vias/final rules and serial memory guards. New qualification/fullnative45/final audits remain required.


## Actual staged native45 failure

Fullnative45 exited1: {"pcb_autorouting_error": 1, "pcb_port_not_connected_error": 123, "pcb_trace_error": 1}. The solver reports Jq ran out of iterations before complete copper.123unconnected-port errors and one danglingtrace are real failed-output conditions, not a passing route or a JLCPCB import issue. PeakRSS4113808KiB, no OOM increase. Its source,57phase plan, actual native inputs/log/output/errors/resources are retained. No board/fabrication/publication pass.

A separate typed generic strict-clearance grid routing experiment is prepared outside the checkout. Its actual3tests/81assertions and strictTypeScript check pass under the unchanged guard. The full33-net SRJ benchmark is now running; no source selection or board pass yet. Existing locked dependencies/archives remain unchanged.
