# 099 — Project paste attribution assumes centred apertures

Classification: project CAM checker defect, not a component importer defect.

The exact native C23239/C23093/C23138 0603 imports contain asymmetric paste
apertures. Their centroids differ from the corresponding copper-pad centroids
by approximately 0.089mm. The old `review-r8-process.py` required coincidence
within 0.0001mm and rejected ten apertures that uniquely overlap their own lands.
The actual reproduction is retained in
`evidence/R8-rgbw-port-2026-10-06/paste-centroid-attribution-reproduction.json`.

The project checker now attributes apertures by positive-area copper overlap
on the same layer, requiring exactly one land and the correct component owner.
It rejects orphan, foreign-owner, wrong-layer and bridging apertures. Existing
stencil release, full-land coverage and manufacturing thresholds are unchanged.
The native imports and emitted paste geometry are unchanged. Actual aperture
overprint and stencil transfer still require the retained process review and
supplier/physical qualification.

Three regression cases distinguish valid offset apertures from bridges and
orphan/foreign/wrong-layer apertures. Actual execution is retained in
`evidence/R8-rgbw-port-2026-10-06/checks/paste-attribution-regression.log`.
