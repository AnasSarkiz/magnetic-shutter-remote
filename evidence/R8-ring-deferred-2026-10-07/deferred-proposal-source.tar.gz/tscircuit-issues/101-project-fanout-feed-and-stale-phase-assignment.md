# 101 — Project routing inputs: extended fanout feed and stale VSET phase

Classification: project source/configuration defect; not a proven importer or
router-library defect. Observed 2026-10-06 while adding the R8 RGBW port.

The first routed candidate appended a long battery supply branch inside
R8_POWER_LOOPS. Native placement reported this fanout boundary overlapping
USB_DISABLE_ESCAPE, SENSOR_ESCAPE, HOT_SET_ESCAPE, COLD_GROUND_ESCAPE and
TEMP_MOSFET_ESCAPE. Separately, VSET still selected saved routing phase 2 after
the moved R8 path was removed. Native routing rejected that incomplete phase
with `pcbTracePaths must cover every connection in the phase; missing:
source_net_12`. Its disconnected-port errors are downstream of that abort.

Reproduction and actual failed CircuitJSON/source/log are preserved under
`evidence/R8-rgbw-port-2026-10-06/failed-route01/` and
`checks/native-route01.log`. They are never current passing evidence.

Source correction places the long radio/light supply branches in ordinary
native trace paths outside local switching fanouts. VSET is removed from the
saved phase and assigned a new native routing phase. Remote C17 also remains
outside the local boost fanout, without changing its position or connections.
The remaining networks are solved serially in native phases to isolate
congestion. Full native DRC, independent physical copper and power checks
remain required; these source corrections alone do not prove routing passed.

Interrupted route02/03 did not write new CircuitJSON. Their retained output
provenance explicitly identifies the previous failed output. Route04 captures
native routing inputs with supported CLI diagnostics and a bounded timeout.
No generated CircuitJSON, imported component, library or check threshold was
patched. Original 075/076 and the separate missing 3V3 metadata importer issue
remain explicit.

## Authored enable-via collision found before completion of route11

The route11 source placed U6.pin2's0.45mm EN via at(-1.95,14.3). The
R15.pin1 feedback bottom trace ran from(-0.5,15) to(-2.9,13.5), width0.15mm.
The via centre is approximately0.175mm from that segment; their combined
copper radii are0.300mm. This is an authored cross-net overlap, independent
of whether those nets' later solver phases return zero errors. Route11 was
intentionally stopped and its source, native inputs, resource log and stale
output provenance retained. It is not passing routing evidence.

The source moves the EN via to(-1.15,13.75) and raises the escape's horizontal
segment to14.1mm. `scripts/review-r8-authored-paths.py` compares all light
fanout via/trace copper against the native source-port net identities before
routing. Its regression rejects the actual archived route11 source and
accepts the corrected source. This limited early check does not replace full
native and independent routed copper, pad, drill and clearance checks.

The corrected via changed the earlier native routing topology. Route12's USB
power phase stopped yielding progress and did not return on the requested
three-minute timeout. The intentionally stopped run lasted5m17s overall,
with no OOM counters and no new routed CircuitJSON; native input/source/log
and output provenance are retained. Source routing order now prioritizes
USB5V before REG_EN, preserving every component, pin contract, authored route
coordinate and design-rule threshold. Route13's USB5V and REG_EN phases both
complete with zero solver errors. Those individual phase results do not prove
full-board routing or manufacturing correctness; final checks remain required.

Route13 completed the new light networks and existing controls through the
cold-temperature setting with zero individual solver errors. TEMP_OK then
stopped yielding progress after its port-point stage. Its actual native input
has three bottom breakout endpoints and the moved R12 pin2 on top. The run
was intentionally stopped375s after that phase input was written, without OOM
or complete routed output. This is preserved as an interrupted candidate,
not a proven library defect or full-board pass.

A new ordinary native PCB path gives R12 pin2 an off-pad through-via at
(19.65,10.496636), retaining R12's supplier land, values and placement. It uses
the component's270-degree frame and the documented native PcbPath API, outside
fanout bounds. Final native and independent hole/pad/copper checks remain
mandatory. Old unused R12 paths and all prior evidence are preserved.

Route14 confirms the new R12 escape's actual native position, but USB5V's
point-path solver returns `Jq ran out of iterations`. Its actual partial
CircuitJSON has zero independent manufacturing geometry violations; this
does not validate missing routes or complete-board current. The next source
also escapes R12's USB pull-up pin1 to(19.65,12.003364), width0.3mm, so both
R12 nets can use bottom routing without an implicit transition near the body.
Component positions, values, imports and all design-rule limits are unchanged.


Route15 materializes both authored R12 via paths, but its native USB routing
input still retains R12 pin1 as the original top-pad endpoint. Ordinary
PcbPath copper alone does not provide the explicit bottom breakout required
by this routing strategy. The interrupted run did not write new CircuitJSON;
its output is byte-identical to failed route14, with corrected provenance.

R12 now uses native fanout paths for both pins, so its two off-pad vias are
explicit bottom breakouts. These remain routing directives; the root
routing-disabled build has no traces or vias. Native source trials16–20
that stopped progressing and were intentionally terminated are retained.
Their source variations do not establish the cause of those stalls.

The native21 profiled CLI root build completes successfully, with65 fitted
components, zero native errors and zero traces/vias. Its actual CPU report
shows filesystem sorting/scanning as significant work, but does not establish
a root cause for the earlier non-yielding runs. Both direct native renderer
diagnostics and CLI logs are retained under runtime-diagnostics21. The heavy
job guard always runs commands at the board repository ROOT; preparing a
smaller source copy did not change those commands' working directory. No
smaller-directory performance conclusion, imported-component defect or
source-wrapper causal claim is supported. Full fresh source/placement gates
and routed/independent checks remain required.


## USB parent-net follow-up — 2026-10-07

Native route16 includes the actual corrected R12 bottom endpoint, but USB5V still returns Jq iteration exhaustion; the unmodified locked solver reproduces it on the retained input. Source30 added native C1/Q1/R13 off-pad through-via escapes. Its12 pre-routing checks and actual browser0 style gate pass, with all65 fitted poses/contracts unchanged. Route17's actual USB input has all bottom endpoints, but the run stalls for>7min without honoring the requested3min timeout; it was intentionally terminated after SIGINT/SIGTERM did not end it. Exit137 is explicitSIGKILL, not OOM or a completed native solver verdict; no new CircuitJSON was written. Resource/provenance receipts retain this distinction.

A supported locked local beta_pipeline4 trial18 returns FZ iteration exhaustion on USB5V in18.7s and separately generates a real fanout boundary overlap between USB_ESCAPE and USB_INPUT_CAP_ESCAPE. The source now moves C1 into the existing USB_ESCAPE group, without changing fitted poses/imports/values/nets, and tests the supported local beta_pipeline9 algorithm after fresh placement/style gates31. This is a native source/configuration design change, with unchanged clearance/via rules and full routed/native/independent audits still mandatory. Neither iteration exhaustion alone nor this fixed board-level group overlap proves a component importer defect or upstream root cause. See the actual route16/17/18 receipts and unrouted31-check-results.json when completed.
