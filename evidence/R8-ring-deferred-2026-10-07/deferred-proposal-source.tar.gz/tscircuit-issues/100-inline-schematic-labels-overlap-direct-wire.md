# 100 — Inline schematic labels overlap a direct wire

Classification: observed native schematic routing/label placement issue;
upstream root cause not fully established, no upstream fix claimed.

The R8 light sheet's horizontally aligned U8.Y and R19.pin1 generated two
`RING_BUFFER_OUT` text elements across the connecting wire. The latest actual
browser Style Analysis reported two text/trace collisions. The pinned CLI
schematic-placement checker reported zero, so CLI success alone did not establish
current browser style compliance. Original inputs and actual screenshots/SVGs
are retained in `evidence/R8-rgbw-port-2026-10-06/unrouted/placement07/` and
`unrouted07-trusted-ui/` beneath that evidence directory.

An explicit trace with `schDisplayLabel` retained both canonical net-name labels
and did not resolve the issue; the placement08 input and browser output remain.
Moving R19's schematic position from y=-3 to y=-1 separates the wire/label
geometry without changing any pin, net, value or PCB pose. The actual native
browser analysis of placement09 reports zero issues. No generated Circuit JSON,
import, analyzer or check threshold was edited or suppressed.
