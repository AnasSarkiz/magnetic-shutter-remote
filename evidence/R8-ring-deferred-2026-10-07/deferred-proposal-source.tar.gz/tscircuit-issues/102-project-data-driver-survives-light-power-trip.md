# 102 — Project light data driver used an independent supply after latch-off

Classification: board source fault-state defect, not an importer or router bug.

The initial RGBW-port candidate powered U8/SN74AHCT1G125, its C19 bypass and
R21 OE pull-up from RING_5V_RAW. The accessory J4 pin2 used the separately
latched-off RING_5V. If U7 trips while GPIO1 stays high and GPIO0 carries data,
Q3 continues enabling a powered data output into an unpowered accessory. The
330ohm series resistor limits current but does not establish the unspecified
ring's permitted input injection. No physical damage or observed current is
claimed; the actual native pin/net contracts demonstrate the independent
power domains.

The exact prior native JSON is retained at
`evidence/R8-rgbw-port-2026-10-06/unrouted-enable14-qualified/circuit.json`.
That directory records earlier source/placement gates, not approval of this
fault state. Route10 was intentionally stopped before source edits; its
provenance identifies the unchanged unrouted output and claims no routing pass.

Correction: U8 VCC, C19 and R21 now share U7's switched output with J4.
C19 retains the previously qualified native PCB placement; its schematic X coordinate is11.8 to group it with C18 on the shared switched supply. Fresh browser and CLI analyses pass zero issues. A rejected trial PCB position also overlapped SW1's measured courtyard; see `evidence/R8-rgbw-port-2026-10-06/C19-rejected-placement-review.json`. Changed-placement renders stalled and are preserved without a root-cause/library-bug claim. The corrected domains build natively with the original PCB pose. Manufacturer
input leakage is specified at VCC0–5.5V, accepting a powered MCU input without
an invented output Ioff guarantee. The actual circuit-domain audit rejects
the archived candidate. A second audit measures routed copper and the DBV
load-switch135mOhm maximum resistance against U8's4.5V operating minimum.
Regression tests reject the actual old domains and excessive supply loss.

All affected schematic/placement/routing/current/fabrication checks must run
again before prototype publication. Firmware low-data-before-enable, fault
shutdown/recovery, power-ramp/transient/DI behavior, exact ring and protected
battery/harness remain qualification gates. Original075/076 and the separate
missing3V3 metadata importer issue are unrelated and remain explicit.
