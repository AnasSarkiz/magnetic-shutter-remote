# Native repair scoring uses fixed relaxed copper clearance

Classification: upstream autorouter policy mismatch, separate from JLCPCB
importer metadata and the original module qualification issues075/076.

The installed `@tscircuit/capacity-autorouter`0.0.951 source map and the official
source at npm `gitHead`785dad5e35bfc692758128d4a08c67763b122331 both show
`create-pipeline7-autorouting-drc-evaluator.ts` setting `traceClearance` and
`viaClearance` to fixed0.10mm constants when creating its repair DRC engine.
The board's0.15mm minimum and supplied0.30mm route-time field do not replace
those two options. The same native repair engine scores overlapping nets
using these options; a0.115mm gap can satisfy its relaxed copper score while
failing the board's native final clearance check.

This is source-level proof of the policy mismatch, not a claim that every
R8 failure has this cause. Actual route44 also contains contacts, drill gaps
and vias over SMT pads. Complete copper, drill, connection and width audits
remain mandatory. The current staged route45 is an explicit source routing
order experiment; it has not yet passed final DRC.

Exact official npm metadata, extracted installed source, source archive URL
and SHA256 are retained under
`evidence/R8-rgbw-port-2026-10-06/router-clearance-source-diagnostic/`.
The source archive is read-only diagnostic input outside the board checkout.
No existing dependency, lockfile, vendor archive, baseline or checker was
changed for this diagnosis. No package or public issue was published.

A proposed fix must propagate declared copper and drill clearances into
routing/repair, retain actual preloaded copper obstacles, and pass both
native final and independent geometry checks. Increasing an early obstacle
margin alone has not fixed the retained failures. Missing `3V3` power metadata
remains a separate importer issue.
