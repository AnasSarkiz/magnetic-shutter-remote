#106 — Native cleanup rejects duplicate current-limit endpoints

Classification: observed native capacity-autorouter cleanup exception; source-authored routing workaround under qualification, upstream unresolved. Not a JLCPCB stock/import defect or missing3V3 metadata issue.

Exact locked @tscircuit/capacity-autorouter0.0.951 / nativebeta_pipeline9, supported2x, noCPUprofiler, clean complete source-closure build. Native58 all12 fresh source/placement/UI/assembly prerequisites pass. Native38 joins all34automatic nets after supported authoredOE/control phases; routing and jointrepair run, then effortCleanupSolver throws `TraceSimplificationSolver cannot preserve endpoints for duplicate route "source_net_33"`, rendered as net.RING_ILIM. The exact input has one ILIM connection with two distinct valid top pads: U7.pin5(13.3,3.749096),R16.pin1(15.75,3.253364), width0.15mm. No handwritten CircuitJSON or conflicting duplicate schematic connection is used.

Retained reproducible inputs/results: evidence/R8-rgbw-port-2026-10-06/route38/source/, complete-native-source-closure.json, native-command.json, native-inputs/phase-3.input.simple-route.json, phase-3.error.json, checks/native-route38.log and route38-resources.json. Actual nativeexit1/peakRSS3189744KiB/noOOM. No partial output is a passing board.

Source59 adds one complete, supported autoroutingphase1 path from U7.pin5 to R16.pin1 on top,0.15mm, ahead of savedcontrolphase2/globalautomaticphase3. Original parts/poses/pins/values, two-layer via definitions, libraries/toolchain and independent rules are unchanged. The native path API and all routing/clearance/physical-connectivity/width/current/export checks remain authoritative. Fresh qualifications/fullnative39/final checks are still required; no engine fix or finished routing/order approval is claimed.

## Initial source-path rejection59 / corrected corridor60

Initial source59 completes nativebuild/five source checks but fails the existing45CAM regression suite: proposed ILIM path crosses U7.pin4/FAULT. This is a separate project source-routing mistake, not an additional importer defect. Exact rejectedsource and nativebuild output/logs remain in unrouted-native59 and native59-check-results.json. It was never routed or published as passing.

Source60 escapes U7.pin5 vertically to y4.6, runs above the adjacent FAULT land, then reaches R16.pin1 vertically. This also maintains clearance from the retained OE off-pad barrel; imports, poses, values and DRC rules stay unchanged. The unchanged source preflight/regressions and full qualifications must actually pass before native40. Native39 was prepared but never run after prerequisite59 failed.

## Actual source60/native40 result

All12 fresh source60 qualifications pass, including existing45CAM tests and actual current browser0style. Native40 successfully completes the ILIM path and all33 remaining automatic nets without the duplicate-endpoint exception. Upstream bug remains unresolved. Full native40 instead fails80 final clearance/drill/placement errors; see107. This is a successfully avoided exception, not a passing-board claim.
