# 103 — Source placement generation stalls before analysis

Classification: observed native CLI/source-generation stall; root cause is not established. No importer, source-wrapper or filesystem causality is claimed.

The R8 0.3.13 source-entrypoint placement check did not complete and was interrupted with exit 137. Its original command, log, input and resource receipt remain in `evidence/R8-rgbw-port-2026-10-06/native21-unrouted-check-results.json` and `checks/native21-placement.log`. No cgroup OOM was observed. It is not a passing check.

The same active source successfully generated a fresh native unrouted build. Source netlist, pin specification, source and schematic-placement checks separately completed with exit zero. The resulting Circuit JSON contains 65 fitted components, no PCB traces/vias and no generated error elements; its SHA256 is `3f7564d77ef23d85bc3d9989848c1ed9e42b8180c54a88ba5bd864bb47fe31f4`.

The installed CLI explicitly supports prebuilt Circuit JSON for placement. `getCheckPlacementResult` sets `allowPrebuiltCircuitJson: true`, then applies the same `analyzeAllPlacements` and placement-filtered native DRC diagnostics to either input. The supported command completed:

```sh
python3 cloud/run-heavy.py -- tsci check placement dist/index/circuit.json
```

Actual result: zero placement issues, zero placement DRC errors, three separately accepted connector-direction metadata warnings. Receipt: `checks/native22-placement-generated-json.log`; the exact four source checks plus generated-JSON placement check are recorded in `native22-unrouted-check-results.json`.

This avoids repeating the stalled source-generation step without replacing or weakening placement analysis. It does not relabel the interrupted source command as successful, prove the stall fixed upstream, or qualify routed copper. The native full build and all routed connectivity/shorts/width/current/fabrication checks are still required. Subsequent browser analyzer certificate failure is a separate environment prerequisite.

The unchanged `cloud/run-heavy.py` always runs its child from the repository root. A diagnostic staging directory supplied as the wrapper's outer working directory did not alter that behavior; no reduced filesystem scope or causal fix is inferred from that trial. Original diagnostic and unsuccessful inputs remain retained.

## Current direct source check follow-up,2026-10-07

All5 canonical direct source commands now actually exit0 in the exact native complete-source-closure task build directory, including placement (native36/37/38). The installed analyzer/CLI/dependencies, every source import and native placement criteria are unchanged. Root attempts35 measured the separate host65,530 mapping limit and remain interrupted137; the profiled root retry printing zero errors but stalling on shutdown is not an exit-zero command. Earlier original103 cause was not measured and is not retroactively assigned. See issue104, native38-source-closure.json and native38-check-results.json. This is current source-check qualification, not a routed-copper pass.
