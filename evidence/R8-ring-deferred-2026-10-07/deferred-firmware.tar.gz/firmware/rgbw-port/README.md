# R8 RGBW firmware successor

This variant retains the original BLE HID shutter and three-second PAIR hold.
A short PAIR press cycles OFF, white, red, green, blue. No extra PCB button is
needed. It targets one12-pixel Adafruit2852 SK6812RGBW ring through J4.
The old firmware/source/artifacts are preserved unchanged.

GPIO0 carries addressable data through the fitted5V buffer. GPIO1 enables
both the switched light supply and output driver. GPIO3 receives the
active-low latched fault. SPI2 emits encoded data onGPIO0; its clock on the
otherwise unconnected moduleGPIO10/pin17 is not a ring connection. UART stays
disabled in the application; bootloader programming uses J3 and manual
BOOT/RESET with battery power and USB-C disconnected.

Startup is OFF. A fault interrupt disablesGPIO1 without waiting for a frame or
BLE loop. One deliberate short press acknowledges a fault while still off;
another requests light. Persistent faults prevent restart. No automatic
fault retry is used. The external hardware latch-off remains authoritative.

Each pixel's sum ofRGBW channel commands must be<=255; the encoder rejects
higher totals. Full white or one full colour is allowed. Full simultaneous
RGBW is prohibited. The estimated12-channel/standby draw is228mA based on the
product's typical18mA/channel and1mA/pixel, below the350mA normal design budget;
this is not a guaranteed or measured current. Actual current, startup, thermal,
fault and photo flicker/colour performance require prototype measurements.

SPI requests6.4MHz:0xC0 encodes zero and0xF0 encodes one. At nominal frequency
the pulse times are0.3125/0.9375us and0.625/0.625us, within the retained
SK6812RGBW Rev01 table; reset-low is>=100us. The final encoded bit is low,
and MOSI remains under SPI control. Measure the actual divider and waveform.
The retained manufacturer table specifiesRGBW byte order; verify the incoming
Adafruit ring's actual colour order before accepting optical tests.

Build only after board qualification, serially from repository root:

```sh
PATH="$PWD/firmware/.venv/bin:$PATH" \
ZEPHYR_SDK_INSTALL_DIR="$PWD/firmware/zephyr-sdk-0.17.2" \
python3 cloud/run-heavy.py -- sh firmware/rgbw-port/build.sh --cmake
```

The build output is separate at`.codex/runtime/firmware-rgbw-build`.
An actual target build and image validation are required before a firmware
release claim. No physical board, iPhone, RGBW ring or battery test is implied.
