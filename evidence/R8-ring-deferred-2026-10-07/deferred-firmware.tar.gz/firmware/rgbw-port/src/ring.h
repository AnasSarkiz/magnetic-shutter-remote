/* SPDX-License-Identifier: Apache-2.0 */
#ifndef R8_RING_H
#define R8_RING_H
int ring_init(void);
void ring_service(void);
void ring_cycle(void);
#endif
