/* SPDX-License-Identifier: Apache-2.0 */
#include <errno.h>
#include <string.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/spi.h>
#include <zephyr/sys/atomic.h>
#include "ring.h"
#include "ring-encoding.h"

static const struct gpio_dt_spec enable = {
	.port = DEVICE_DT_GET(DT_NODELABEL(gpio0)), .pin = 1,
	.dt_flags = GPIO_ACTIVE_HIGH
};
static const struct gpio_dt_spec fault_input = {
	.port = DEVICE_DT_GET(DT_NODELABEL(gpio0)), .pin = 3,
	.dt_flags = GPIO_ACTIVE_LOW
};
static const struct device *const spi = DEVICE_DT_GET(DT_NODELABEL(spi2));
static const struct spi_config spi_config = {
	.frequency = 6400000,
	.operation = SPI_OP_MODE_MASTER | SPI_WORD_SET(8) | SPI_TRANSFER_MSB,
	.slave = 0
};
static struct gpio_callback fault_callback;
static atomic_t fault_latched;
static unsigned int mode;
static uint8_t encoded[R8_RING_PIXELS * R8_RING_PIXEL_SPI_BYTES];

static void ring_disable(void)
{
	gpio_pin_set_dt(&enable, 0);
	mode = 0;
}

static void fault_irq(const struct device *port, struct gpio_callback *callback,
	uint32_t pins)
{
	ARG_UNUSED(port); ARG_UNUSED(callback); ARG_UNUSED(pins);
	/* Fault handling never waits for a frame or the BLE application loop. */
	gpio_pin_set_dt(&enable, 0);
	atomic_set(&fault_latched, 1);
}

static int send_channels(const struct ring_channels *channels)
{
	if (!ring_encode_pixel(channels, encoded)) return -ERANGE;
	for (unsigned int pixel = 1; pixel < R8_RING_PIXELS; pixel++) {
		memcpy(encoded + pixel * R8_RING_PIXEL_SPI_BYTES, encoded,
			R8_RING_PIXEL_SPI_BYTES);
	}
	struct spi_buf buffer = {.buf = encoded, .len = sizeof(encoded)};
	const struct spi_buf_set buffers = {.buffers = &buffer, .count = 1};
	int err = spi_write(spi, &spi_config, &buffers);
	/* The last encoded bit is low; keep MOSI under SPI pin control. */
	k_busy_wait(100);
	return err;
}

int ring_init(void)
{
	if (!gpio_is_ready_dt(&enable) || !gpio_is_ready_dt(&fault_input)) return -ENODEV;
	if (gpio_pin_configure_dt(&enable, GPIO_OUTPUT_INACTIVE) ||
		gpio_pin_configure_dt(&fault_input, GPIO_INPUT)) return -EIO;
	if (!device_is_ready(spi)) return -ENODEV;
	gpio_init_callback(&fault_callback, fault_irq, BIT(fault_input.pin));
	if (gpio_add_callback(fault_input.port, &fault_callback) ||
		gpio_pin_interrupt_configure_dt(&fault_input, GPIO_INT_EDGE_TO_ACTIVE)) return -EIO;
	const struct ring_channels blank = {0};
	int err = send_channels(&blank);
	ring_service();
	return err;
}

void ring_service(void)
{
	if (gpio_pin_get_dt(&fault_input) != 0) atomic_set(&fault_latched, 1);
	if (atomic_get(&fault_latched)) ring_disable();
}

void ring_cycle(void)
{
	if (atomic_get(&fault_latched)) {
		/* One deliberate press acknowledges while off; another requests light. */
		ring_disable();
		k_sleep(K_MSEC(2));
		if (gpio_pin_get_dt(&fault_input) == 0) atomic_clear(&fault_latched);
		return;
	}
	unsigned int next_mode = (mode + 1) % 5;
	if (!next_mode) { ring_disable(); return; }
	if (!mode) {
		/* Serialize the enable edge with the fault interrupt. A pending IRQ
		 * runs after unlock and immediately removes power. */
		unsigned int key = irq_lock();
		int enable_error = (atomic_get(&fault_latched) ||
			gpio_pin_get_dt(&fault_input) != 0) ? -EIO :
			gpio_pin_set_dt(&enable, 1);
		irq_unlock(key);
		if (enable_error) {
			atomic_set(&fault_latched, 1);
			ring_disable();
			return;
		}
		k_sleep(K_MSEC(2));
		const struct ring_channels blank = {0};
		if (send_channels(&blank)) { atomic_set(&fault_latched, 1); ring_disable(); return; }
	}
	struct ring_channels channels = {0};
	switch (next_mode) {
	case 1: channels.white = 255; break;
	case 2: channels.red = 255; break;
	case 3: channels.green = 255; break;
	case 4: channels.blue = 255; break;
	}
	if (gpio_pin_get_dt(&fault_input) != 0 || atomic_get(&fault_latched) ||
		send_channels(&channels)) {
		atomic_set(&fault_latched, 1);
		ring_disable();
		return;
	}
	mode = next_mode;
	ring_service();
}
