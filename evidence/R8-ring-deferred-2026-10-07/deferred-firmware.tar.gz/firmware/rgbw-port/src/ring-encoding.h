/* SPDX-License-Identifier: Apache-2.0 */
#ifndef R8_RING_ENCODING_H
#define R8_RING_ENCODING_H
#include <stdbool.h>
#include <stdint.h>

#define R8_RING_PIXELS 12
#define R8_RING_PIXEL_SPI_BYTES 32

struct ring_channels {
	uint8_t red;
	uint8_t green;
	uint8_t blue;
	uint8_t white;
};

/* SK6812RGBW Rev01 declares R,G,B,W, MSB first. Confirm incoming ring order. */
bool ring_encode_pixel(const struct ring_channels *channels,
	uint8_t encoded[R8_RING_PIXEL_SPI_BYTES]);
#endif
