/* SPDX-License-Identifier: Apache-2.0 */
#include "ring-encoding.h"

bool ring_encode_pixel(const struct ring_channels *channels,
	uint8_t encoded[R8_RING_PIXEL_SPI_BYTES])
{
	uint16_t channel_sum = (uint16_t)channels->red + channels->green +
		channels->blue + channels->white;
	if (channel_sum > 255) return false;
	const uint8_t ordered[] = {
		channels->red, channels->green, channels->blue, channels->white
	};
	for (unsigned int channel = 0; channel < 4; channel++) {
		for (unsigned int bit = 0; bit < 8; bit++) {
			encoded[channel * 8 + bit] =
				(ordered[channel] & (0x80 >> bit)) ? 0xf0 : 0xc0;
		}
	}
	return true;
}
