#!/bin/sh
set -eu
task_root="$PWD"
export ZEPHYR_BASE="$task_root/firmware/deps/zephyr"
: "${ZEPHYR_SDK_INSTALL_DIR:?Set the task-local pinned Zephyr SDK directory}"
export ZEPHYR_TOOLCHAIN_VARIANT=zephyr
cd "$task_root/firmware/deps"
exec ../.venv/bin/python -m west build -b esp32c3_devkitc/esp32c3 ../rgbw-port -d ../../.codex/runtime/firmware-rgbw-build "$@"
