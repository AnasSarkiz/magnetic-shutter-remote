/* SPDX-License-Identifier: Apache-2.0 */
#include <assert.h>
#include <string.h>
#include "ring-encoding.h"

int main(void)
{
	uint8_t frame[R8_RING_PIXEL_SPI_BYTES];
	struct ring_channels channels = {0};
	assert(ring_encode_pixel(&channels, frame));
	for (unsigned int i = 0; i < sizeof(frame); i++) assert(frame[i] == 0xc0);
	channels.white = 255;
	assert(ring_encode_pixel(&channels, frame));
	for (unsigned int i = 0; i < 24; i++) assert(frame[i] == 0xc0);
	for (unsigned int i = 24; i < 32; i++) assert(frame[i] == 0xf0);
	channels = (struct ring_channels){.red = 128};
	assert(ring_encode_pixel(&channels, frame));
	assert(frame[0] == 0xf0);
	for (unsigned int i = 1; i < 32; i++) assert(frame[i] == 0xc0);
	channels = (struct ring_channels){85, 85, 85, 0};
	assert(ring_encode_pixel(&channels, frame));
	for (unsigned int channel = 0; channel < 3; channel++) {
		for (unsigned int bit = 0; bit < 8; bit++) {
			assert(frame[channel * 8 + bit] == ((bit % 2) ? 0xf0 : 0xc0));
		}
	}
	uint8_t prior[sizeof(frame)];
	memcpy(prior, frame, sizeof(frame));
	channels = (struct ring_channels){64, 64, 64, 64};
	assert(!ring_encode_pixel(&channels, frame));
	assert(memcmp(prior, frame, sizeof(frame)) == 0);
	channels = (struct ring_channels){255, 255, 255, 255};
	assert(!ring_encode_pixel(&channels, frame));
	assert(memcmp(prior, frame, sizeof(frame)) == 0);
	return 0;
}
