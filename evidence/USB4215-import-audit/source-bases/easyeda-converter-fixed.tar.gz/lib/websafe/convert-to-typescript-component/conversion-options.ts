import { z } from "zod"

/** Manufacturer-verified metadata absent from the supplier CAD document. */
export const conversionOptionsSchema = z.object({
  switchType: z.enum(["spst", "spdt", "dpst", "dpdt"]).optional(),
  insertionDirection: z
    .enum([
      "from_top",
      "from_bottom",
      "from_left",
      "from_right",
      "from_above",
      "from_below",
    ])
    .optional(),
})
export type ConversionOptions = z.infer<typeof conversionOptionsSchema>
