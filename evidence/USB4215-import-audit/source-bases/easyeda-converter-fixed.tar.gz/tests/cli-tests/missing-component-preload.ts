// Deterministic public-library absence; no network or alternate component.
globalThis.fetch = Object.assign(
  async () => Response.json({ success: true, result: { lists: { lcsc: [] } } }),
  { preconnect: globalThis.fetch.preconnect },
)
