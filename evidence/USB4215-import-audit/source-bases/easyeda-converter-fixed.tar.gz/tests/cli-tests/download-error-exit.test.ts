import { expect, test } from "bun:test"
import { mkdtemp, rm, stat } from "node:fs/promises"
import { tmpdir } from "node:os"
import { join } from "node:path"

test("download failure exits nonzero and writes no supplier footprint", async () => {
  const directory = await mkdtemp(join(tmpdir(), "easyeda-download-test-"))
  const outputFilename = join(directory, "missing.raweasy.json")
  try {
    const child = Bun.spawn(
      [
        process.execPath,
        "--preload",
        join(import.meta.dir, "missing-component-preload.ts"),
        "cli/main.ts",
        "download",
        "--input",
        "C5438410",
        "--output",
        outputFilename,
      ],
      { cwd: join(import.meta.dir, "../.."), stdout: "pipe", stderr: "pipe" },
    )
    const [exitCode, stdout, stderr] = await Promise.all([
      child.exited,
      new Response(child.stdout).text(),
      new Response(child.stderr).text(),
    ])
    expect(exitCode).toBe(1)
    expect(stdout).not.toContain("Downloaded JSON footprint")
    expect(stderr).toContain("Component not found in EasyEDA library search")
    await expect(stat(outputFilename)).rejects.toMatchObject({ code: "ENOENT" })
  } finally {
    await rm(directory, { recursive: true })
  }
})
