import { expect, test } from "bun:test"
import { z } from "zod"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { convertEasyEdaJsonToCircuitJson } from "lib/convert-easyeda-json-to-tscircuit-soup-json"

test("preserves raw source margins and paste contours across existing import fixtures", async () => {
  const partNumbers = [
    "C1046",
    "C105419",
    "C107701",
    "C11702",
    "C12084",
    "C128415",
    "C131337",
    "C14877",
    "C1525",
    "C15464",
    "C157929",
    "C157947",
    "C158012",
    "C160354",
    "C165948",
    "C17168",
    "C18185602",
    "C19076967",
    "C19795120",
    "C2040",
    "C20526",
    "C22446580",
    "C23689428",
    "C25744",
    "C265111",
    "C281113",
    "C2838502",
    "C2848306",
    "C2913206",
    "C2929994",
    "C2961147",
    "C2979182",
    "C309274",
    "C3178291",
    "C3273487",
    "C393941",
    "C410353",
    "C46497",
    "C46749",
    "C490691",
    "C561765",
    "C57759",
    "C5830143",
    "C6186",
    "C7203002",
    "C75749",
    "C8465",
    "C88224",
  ]
  const sourceShapeSchema = z.object({
    packageDetail: z.object({
      dataStr: z.object({ shape: z.array(z.string()) }),
    }),
  })
  for (const partNumber of partNumbers) {
    const rawSource: unknown = await Bun.file(
      new URL(`./assets/${partNumber}.raweasy.json`, import.meta.url),
    ).json()
    const rawShapes =
      sourceShapeSchema.parse(rawSource).packageDetail.dataStr.shape
    const parsed = EasyEdaJsonSchema.parse(rawSource)
    const circuitJson = convertEasyEdaJsonToCircuitJson(parsed, {
      shouldRecenter: false,
      showDesignator: false,
    })
    const lands = circuitJson.filter(
      (e) => e.type === "pcb_smtpad" || e.type === "pcb_plated_hole",
    )
    const rawPads = rawShapes.filter((s) => s.startsWith("PAD~"))
    expect(lands).toHaveLength(rawPads.length)
    for (const [index, land] of lands.entries()) {
      const fields = rawPads[index].split("~")
      const maskMm =
        fields[18] === undefined || fields[18] === ""
          ? undefined
          : Number(fields[18]) * 0.254
      if (maskMm === undefined) expect(land.soldermask_margin).toBeUndefined()
      else expect(land.soldermask_margin).toBeCloseTo(maskMm, 8)
      if (land.type === "pcb_smtpad") {
        const pasteMm =
          fields[17] === undefined || fields[17] === ""
            ? undefined
            : Number(fields[17]) * 0.254
        if (pasteMm === undefined)
          expect(land.solderpaste_margin).toBeUndefined()
        else expect(land.solderpaste_margin).toBeCloseTo(pasteMm, 8)
      }
    }
    const rawPaste = rawShapes.filter(
      (s) => /^SOLIDREGION~[56]~/.test(s) && s.split("~")[4] === "solid",
    )
    const apertures = circuitJson.filter((e) => e.type === "pcb_solder_paste")
    expect(apertures).toHaveLength(rawPaste.length)
    for (const [index, aperture] of apertures.entries()) {
      if (aperture.shape !== "polygon")
        throw new Error("Source region must remain a polygon")
      const fields = rawPaste[index].split("~")
      const points = [
        ...fields[3].matchAll(/[ML] ?(-?[\d.]+)[ ,](-?[\d.]+)/g),
      ].map((m) => ({ x: Number(m[1]) * 0.254, y: Number(m[2]) * 0.254 }))
      expect(aperture.layer).toBe(fields[1] === "5" ? "top" : "bottom")
      expect(aperture.points).toHaveLength(points.length)
      for (const [vertex, point] of aperture.points.entries()) {
        expect(point.x).toBeCloseTo(points[vertex].x, 8)
        expect(point.y).toBeCloseTo(points[vertex].y, 8)
      }
    }
  }
})
