import { expect, test } from "bun:test"
import rawEasy from "../../../inputs/minimal-paste.raweasy.json"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { convertEasyEdaJsonToCircuitJson } from "lib/convert-easyeda-json-to-tscircuit-soup-json"
import { generateFootprintTsx } from "lib/websafe/generate-footprint-tsx"

test("preserves explicit supplier paste polygons and per-pad expansion", () => {
  const parsed = EasyEdaJsonSchema.parse(rawEasy)
  expect(
    parsed.packageDetail.dataStr.shape.filter(
      (s) => s.type === "SOLIDREGION" && s.layermask === 5,
    ),
  ).toHaveLength(16)
  const circuitJson = convertEasyEdaJsonToCircuitJson(parsed, {
    shouldRecenter: false,
    showDesignator: false,
  })
  const paste = circuitJson.filter((e) => e.type === "pcb_solder_paste")
  expect(paste).toHaveLength(16)
  const sourcePaths = rawEasy.packageDetail.dataStr.shape.filter((s) =>
    s.startsWith("SOLIDREGION~5~"),
  )
  const centers = new Set<string>()
  for (const [index, aperture] of paste.entries()) {
    expect(aperture.shape).toBe("polygon")
    if (aperture.shape !== "polygon") throw new Error("Expected source polygon")
    const points = [
      ...sourcePaths[index]
        .split("~")[3]
        .matchAll(/[ML] ?(-?[\d.]+)[ ,](-?[\d.]+)/g),
    ].map((m) => ({ x: Number(m[1]) * 0.254, y: Number(m[2]) * 0.254 }))
    expect(aperture.layer).toBe("top")
    expect(aperture.points).toHaveLength(points.length)
    for (const [pointIndex, point] of aperture.points.entries()) {
      expect(point.x).toBeCloseTo(points[pointIndex].x, 8)
      expect(point.y).toBeCloseTo(points[pointIndex].y, 8)
    }
    const xs = points.map((p) => p.x),
      ys = points.map((p) => p.y)
    expect(aperture.x).toBeCloseTo((Math.min(...xs) + Math.max(...xs)) / 2, 8)
    expect(aperture.y).toBeCloseTo((Math.min(...ys) + Math.max(...ys)) / 2, 8)
    const outputXs = aperture.points.map((p) => p.x),
      outputYs = aperture.points.map((p) => p.y)
    expect(Math.max(...outputXs) - Math.min(...outputXs)).toBeCloseTo(
      Math.max(...xs) - Math.min(...xs),
      8,
    )
    expect(Math.max(...outputYs) - Math.min(...outputYs)).toBeCloseTo(
      Math.max(...ys) - Math.min(...ys),
      8,
    )
    centers.add(`${aperture.x},${aperture.y}`)
  }
  expect(centers.size).toBe(16)
  const lands = circuitJson.filter(
    (e) => e.type === "pcb_smtpad" || e.type === "pcb_plated_hole",
  )
  expect(lands).toHaveLength(16)
  for (const land of lands)
    expect(land.soldermask_margin).toBeCloseTo(0.0508, 8)
  const tsx = generateFootprintTsx(circuitJson)
  expect(tsx.match(/<solderpaste /g)).toHaveLength(16)
  expect(tsx.match(/solderPasteMargin=/g)).toHaveLength(12)
  expect(tsx.match(/solderMaskMargin=/g)).toHaveLength(16)
})
