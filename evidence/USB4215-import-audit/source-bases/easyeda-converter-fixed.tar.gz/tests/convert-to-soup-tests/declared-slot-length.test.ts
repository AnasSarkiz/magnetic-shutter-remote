import { expect, test } from "bun:test"
import { convertEasyEdaJsonToCircuitJson } from "lib/convert-easyeda-json-to-tscircuit-soup-json"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { ShapeItemSchema } from "lib/schemas/package-detail-shape-schema"
import fixture from "../assets/C75749.raweasy.json"

// EasyEDA footprint-local XY, in 10 mil units. Unequal copper margins must
// not determine the physical drill dimensions.
for (const rotation of [0, 90, 180, 270]) {
  test(`preserves declared 1.2 mm slot at ${rotation} degrees`, () => {
    const easyEda = EasyEdaJsonSchema.parse(fixture)
    const pad = ShapeItemSchema.parse({
      type: "PAD",
      data: `OVAL~0~0~4.3307~7.0866~11~~1~1.1811~~${rotation}~test-slot~4.7244~~Y~0~0~0`,
    })
    easyEda.packageDetail.dataStr.shape = [pad]
    const holes = convertEasyEdaJsonToCircuitJson(easyEda).filter(
      (e) => e.type === "pcb_plated_hole",
    )
    expect(holes).toHaveLength(1)
    const hole = holes[0]!
    if (hole.shape !== "pill")
      throw new Error("Expected oval copper / pill drill")
    expect(hole.hole_width).toBeCloseTo(0.6, 4)
    expect(hole.hole_height).toBeCloseTo(1.2, 4)
    expect(hole.outer_width).toBeCloseTo(1.1, 4)
    expect(hole.outer_height).toBeCloseTo(1.8, 4)
    expect(hole.ccw_rotation).toBe(rotation)
  })
}
test("oval copper does not imply a slotted drill", () => {
  const easyEda = EasyEdaJsonSchema.parse(fixture)
  easyEda.packageDetail.dataStr.shape = [
    ShapeItemSchema.parse({
      type: "PAD",
      data: "OVAL~0~0~4~8~11~~1~1~~0~test-round~0~~Y~0~0~0",
    }),
  ]
  const hole = convertEasyEdaJsonToCircuitJson(easyEda).find(
    (e) => e.type === "pcb_plated_hole",
  )
  if (!hole || hole.shape !== "pill") throw new Error("Expected plated pad")
  expect(hole.hole_width).toBeCloseTo(0.508, 4)
  expect(hole.hole_height).toBeCloseTo(0.508, 4)
})
