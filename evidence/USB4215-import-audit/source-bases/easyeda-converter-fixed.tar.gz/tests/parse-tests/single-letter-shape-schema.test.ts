import { it, expect } from "bun:test"
import { SingleLetterShapeSchema } from "lib/schemas/single-letter-shape-schema"

const examples = [
  "R~365~275~2~2~70~50~#880000~1~0~none~gge1~0~",
  "E~370~280~1.5~1.5~#880000~1~0~#880000~gge2~0",
  "P~show~0~1~355~285~180~gge5~0^^355~285^^M355,285h10~#000000^^1~368.7~289~0~GND~start~~~#000000^^1~364.5~284~0~1~end~~~#000000^^0~362~285^^0~M 365 288 L 368 285 L 365 282",
  "P~show~0~2~355~295~180~gge6~0^^355~295^^M355,295h10~#880000^^1~368.7~299~0~TRIG~start~~~#0000FF^^1~364.5~294~0~2~end~~~#0000FF^^0~362~295^^0~M 365 298 L 368 295 L 365 292",
  "P~show~0~3~355~305~180~gge7~0^^355~305^^M355,305h10~#880000^^1~368.7~309~0~OUT~start~~~#0000FF^^1~364.5~304~0~3~end~~~#0000FF^^0~362~305^^0~M 365 308 L 368 305 L 365 302",
  "P~show~0~4~355~315~180~gge8~0^^355~315^^M355,315h10~#880000^^1~368.7~319~0~RESET~start~~~#0000FF^^1~364.5~314~0~4~end~~~#0000FF^^0~362~315^^0~M 365 318 L 368 315 L 365 312",
  "P~show~0~5~445~315~0~gge9~0^^445~315^^M445,315h-10~#880000^^1~431.3~319~0~CONT~end~~~#0000FF^^1~435.5~314~0~5~start~~~#0000FF^^0~438~315^^0~M 435 312 L 432 315 L 435 318",
  "P~show~0~6~445~305~0~gge10~0^^445~305^^M445,305h-10~#880000^^1~431.3~309~0~THRES~end~~~#0000FF^^1~435.5~304~0~6~start~~~#0000FF^^0~438~305^^0~M 435 302 L 432 305 L 435 308",
  "P~show~0~7~445~295~0~gge11~0^^445~295^^M445,295h-10~#880000^^1~431.3~299~0~DISCH~end~~~#0000FF^^1~435.5~294~0~7~start~~~#0000FF^^0~438~295^^0~M 435 292 L 432 295 L 435 298",
  "P~show~0~8~445~285~0~gge12~0^^445~285^^M445,285h-10~#FF0000^^1~431.3~289~0~VCC~end~~~#FF0000^^1~435.5~284~0~8~start~~~#FF0000^^0~438~285^^0~M 435 282 L 432 285 L 435 288",
]

it("parses examples for single letter shape schema", () => {
  examples.forEach((example) => {
    expect(() => {
      try {
        SingleLetterShapeSchema.parse(example)
      } catch (error: any) {
        console.log(error)
        throw new Error(
          `Failed to parse example: ${example}. Error: ${error.message}`,
        )
      }
    }).not.toThrow()
  })
})

it("normalizes literal undefined optional text fields from EasyEDA text shapes", () => {
  const shape = SingleLetterShapeSchema.parse(
    "T~L~415~303~0~#0000FF~undefined~5.5pt~undefined~undefined~undefined~comment~TR1~1~start~gge7~0~pinpart",
  )

  expect(shape).toMatchObject({
    type: "TEXT",
    fontWeight: "normal",
    fontStyle: "normal",
    fontDecoration: "",
    backgroundColor: undefined,
    content: "TR1",
    textType: "comment",
  })
})

it("normalizes whitespace-only text metadata from C60708", () => {
  const shape = SingleLetterShapeSchema.parse(
    "T~L~355~335~0~#000000~times New Roman~5~ ~ ~~comment~1.2-3.6V~1~start~gge98~0~pinpart",
  )

  expect(shape).toMatchObject({
    type: "TEXT",
    fontWeight: "normal",
    fontStyle: "normal",
    fontDecoration: "",
    content: "1.2-3.6V",
    textType: "comment",
  })
})

it("still rejects unexpected fontStyle values", () => {
  expect(() =>
    SingleLetterShapeSchema.parse(
      "T~L~415~303~0~#0000FF~~5.5pt~~slanted~~comment~TR1~1~start~gge7~0~pinpart",
    ),
  ).toThrow(/fontStyle/)
})

it("parses schematic drawing colors, paths, and pin stems", () => {
  expect(
    SingleLetterShapeSchema.parse(
      "PT~M 395 293 L 385 300 L 395 307 Z~#880000~1~0~none~gge10~0~",
    ),
  ).toMatchObject({
    type: "PATH",
    pathData: "M 395 293 L 385 300 L 395 307 Z",
    strokeColor: "#880000",
    strokeWidth: 0.254,
    fillColor: "none",
  })

  expect(
    SingleLetterShapeSchema.parse(
      "PG~520 222 523 217 517 217~#880000~1~0~#880000~gge103~0",
    ),
  ).toMatchObject({
    type: "POLYGON",
    lineColor: "#880000",
    fillColor: "#880000",
  })

  expect(SingleLetterShapeSchema.parse(examples[2])).toMatchObject({
    type: "PIN",
    path: "M355,285h10",
  })

  expect(
    SingleLetterShapeSchema.parse(
      "A~M 400 194 A 4 4 0 1 1 400 186~~#880000~1~0~none~gge79~0",
    ),
  ).toMatchObject({
    type: "ARC",
    pathData: "M 400 194 A 4 4 0 1 1 400 186",
    start: { x: 400, y: 194 },
    end: { x: 400, y: 186 },
    color: "#880000",
    lineWidth: 1,
    sweepFlag: true,
    id: "gge79",
  })
})
