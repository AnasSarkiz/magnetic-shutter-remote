import { it, expect } from "bun:test"
import chipRawEasy from "../assets/C105419.raweasy.json"
import { convertBetterEasyToTsx } from "lib/websafe/convert-to-typescript-component"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { runTscircuitCode } from "tscircuit"
import { wrapTsxWithBoardFor3dSnapshot } from "../fixtures/wrap-tsx-with-board-for-3d-snapshot"

it("should convert C105419 into typescript file", async () => {
  const betterEasy = EasyEdaJsonSchema.parse(chipRawEasy)
  const result = await convertBetterEasyToTsx({
    betterEasy,
  })

  expect(result).not.toContain("milmm")
  expect(result).not.toContain("NaNmm")

  const circuitJson = await runTscircuitCode(
    wrapTsxWithBoardFor3dSnapshot(result),
  )
  await expect(circuitJson).toMatch3dSnapshot(import.meta.path)

  expect(result).toMatchInlineSnapshot(`
    "import type { ConnectorProps } from "@tscircuit/props"

    const pinLabels = {
      pin1: ["DAT2"],
      pin2: ["CD","DAT3"],
      pin3: ["CMD"],
      pin4: ["VDD"],
      pin5: ["CLK"],
      pin6: ["VSS"],
      pin7: ["DAT0"],
      pin8: ["DAT1"],
      pin9: ["pin9"],
      pin10: ["pin10"],
      pin11: ["pin11"],
      pin12: ["pin12"]
    } as const

    export const TF_02A = (props: ConnectorProps) => {
      return (
        <connector
          pinLabels={pinLabels}
          supplierPartNumbers={{
      "jlcpcb": [
        "C105419"
      ]
    }}
          manufacturerPartNumber="TF-02A"
          footprint={<footprint>
            <smtpad portHints={["pin1"]} pcbX="-3.00000035mm" pcbY="-1.725676mm" width="1.5999968mm" height="0.6999986mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin2"]} pcbX="-2.65506835mm" pcbY="-0.625094mm" width="1.5999968mm" height="0.6999986mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin3"]} pcbX="-3.00508035mm" pcbY="0.47498mm" width="1.5999968mm" height="0.6999986mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin4"]} pcbX="-3.25501635mm" pcbY="1.575054mm" width="1.5999968mm" height="0.6999986mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin5"]} pcbX="-3.00508035mm" pcbY="2.674874mm" width="1.5999968mm" height="0.6999986mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin6"]} pcbX="-3.25501635mm" pcbY="3.774948mm" width="1.5999968mm" height="0.6999986mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin7"]} pcbX="-3.00508035mm" pcbY="4.875022mm" width="1.5999968mm" height="0.6999986mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin8"]} pcbX="-3.00508035mm" pcbY="5.974842mm" width="1.5999968mm" height="0.6999986mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin9"]} pcbX="-5.75488435mm" pcbY="6.724904mm" width="2.1999956mm" height="1.6999966mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin10"]} pcbX="-6.80497115mm" pcbY="-6.724904mm" width="2.1999956mm" height="1.6999966mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin11"]} pcbX="7.15497045mm" pcbY="5.174996mm" width="1.499997mm" height="1.999996mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin12"]} pcbX="7.15497045mm" pcbY="-0.5249926mm" width="1.499997mm" height="1.999996mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <silkscreenpath route={[{"x":0.5763196500001868,"y":6.519164000000046},{"x":6.138919650000162,"y":5.985764000000017},{"x":6.138919650000162,"y":4.360164000000054},{"x":6.113519650000171,"y":4.33476399999995},{"x":0.5509196500000826,"y":3.9537639999999783},{"x":0.5509196500000826,"y":4.324604000000022},{"x":0.5509196500000826,"y":4.4617640000000165},{"x":5.529319650000161,"y":4.766564000000017},{"x":5.529319650000161,"y":5.4777639999998655},{"x":0.5509196500000826,"y":5.909563999999932},{"x":0.5509196500000826,"y":6.493763999999942},{"x":0.5763196500001868,"y":6.519164000000046}]} />
    <silkscreenpath route={[{"x":0.5763196500001868,"y":0.8803639999999859},{"x":6.138919650000162,"y":0.3469640000000709},{"x":6.138919650000162,"y":-1.2786359999998922},{"x":6.113519650000171,"y":-1.30403600000011},{"x":0.5509196500000826,"y":-1.685036000000082},{"x":0.5509196500000826,"y":-1.3141959999999244},{"x":0.5509196500000826,"y":-1.17703599999993},{"x":5.529319650000161,"y":-0.8722360000000435},{"x":5.529319650000161,"y":-0.161036000000081},{"x":0.5509196500000826,"y":0.27076399999998557},{"x":0.5509196500000826,"y":0.8549639999999954},{"x":0.5763196500001868,"y":0.8803639999999859}]} />
    <silkscreenpath route={[{"x":7.612119650000295,"y":7.230364000000009},{"x":7.612119650000295,"y":6.406133999999952}]} />
    <silkscreenpath route={[{"x":7.612119650000295,"y":3.9438579999999774},{"x":7.612119650000295,"y":0.7061199999999417}]} />
    <silkscreenpath route={[{"x":7.586719650000077,"y":-1.7561560000000327},{"x":7.586719650000077,"y":-6.8412360000000945}]} />
    <silkscreenpath route={[{"x":7.612119650000295,"y":7.230364000000009},{"x":-4.423924349999879,"y":7.230364000000009}]} />
    <silkscreenpath route={[{"x":-7.678680349999922,"y":-3.5138359999998556},{"x":-7.678680349999922,"y":-5.643879999999967}]} />
    <silkscreenpath route={[{"x":7.586719650000077,"y":-6.8412360000000945},{"x":-5.468372349999754,"y":-6.8412360000000945}]} />
    <silkscreenpath route={[{"x":-4.071880349999901,"y":6.569964000000027},{"x":-3.9268971499998315,"y":6.569964000000027}]} />
    <silkscreenpath route={[{"x":-4.071880349999901,"y":6.569964000000027},{"x":-4.071880349999901,"y":4.40552839999998}]} />
    <silkscreenpath route={[{"x":-4.071880349999901,"y":3.1443676000000096},{"x":-4.071880349999901,"y":2.2056343999998944}]} />
    <silkscreenpath route={[{"x":-4.071880349999901,"y":0.9444736000000375},{"x":-4.071880349999901,"y":-2.320035999999959}]} />
    <silkscreenpath route={[{"x":-2.141480349999938,"y":4.252823599999942},{"x":-2.141480349999938,"y":3.2970723999999336}]} />
    <silkscreenpath route={[{"x":-2.141480349999938,"y":2.0526756000000432},{"x":-2.141480349999938,"y":1.0971783999999616}]} />
    <silkscreenpath route={[{"x":-6.611880349999865,"y":5.7571640000001025},{"x":-6.51781893128998,"y":5.5256051306557765},{"x":-6.4298548075097415,"y":5.291662032041472},{"x":-6.34804833493456,"y":5.055495223394246},{"x":-6.272455644789261,"y":4.817266749742885},{"x":-6.203128604733024,"y":4.577140070719452},{"x":-6.140114783271542,"y":4.335279948403809},{"x":-6.083457417117643,"y":4.09185233427138},{"x":-6.033195381524706,"y":3.8470242553265734},{"x":-5.989363163612325,"y":3.6009636994980383},{"x":-5.951990838703296,"y":3.3538395003741925},{"x":-5.921104049687074,"y":3.105821221358269},{"x":-5.89672398942605,"y":2.85707903932348},{"x":-5.878867386213074,"y":2.607783627846743},{"x":-5.867546492293968,"y":2.3581060401008926},{"x":-5.862769075460392,"y":2.108217591488028},{"x":-5.8645384137200836,"y":1.8582897420916424},{"x":-5.872853293047683,"y":1.6084939790300723},{"x":-5.887708008218169,"y":1.3590016987910758},{"x":-5.9090923667206425,"y":1.109984089628142},{"x":-5.936991695752454,"y":0.8616120141017518},{"x":-5.971386852286514,"y":0.6140558918410761},{"x":-6.0122542362070135,"y":0.36748558261228936},{"x":-6.059565806501496,"y":0.12207026976886937},{"x":-6.113289100501788,"y":-0.12202165583187252},{"x":-6.173387256157866,"y":-0.3646227113705436},{"x":-6.2398190373309035,"y":-0.6055664369827127},{"x":-6.312538862087081,"y":-0.8446875099754152},{"x":-6.391496833973179,"y":-1.081821858262174},{"x":-6.476638776253594,"y":-1.3168067729407085},{"x":-6.567906269082869,"y":-1.5494810199348876},{"x":-6.665236689590756,"y":-1.7796849506258923},{"x":-6.768563254849823,"y":-2.007260611392553},{"x":-6.877815067699771,"y":-2.232051851993333},{"x":-6.992917165391759,"y":-2.4539044327053716},{"x":-7.113790571024765,"y":-2.6726661301580634},{"x":-7.240352347735097,"y":-2.888186841779202},{"x":-7.372515655602797,"y":-3.1003186887875245},{"x":-7.510189811237751,"y":-3.3089161176593507},{"x":-7.653280349999932,"y":-3.5138359999998556}]} />
    <silkscreentext text="{NAME}" pcbX="-0.00788035mm" pcbY="8.585964mm" anchorAlignment="center" fontSize="1mm" />
    <courtyardoutline outline={[{"x":-8.154968949999898,"y":7.824902300000076},{"x":8.154968950000011,"y":7.824902300000076},{"x":8.154968950000011,"y":-7.824902300000076},{"x":-8.154968949999898,"y":-7.824902300000076},{"x":-8.154968949999898,"y":7.824902300000076}]} />
          </footprint>}
          cadModel={{
            objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C105419.obj?uuid=761680ba9d244812bfb349e4268ee9de",
            stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C105419.step?uuid=761680ba9d244812bfb349e4268ee9de",
            pcbRotationOffset: 0,
            modelOriginPosition: { x: -0.07002765000020172, y: -0.19999959999995554, z: -0.05 },
          }}
          {...props}
        />
      )
    }"
  `)
})
