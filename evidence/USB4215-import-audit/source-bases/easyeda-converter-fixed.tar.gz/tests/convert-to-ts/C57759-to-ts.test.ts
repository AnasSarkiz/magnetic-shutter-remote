import { expect, it } from "bun:test"
import { runTscircuitCode } from "tscircuit"
import diodeRawEasy from "../assets/C57759.raweasy.json"
import { wrapTsxWithBoardFor3dSnapshot } from "../fixtures/wrap-tsx-with-board-for-3d-snapshot"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { convertBetterEasyToTsx } from "lib/websafe/convert-to-typescript-component"

it("should convert diode category components to diode elements", async () => {
  const betterEasy = EasyEdaJsonSchema.parse({
    ...diodeRawEasy,
    tags: [],
    category: "Diode",
  })
  const result = await convertBetterEasyToTsx({ betterEasy })

  expect(result).toMatchInlineSnapshot(`
    "import type { DiodeProps } from "@tscircuit/props"

    const pinLabels = {
      pin1: ["cathode","neg"],
      pin2: ["anode","pos"]
    } as const

    export const A_1N4148WS = (props: DiodeProps) => {
      const { name = "D1", ...restProps } = props

      return (
        <diode
          name={name}
          pinLabels={pinLabels}
          supplierPartNumbers={{
      "jlcpcb": [
        "C57759"
      ]
    }}
          manufacturerPartNumber="1N4148WS"
          footprint={<footprint>
            <smtpad portHints={["pin1","cathode","neg"]} pcbX="-1.172591mm" pcbY="0mm" width="0.999998mm" height="0.7500112mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin2","anode","pos"]} pcbX="1.172591mm" pcbY="0mm" width="0.999998mm" height="0.7500112mm" shape="rect" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <silkscreenpath route={[{"x":0.9012427999999773,"y":-0.726211400000011},{"x":0.9012427999999773,"y":-0.5199887999999646}]} />
    <silkscreenpath route={[{"x":0.9012427999999773,"y":0.726211400000011},{"x":0.9012427999999773,"y":0.5299964000000728}]} />
    <silkscreenpath route={[{"x":-0.8512047999998913,"y":0.726211400000011},{"x":0.9012427999999773,"y":0.726211400000011}]} />
    <silkscreenpath route={[{"x":-0.8512047999998913,"y":-0.726211400000011},{"x":0.9012427999999773,"y":-0.726211400000011}]} />
    <silkscreenpath route={[{"x":-0.44676059999994777,"y":0.726211400000011},{"x":-0.44676059999994777,"y":-0.726211400000011}]} />
    <silkscreentext text="{NAME}" pcbX="0.004191mm" pcbY="1.6604mm" anchorAlignment="center" fontSize="1mm" />
    <fabricationnotepath route={[{"x":1.0830306000001428,"y":0.5299964000000728},{"x":1.0830306000001428,"y":-0.5099811999998565},{"x":0.9270237999999154,"y":-0.5099811999998565},{"x":0.9270237999999154,"y":0.5299964000000728},{"x":1.0830306000001428,"y":0.5299964000000728}]} strokeWidth="0.254mm" />
    <fabricationnotepath route={[{"x":1.3150088000001006,"y":0.08999219999998331},{"x":1.3150088000001006,"y":-0.0660146000000168},{"x":0.6910070000001269,"y":-0.0660146000000168},{"x":0.6910070000001269,"y":0.08999219999998331},{"x":1.3150088000001006,"y":0.08999219999998331}]} strokeWidth="0.254mm" />
    <fabricationnotepath route={[{"x":-1.22496579999995,"y":0.07000240000002123},{"x":-1.22496579999995,"y":-0.08600439999997889},{"x":-0.6009639999998626,"y":-0.08600439999997889},{"x":-0.6009639999998626,"y":0.07000240000002123},{"x":-1.22496579999995,"y":0.07000240000002123}]} strokeWidth="0.254mm" />
    <courtyardoutline outline={[{"x":-1.9225900000000138,"y":0.8999860000001263},{"x":1.9225900000000138,"y":0.8999860000001263},{"x":1.9225900000000138,"y":-0.9000113999999257},{"x":-1.9225900000000138,"y":-0.9000113999999257},{"x":-1.9225900000000138,"y":0.8999860000001263}]} />
          </footprint>}
          cadModel={{
            objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C57759.obj?uuid=973acf8a660c48b1975f1ba1c890421a",
            stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C57759.step?uuid=973acf8a660c48b1975f1ba1c890421a",
            pcbRotationOffset: 0,
            modelOriginPosition: { x: 0.000012699999956566899, y: 0.000012699999842880061, z: -0.01 },
          }}
          {...restProps}
        />
      )
    }"
  `)

  const circuitJson = await runTscircuitCode(
    wrapTsxWithBoardFor3dSnapshot(result),
  )
  const sourceComponent = circuitJson.find(
    (element) => element.type === "source_component",
  )

  expect(sourceComponent?.ftype).toBe("simple_diode")
  expect(sourceComponent?.supplier_part_numbers).toEqual({ jlcpcb: ["C57759"] })
})
