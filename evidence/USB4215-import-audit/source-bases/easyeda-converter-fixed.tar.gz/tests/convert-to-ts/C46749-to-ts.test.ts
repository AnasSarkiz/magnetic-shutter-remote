import { it, expect } from "bun:test"
import chipRawEasy from "../assets/C46749.raweasy.json"
import { convertBetterEasyToTsx } from "lib/websafe/convert-to-typescript-component"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { runTscircuitCode } from "tscircuit"
import { wrapTsxWithBoardFor3dSnapshot } from "../fixtures/wrap-tsx-with-board-for-3d-snapshot"

it("should convert C46749 into typescript file", async () => {
  const betterEasy = EasyEdaJsonSchema.parse(chipRawEasy)
  const result = await convertBetterEasyToTsx({
    betterEasy,
  })

  expect(result).not.toContain("milmm")
  expect(result).not.toContain("NaNmm")
  expect(result).toContain("pin1: {requiresGround: true}")
  expect(result).toContain("pin8: {requiresPower: true}")
  expect(result).toContain("pinAttributes={pinAttributes}")

  const circuitJson = await runTscircuitCode(
    wrapTsxWithBoardFor3dSnapshot(result),
  )
  const sourcePorts = circuitJson.filter(
    (element) => element.type === "source_port",
  )
  const groundPort = sourcePorts.find((element) => element.pin_number === 1)
  const powerPort = sourcePorts.find((element) => element.pin_number === 8)

  expect(groundPort?.requires_ground).toBe(true)
  expect(powerPort?.requires_power).toBe(true)
  await expect(circuitJson).toMatch3dSnapshot(import.meta.path)

  expect(result).toMatchInlineSnapshot(`
    "import type { ChipProps } from "@tscircuit/props"

    const pinLabels = {
      pin1: ["GND"],
      pin2: ["TRIG"],
      pin3: ["OUT"],
      pin4: ["RESET"],
      pin5: ["CONT"],
      pin6: ["THRES"],
      pin7: ["DISCH"],
      pin8: ["VCC"]
    } as const

    const pinAttributes = {
      pin1: {requiresGround: true},
      pin8: {requiresPower: true}
    } as const

    export const NE555P = (props: ChipProps<typeof pinLabels>) => {
      return (
        <chip
          pinLabels={pinLabels}
          pinAttributes={pinAttributes}
          supplierPartNumbers={{
      "jlcpcb": [
        "C46749"
      ]
    }}
          manufacturerPartNumber="NE555P"
          footprint={<footprint>
            <platedhole solderMaskMargin="0.0508mm"  portHints={["pin1"]} pcbX="-3.81mm" pcbY="-3.81mm" holeWidth="0.9000236mm" holeHeight="0.9000236mm" outerWidth="1.499997mm" outerHeight="1.499997mm" rectPad={true} pcbRotation="0deg" shape="pill" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin2"]} pcbX="-1.27mm" pcbY="-3.81mm" outerDiameter="1.499997mm" holeDiameter="0.9000236mm" shape="circle" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin3"]} pcbX="1.27mm" pcbY="-3.81mm" outerDiameter="1.499997mm" holeDiameter="0.9000236mm" shape="circle" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin4"]} pcbX="3.81mm" pcbY="-3.81mm" outerDiameter="1.499997mm" holeDiameter="0.9000236mm" shape="circle" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin8"]} pcbX="-3.81mm" pcbY="3.81mm" outerDiameter="1.499997mm" holeDiameter="0.9000236mm" shape="circle" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin7"]} pcbX="-1.27mm" pcbY="3.81mm" outerDiameter="1.499997mm" holeDiameter="0.9000236mm" shape="circle" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin6"]} pcbX="1.27mm" pcbY="3.81mm" outerDiameter="1.499997mm" holeDiameter="0.9000236mm" shape="circle" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin5"]} pcbX="3.81mm" pcbY="3.81mm" outerDiameter="1.499997mm" holeDiameter="0.9000236mm" shape="circle" />
    <silkscreenpath route={[{"x":-4.9399951999999985,"y":0.640003800000045},{"x":-4.940299999999979,"y":0.6350000000001046},{"x":-4.940299999999979,"y":2.649220000000014},{"x":4.960620000000063,"y":2.649220000000014},{"x":4.960620000000063,"y":-2.6492199999999},{"x":-4.940299999999979,"y":-2.6492199999999},{"x":-4.940299999999979,"y":-0.6349999999999909},{"x":-4.9399951999999985,"y":-0.6400037999999313}]} />
    <silkscreenpath route={[{"x":-4.9399951999999985,"y":-0.6400037999999313},{"x":-4.6969912204483535,"y":-0.5916673031445043},{"x":-4.490982393946524,"y":-0.4540166060533011},{"x":-4.353331696855321,"y":-0.24800777955169906},{"x":-4.304995200000121,"y":-0.005003799999826697},{"x":-4.353331696855321,"y":0.2380001795518183},{"x":-4.490982393946524,"y":0.4440090060536477},{"x":-4.6969912204483535,"y":0.5816597031448509},{"x":-4.9399951999999985,"y":0.6299962000000505}]} />
    <silkscreenpath route={[{"x":-5.234940000000051,"y":-3.8099999999999454},{"x":-5.109318043912481,"y":-3.933721786962792},{"x":-4.984959652107364,"y":-3.808729999999855},{"x":-5.109318043912481,"y":-3.6837382130370315},{"x":-5.234940000000051,"y":-3.8074599999997645}]} />
    <silkscreenpath route={[{"x":-4.450080000000071,"y":-1.65099999999984},{"x":-4.360871640570167,"y":-1.8619343786078844},{"x":-4.148821341500593,"y":-1.9484567117675624},{"x":-3.9375112001708885,"y":-1.8601421170388903},{"x":-3.85009195288103,"y":-1.6484599999998863},{"x":-3.937511200171002,"y":-1.4367778829607687},{"x":-4.148821341500707,"y":-1.3484632882322103},{"x":-4.360871640570167,"y":-1.4349856213918883},{"x":-4.450080000000071,"y":-1.6459199999999328}]} />
    <silkscreentext text="{NAME}" pcbX="-0.3556mm" pcbY="5.572mm" anchorAlignment="center" fontSize="1mm" />
    <courtyardoutline outline={[{"x":-5.192992400000094,"y":4.809998500000006},{"x":5.106988000000001,"y":4.809998500000006},{"x":5.106988000000001,"y":-4.809998499999892},{"x":-5.192992400000094,"y":-4.809998499999892},{"x":-5.192992400000094,"y":4.809998500000006}]} />
          </footprint>}
          cadModel={{
            objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C46749.obj?uuid=5e8e9a2e75ff40abab9e1f1cacdd2cbb",
            stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C46749.step?uuid=5e8e9a2e75ff40abab9e1f1cacdd2cbb",
            pcbRotationOffset: 0,
            modelOriginPosition: { x: 0.04300220000004629, y: 0.000012699999842880061, z: -0.5500069999999995 },
          }}
          {...props}
        />
      )
    }"
  `)
})
