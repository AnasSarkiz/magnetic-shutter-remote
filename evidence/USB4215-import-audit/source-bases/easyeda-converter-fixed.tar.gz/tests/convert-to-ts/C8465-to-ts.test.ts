import { it, expect } from "bun:test"
import chipRawEasy from "../assets/C8465.raweasy.json"
import { convertBetterEasyToTsx } from "lib/websafe/convert-to-typescript-component"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { runTscircuitCode } from "tscircuit"
import { wrapTsxWithBoardFor3dSnapshot } from "../fixtures/wrap-tsx-with-board-for-3d-snapshot"

it("should convert C8465 into typescript file", async () => {
  const betterEasy = EasyEdaJsonSchema.parse(chipRawEasy)
  const result = await convertBetterEasyToTsx({
    betterEasy,
  })

  expect(result).not.toContain("milmm")
  expect(result).not.toContain("NaNmm")

  const circuitJson = await runTscircuitCode(
    wrapTsxWithBoardFor3dSnapshot(result),
  )
  await expect(circuitJson).toMatch3dSnapshot(import.meta.path, {
    camPos: [20, 0, 10],
  })

  expect(result).toMatchInlineSnapshot(`
    "import type { ChipProps } from "@tscircuit/props"

    const pinLabels = {
      pin1: ["pin1"],
      pin2: ["pin2"]
    } as const

    export const WJ500V_5_08_2P = (props: ChipProps<typeof pinLabels>) => {
      return (
        <chip
          pinLabels={pinLabels}
          supplierPartNumbers={{
      "jlcpcb": [
        "C8465"
      ]
    }}
          manufacturerPartNumber="WJ500V-5.08-2P"
          footprint={<footprint>
            <platedhole solderMaskMargin="0.0508mm"  portHints={["pin2"]} pcbX="2.54mm" pcbY="0mm" outerDiameter="1.999996mm" holeDiameter="1.3000228mm" shape="circle" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin1"]} pcbX="-2.54mm" pcbY="0mm" outerDiameter="1.999996mm" holeDiameter="1.3000228mm" shape="circle" />
    <silkscreenpath route={[{"x":5.079999999999998,"y":5.637529999999998},{"x":-5.053837999999999,"y":5.637529999999998}]} />
    <silkscreenpath route={[{"x":-5.679998799999993,"y":-3.7500051999999897},{"x":-5.0800000000000125,"y":-3.499967599999991}]} />
    <silkscreenpath route={[{"x":-5.679998799999993,"y":-2.750007199999999},{"x":-5.679998799999993,"y":-3.7500051999999897}]} />
    <silkscreenpath route={[{"x":-5.0800000000000125,"y":-3.000070199999996},{"x":-5.679998799999993,"y":-2.750007199999999}]} />
    <silkscreenpath route={[{"x":-5.0800000000000125,"y":4.500016400000007},{"x":-5.679998799999993,"y":4.750003200000009},{"x":-5.679998799999993,"y":3.7499798000000055},{"x":-5.0800000000000125,"y":3.999890399999998}]} />
    <silkscreenpath route={[{"x":5.079999999999998,"y":-4.522469999999984},{"x":-5.053837999999999,"y":-4.522469999999984}]} />
    <silkscreenpath route={[{"x":5.079999999999998,"y":-4.522469999999984},{"x":5.079999999999998,"y":5.637529999999998}]} />
    <silkscreenpath route={[{"x":-5.0800000000000125,"y":-4.519930000000002},{"x":-5.0800000000000125,"y":5.640070000000009}]} />
    <silkscreentext text="{NAME}" pcbX="-0.2413mm" pcbY="6.6388mm" anchorAlignment="center" fontSize="1mm" />
    <fabricationnotepath route={[{"x":2.0800059999999974,"y":5.499988999999999},{"x":3.080003999999988,"y":5.499988999999999},{"x":3.080003999999988,"y":3.4999930000000035},{"x":3.5800029999999907,"y":3.4999930000000035},{"x":2.580005,"y":2.4999949999999984},{"x":1.5800069999999948,"y":3.4999930000000035},{"x":2.0800059999999974,"y":3.4999930000000035},{"x":2.0800059999999974,"y":5.499988999999999}]} strokeWidth="0.254mm" />
    <fabricationnotepath route={[{"x":-2.999994000000001,"y":5.499988999999999},{"x":-1.99999600000001,"y":5.499988999999999},{"x":-1.99999600000001,"y":3.4999930000000035},{"x":-1.4999970000000076,"y":3.4999930000000035},{"x":-2.4999949999999984,"y":2.4999949999999984},{"x":-3.4999930000000035,"y":3.4999930000000035},{"x":-2.999994000000001,"y":3.4999930000000035},{"x":-2.999994000000001,"y":5.499988999999999}]} strokeWidth="0.254mm" />
    <courtyardoutline outline={[{"x":-5.929998799999993,"y":5.749988999999999},{"x":5.329974600000014,"y":5.749988999999999},{"x":5.329974600000014,"y":-4.7499910000000085},{"x":-5.929998799999993,"y":-4.7499910000000085},{"x":-5.929998799999993,"y":5.749988999999999}]} />
          </footprint>}
          cadModel={{
            objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C8465.obj?uuid=d60ef5d423934d3393dc75fa0a07b6bd",
            stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C8465.step?uuid=d60ef5d423934d3393dc75fa0a07b6bd",
            pcbRotationOffset: 0,
            modelOriginPosition: { x: -2.5399878999999967, y: 0, z: -0.000006999999999646178 },
          }}
          {...props}
        />
      )
    }"
  `)
})
