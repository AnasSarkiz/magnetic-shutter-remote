import { expect, test } from "bun:test"
import { convertRawEasyToTsx } from "lib/websafe/convert-to-typescript-component"
import rawEasy from "../assets/C5184243.raweasy.json"

test("USB-C supplier prefix and package classify a connector without category tags", async () => {
  const tsx = await convertRawEasyToTsx({
    rawEasy,
    options: { insertionDirection: "from_bottom" },
  })
  expect(tsx).toContain("<connector")
  expect(tsx).toContain('<footprint insertionDirection="from_bottom">')
  expect(tsx).toContain('"C5184243"')
  expect(tsx).toContain('manufacturerPartNumber="USB4105-GF-A-120"')
})
