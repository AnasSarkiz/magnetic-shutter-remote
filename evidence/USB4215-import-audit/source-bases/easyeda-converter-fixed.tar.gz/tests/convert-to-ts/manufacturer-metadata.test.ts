import { expect, test } from "bun:test"
import { convertRawEasyToTsx } from "lib/websafe/convert-to-typescript-component"
import switchRaw from "../assets/C221660.raweasy.json"
import connectorRaw from "../assets/C160392.raweasy.json"

test("SPDT import preserves all supplier symbol terminals and explicit topology", async () => {
  const tsx = await convertRawEasyToTsx({
    rawEasy: switchRaw,
    options: { switchType: "spdt" },
  })
  expect(tsx).toContain('type="spdt"')
  expect(tsx).toContain("symbol={")
  for (const pinNumber of [1, 2, 3]) {
    expect(tsx).toContain(`name="pin${pinNumber}" pinNumber={${pinNumber}}`)
  }
  expect(tsx.match(/<port /g)).toHaveLength(3)
})

test("multi-terminal switch refuses an unverified default SPST topology", async () => {
  await expect(convertRawEasyToTsx({ rawEasy: switchRaw })).rejects.toThrow(
    "manufacturer-verified switchType",
  )
})

test("connector import carries verified mating direction in the footprint frame", async () => {
  const tsx = await convertRawEasyToTsx({
    rawEasy: connectorRaw,
    options: { insertionDirection: "from_above" },
  })
  expect(tsx).toContain("<connector")
  expect(tsx).toContain('<footprint insertionDirection="from_above">')
})

test("invalid manufacturer metadata is rejected rather than dropped", async () => {
  await expect(
    convertRawEasyToTsx({
      rawEasy: connectorRaw,
      options: { switchType: "spdt" },
    }),
  ).rejects.toThrow("mechanical switch")
})

test("connector classification preserves a supplier contact-switch symbol", async () => {
  const rawEasy = await Bun.file(
    new URL("../assets/C309274.raweasy.json", import.meta.url),
  ).json()
  const tsx = await convertRawEasyToTsx({ rawEasy })
  expect(tsx).toContain("<connector")
  expect(tsx).toContain("symbol={")
  // Supplier numbering starts at 2: contacts 2 through 7 (six terminals).
  for (const pin of [2, 3, 4, 5, 6, 7])
    expect(tsx).toContain(`name="pin${pin}"`)
  expect(tsx.match(/<port /g)).toHaveLength(6)
  expect(tsx).toContain("<schematicpath")
})
