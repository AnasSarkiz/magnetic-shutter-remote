import { expect, test } from "bun:test"
import { categoryValueContainsSwitch } from "lib/websafe/convert-to-typescript-component/category-value-contains-switch"

test("semiconductor thermostat switches are not mechanical switches", () => {
  expect(categoryValueContainsSwitch("Thermostat Switches")).toBe(false)
})
