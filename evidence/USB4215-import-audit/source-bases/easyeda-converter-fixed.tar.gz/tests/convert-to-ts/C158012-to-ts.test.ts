import { it, expect } from "bun:test"
import chipRawEasy from "../assets/C158012.raweasy.json"
import { convertBetterEasyToTsx } from "lib/websafe/convert-to-typescript-component"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { runTscircuitCode } from "tscircuit"
import { wrapTsxWithBoardFor3dSnapshot } from "../fixtures/wrap-tsx-with-board-for-3d-snapshot"

it("should convert C158012 into typescript file", async () => {
  const betterEasy = EasyEdaJsonSchema.parse(chipRawEasy)
  const result = await convertBetterEasyToTsx({
    betterEasy,
  })

  expect(result).not.toContain("milmm")
  expect(result).not.toContain("NaNmm")

  const circuitJson = await runTscircuitCode(
    wrapTsxWithBoardFor3dSnapshot(result),
  )
  await expect(circuitJson).toMatch3dSnapshot(import.meta.path, {
    camPos: [20, 7, 20],
  })

  expect(result).toMatchInlineSnapshot(`
    "import type { ConnectorProps } from "@tscircuit/props"

    const pinLabels = {
      pin1: ["pin1"],
      pin2: ["pin2"]
    } as const

    export const B2B_XH_A_LF__SN_ = (props: ConnectorProps) => {
      return (
        <connector
          pinLabels={pinLabels}
          supplierPartNumbers={{
      "jlcpcb": [
        "C158012"
      ]
    }}
          manufacturerPartNumber="B2B-XH-A(LF)(SN)"
          footprint={<footprint>
            <platedhole solderMaskMargin="0.0508mm"  portHints={["pin1"]} pcbX="1.2499975mm" pcbY="0mm" outerDiameter="1.6999966mm" holeDiameter="0.999998mm" shape="circle" />
    <platedhole solderMaskMargin="0.0508mm"  portHints={["pin2"]} pcbX="-1.2499975mm" pcbY="0mm" outerDiameter="1.6999966mm" holeDiameter="0.999998mm" shape="circle" />
    <silkscreenpath route={[{"x":3.6829872999999225,"y":-2.413000000000011},{"x":3.6829872999999225,"y":-2.158999999999878}]} />
    <silkscreenpath route={[{"x":-3.6830127000001767,"y":-2.413000000000011},{"x":-3.6830127000001767,"y":-2.158999999999878}]} />
    <silkscreenpath route={[{"x":3.6829872999999225,"y":-2.413000000000011},{"x":2.5399872999998934,"y":-2.413000000000011}]} />
    <silkscreenpath route={[{"x":-1.270012700000052,"y":-2.413000000000011},{"x":1.2699872999997979,"y":-2.413000000000011}]} />
    <silkscreenpath route={[{"x":-3.6830127000001767,"y":-2.413000000000011},{"x":-2.6670127000001003,"y":-2.413000000000011}]} />
    <silkscreenpath route={[{"x":-3.6830127000001767,"y":-1.0159999999999627},{"x":-3.6830127000001767,"y":3.4289999999999736}]} />
    <silkscreenpath route={[{"x":-3.6830127000001767,"y":3.4289999999999736},{"x":3.6829872999999225,"y":3.4289999999999736},{"x":3.6829872999999225,"y":-1.0159999999999627}]} />
    <silkscreentext text="{NAME}" pcbX="-0.0000127mm" pcbY="4.556mm" anchorAlignment="center" fontSize="1mm" />
    <fabricationnotepath route={[{"x":-1.3970127000001185,"y":-2.5399999999999636},{"x":-1.3970127000001185,"y":-2.2859999999999445},{"x":1.3969872999998643,"y":-2.2859999999999445},{"x":1.3969872999998643,"y":-2.5399999999999636},{"x":-1.3970127000001185,"y":-2.5399999999999636}]} strokeWidth="0.254mm" />
    <fabricationnotepath route={[{"x":2.4129872999999407,"y":-2.5399999999999636},{"x":3.809987299999875,"y":-2.5399999999999636},{"x":3.809987299999875,"y":-2.0319999999999254},{"x":3.555987299999856,"y":-2.0319999999999254},{"x":3.555987299999856,"y":-2.2859999999999445},{"x":2.4129872999999407,"y":-2.2859999999999445},{"x":2.4129872999999407,"y":-2.5399999999999636}]} strokeWidth="0.254mm" />
    <fabricationnotepath route={[{"x":-2.5400127000001476,"y":-2.5399999999999636},{"x":-3.8100127000001294,"y":-2.5399999999999636},{"x":-3.8100127000001294,"y":-2.0319999999999254},{"x":-3.5560127000001103,"y":-2.0319999999999254},{"x":-3.5560127000001103,"y":-2.2859999999999445},{"x":-2.5400127000001476,"y":-2.2859999999999445},{"x":-2.5400127000001476,"y":-2.5399999999999636}]} strokeWidth="0.254mm" />
    <fabricationnotepath route={[{"x":-3.8100127000001294,"y":-1.1429999999999154},{"x":-3.8100127000001294,"y":3.55600000000004},{"x":3.809987299999875,"y":3.55600000000004},{"x":3.809987299999875,"y":-1.1429999999999154},{"x":3.555987299999856,"y":-1.1429999999999154},{"x":3.555987299999856,"y":3.302000000000021},{"x":-3.5560127000001103,"y":3.302000000000021},{"x":-3.5560127000001103,"y":-1.1429999999999154},{"x":-3.8100127000001294,"y":-1.1429999999999154}]} strokeWidth="0.254mm" />
    <courtyardoutline outline={[{"x":-3.9999925000001895,"y":3.5749869999999646},{"x":3.9999924999998484,"y":3.5749869999999646},{"x":3.9999924999998484,"y":-2.6250016000000187},{"x":-3.9999925000001895,"y":-2.6250016000000187},{"x":-3.9999925000001895,"y":3.5749869999999646}]} />
          </footprint>}
          cadModel={{
            objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C158012.obj?uuid=417e395cbf3443fdb9642576696e80a3",
            stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C158012.step?uuid=417e395cbf3443fdb9642576696e80a3",
            pcbRotationOffset: 180,
            modelOriginPosition: { x: 1.2499999999997726, y: 2.72549270000003, z: -1.800005 },
          }}
          {...props}
        />
      )
    }"
  `)
})
