import { expect, test } from "bun:test"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { convertEasyEdaJsonToCircuitJson } from "lib/convert-easyeda-json-to-tscircuit-soup-json"
import { generateSymbolTsx } from "lib/websafe/convert-to-typescript-component/generate-symbol-tsx"
import transistorRaw from "../assets/C8545.raweasy.json"

test("a transistor symbol without supplier text receives a dynamic reference", () => {
  const supplierComponent = EasyEdaJsonSchema.parse(transistorRaw)
  expect(
    supplierComponent.dataStr.shape.some((shape) => shape.type === "TEXT"),
  ).toBe(false)
  const symbol = generateSymbolTsx(
    supplierComponent,
    convertEasyEdaJsonToCircuitJson(supplierComponent),
  )
  expect(symbol).toContain('text="{NAME}"')
  expect(symbol?.match(/<port /g)).toHaveLength(3)
  expect(symbol?.match(/text="\{NAME\}"/g)).toHaveLength(1)
})
