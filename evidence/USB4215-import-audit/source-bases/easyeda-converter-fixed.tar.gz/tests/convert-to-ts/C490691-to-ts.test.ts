import { it, expect } from "bun:test"
import chipRawEasy from "../assets/C490691.raweasy.json"
import { convertBetterEasyToTsx } from "lib/websafe/convert-to-typescript-component"
import { EasyEdaJsonSchema } from "lib/schemas/easy-eda-json-schema"
import { runTscircuitCode } from "tscircuit"
import { wrapTsxWithBoardFor3dSnapshot } from "../fixtures/wrap-tsx-with-board-for-3d-snapshot"

it("should convert C490691 into typescript file", async () => {
  const betterEasy = EasyEdaJsonSchema.parse(chipRawEasy)
  const result = await convertBetterEasyToTsx({
    betterEasy,
  })

  expect(result).not.toContain("milmm")
  expect(result).not.toContain("NaNmm")

  const circuitJson = await runTscircuitCode(
    wrapTsxWithBoardFor3dSnapshot(result),
  )
  const sourcePorts = circuitJson.filter(
    (element) => element.type === "source_port",
  )
  const noConnectPort = sourcePorts.find((element) => element.pin_number === 8)

  expect(noConnectPort?.do_not_connect).toBe(true)
  await expect(circuitJson).toMatch3dSnapshot(import.meta.path)

  expect(result).toMatchInlineSnapshot(`
    "import type { ChipProps } from "@tscircuit/props"

    const pinLabels = {
      pin1: ["TXD"],
      pin2: ["N_DTR"],
      pin3: ["N_RTS"],
      pin4: ["VCCIO"],
      pin5: ["RXD"],
      pin6: ["N_RI"],
      pin7: ["GND1"],
      pin8: ["NC1"],
      pin9: ["N_DSR"],
      pin10: ["N_DCD"],
      pin11: ["N_CTS"],
      pin12: ["CBUS4"],
      pin13: ["CBUS2"],
      pin14: ["CBUS3"],
      pin15: ["USBDP"],
      pin16: ["USBDM"],
      pin17: ["3V3OUT"],
      pin18: ["GND3"],
      pin19: ["N_RESET"],
      pin20: ["VCC"],
      pin21: ["GND2"],
      pin22: ["CBUS1"],
      pin23: ["CBUS0"],
      pin24: ["NC2"],
      pin25: ["AGND"],
      pin26: ["TEST"],
      pin27: ["OSCI"],
      pin28: ["OSCO"]
    } as const

    const pinAttributes = {
      pin7: {requiresGround: true},
      pin8: {doNotConnect: true},
      pin18: {requiresGround: true},
      pin20: {requiresPower: true},
      pin21: {requiresGround: true},
      pin24: {doNotConnect: true},
      pin25: {requiresGround: true}
    } as const

    export const FT232RL = (props: ChipProps<typeof pinLabels>) => {
      return (
        <chip
          pinLabels={pinLabels}
          pinAttributes={pinAttributes}
          supplierPartNumbers={{
      "jlcpcb": [
        "C490691"
      ]
    }}
          manufacturerPartNumber="FT232RL"
          footprint={<footprint>
            <smtpad portHints={["pin1"]} pcbX="-4.225036mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin2"]} pcbX="-3.57505mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin3"]} pcbX="-2.925064mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin4"]} pcbX="-2.275078mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin5"]} pcbX="-1.625092mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin6"]} pcbX="-0.975106mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin7"]} pcbX="-0.324866mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin8"]} pcbX="0.32512mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin9"]} pcbX="0.975106mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin10"]} pcbX="1.625092mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin11"]} pcbX="2.275078mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin12"]} pcbX="2.925064mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin13"]} pcbX="3.57505mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin14"]} pcbX="4.225036mm" pcbY="-3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin28"]} pcbX="-4.225036mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin27"]} pcbX="-3.57505mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin26"]} pcbX="-2.925064mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin25"]} pcbX="-2.275078mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin24"]} pcbX="-1.625092mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin23"]} pcbX="-0.975106mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin22"]} pcbX="-0.324866mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin21"]} pcbX="0.32512mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin20"]} pcbX="0.975106mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin19"]} pcbX="1.625092mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin18"]} pcbX="2.275078mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin17"]} pcbX="2.925064mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin16"]} pcbX="3.57505mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <smtpad portHints={["pin15"]} pcbX="4.225036mm" pcbY="3.455162mm" width="0.3640074mm" height="2.01549mm" radius="0.1820037mm" shape="pill" solderPasteMargin="0mm" solderMaskMargin="0.0508mm" />
    <silkscreenpath route={[{"x":5.079999999999927,"y":2.199868600000059},{"x":5.079999999999927,"y":-2.158999999999878}]} />
    <silkscreenpath route={[{"x":-5.080000000000041,"y":-0.6439915999999357},{"x":-5.080000000000041,"y":-2.1999955999999656}]} />
    <silkscreenpath route={[{"x":-5.080000000000041,"y":0.6349999999999909},{"x":-5.080000000000041,"y":2.199868600000059}]} />
    <silkscreenpath route={[{"x":-5.080000000000041,"y":2.199868600000059},{"x":5.079999999999927,"y":2.199868600000059}]} />
    <silkscreenpath route={[{"x":-5.080000000000041,"y":-2.1999955999999656},{"x":5.079999999999927,"y":-2.1999955999999656}]} />
    <silkscreenpath route={[{"x":-5.080000000000041,"y":-0.6439915999999357},{"x":-5.080000000000041,"y":0.6349999999999909}]} />
    <silkscreentext text="{NAME}" pcbX="0mm" pcbY="5.2926mm" anchorAlignment="center" fontSize="1mm" />
    <courtyardoutline outline={[{"x":-5.349989800000117,"y":4.712906999999973},{"x":5.349989800000003,"y":4.712906999999973},{"x":5.349989800000003,"y":-4.712906999999973},{"x":-5.349989800000117,"y":-4.712906999999973},{"x":-5.349989800000117,"y":4.712906999999973}]} />
          </footprint>}
          cadModel={{
            objUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C490691.obj?uuid=f6684975c608438e85ae4e120e588908",
            stepUrl: "https://modelcdn.tscircuit.com/easyeda_models/assets/C490691.step?uuid=f6684975c608438e85ae4e120e588908",
            pcbRotationOffset: 0,
            modelOriginPosition: { x: 0, y: 0, z: 0 },
          }}
          {...props}
        />
      )
    }"
  `)
})
