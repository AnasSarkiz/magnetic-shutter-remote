import { distance, route_hint_point } from "circuit-json"
import { z } from "zod"
import { point } from "../common/point"
import { pcbPath } from "../common/pcbPath"

export const portRef = z.union([
  z.string(),
  z.custom<{ getPortSelector: () => string }>(
    (v) =>
      typeof v === "object" &&
      v !== null &&
      "getPortSelector" in v &&
      typeof v.getPortSelector === "function",
  ),
])

const baseTraceProps = z.object({
  key: z.string().optional(),
  name: z.string().optional(),
  displayName: z.string().optional(),
  thickness: distance.optional(),
  width: distance.optional().describe("Alias for trace thickness"),
  schematicRouteHints: z.array(point).optional(),
  pcbRouteHints: z.array(route_hint_point).optional(),
  pcbTeardrops: z.boolean().optional().describe("Enable PCB trace teardrops."),
  pcbTeardropStart: z
    .boolean()
    .optional()
    .describe("Teardrop at the start (from) of trace"),
  pcbTeardropEnd: z
    .boolean()
    .optional()
    .describe("Teardrop at the end (to) of trace"),
  pcbPathRelativeTo: z.string().optional(),
  pcbPath: pcbPath.optional(),
  pcbPaths: z.array(pcbPath).optional(),
  routingPhaseIndex: z.number().nullable().optional(),
  pcbStraightLine: z
    .boolean()
    .optional()
    .describe("Draw a straight pcb trace between the connected points"),
  schDisplayLabel: z.string().optional(),
  schStroke: z.string().optional(),
  highlightColor: z.string().optional(),
  maxLength: distance.optional(),
  maxViaCount: z
    .number()
    .int()
    .nonnegative()
    .optional()
    .describe("Maximum number of vias allowed in the PCB trace route"),
  connectsTo: z.string().or(z.array(z.string())).optional(),
})

export const traceProps = z.union([
  baseTraceProps.extend({
    path: z.array(portRef),
  }),
  baseTraceProps.extend({
    from: portRef,
    to: portRef,
  }),
  baseTraceProps.extend({
    start: portRef,
    end: portRef,
  }),
])

export type TraceProps = z.input<typeof traceProps>
