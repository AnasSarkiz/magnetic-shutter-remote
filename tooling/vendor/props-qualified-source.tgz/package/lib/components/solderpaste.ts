import { pcbLayoutProps, type PcbLayoutProps } from "lib/common/layout"
import { distance, type Distance } from "lib/common/distance"
import { point, type Point } from "lib/common/point"
import { z } from "zod"
import { expectTypesMatch } from "lib/typecheck"

export interface RectSolderPasteProps
  extends Omit<PcbLayoutProps, "pcbRotation"> {
  shape: "rect"
  width: Distance
  height: Distance
}

export interface CircleSolderPasteProps
  extends Omit<PcbLayoutProps, "pcbRotation"> {
  shape: "circle"
  radius: Distance
}

/** Explicit aperture outline, in footprint-local mm (+X right, +Y up).
 * Polygon points rotate/translate with the footprint. At least three vertices;
 * the outline is implicitly closed. No inferred reduction or copper geometry.
 */
export interface PolygonSolderPasteProps extends PcbLayoutProps {
  shape: "polygon"
  points: Point[]
}
export const polygonSolderPasteProps = pcbLayoutProps.extend({
  shape: z.literal("polygon"),
  points: z.array(point).min(3),
})
expectTypesMatch<
  z.input<typeof polygonSolderPasteProps>,
  PolygonSolderPasteProps
>(true)

export type SolderPasteProps =
  | RectSolderPasteProps
  | CircleSolderPasteProps
  | PolygonSolderPasteProps

// zod

export const rectSolderPasteProps = pcbLayoutProps
  .omit({ pcbRotation: true })
  .extend({
    shape: z.literal("rect"),
    width: distance,
    height: distance,
  })
type InferredRectSolderPasteProps = z.input<typeof rectSolderPasteProps>
expectTypesMatch<InferredRectSolderPasteProps, RectSolderPasteProps>(true)

export const circleSolderPasteProps = pcbLayoutProps
  .omit({ pcbRotation: true })
  .extend({
    shape: z.literal("circle"),
    radius: distance,
  })
type InferredCircleSolderPasteProps = z.input<typeof circleSolderPasteProps>
expectTypesMatch<InferredCircleSolderPasteProps, CircleSolderPasteProps>(true)

export const solderPasteProps = z.union([
  circleSolderPasteProps,
  rectSolderPasteProps,
  polygonSolderPasteProps,
])

export type InferredSolderPasteProps = z.input<typeof solderPasteProps>
expectTypesMatch<InferredSolderPasteProps, SolderPasteProps>(true)
