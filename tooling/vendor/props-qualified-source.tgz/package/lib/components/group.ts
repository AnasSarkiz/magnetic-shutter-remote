import {
  layer_ref,
  length,
  distance,
  type AnyCircuitElement,
} from "circuit-json"
import type { AutocompleteString } from "lib/common/autocomplete"
import type { Distance } from "lib/common/distance"
import {
  type CommonLayoutProps,
  commonLayoutProps,
  type SupplierPartNumbers,
} from "lib/common/layout"
import type { PcbStyle } from "lib/common/pcbStyle"
import type { ninePointAnchor } from "lib/common/ninePointAnchor"
import { type Point, point } from "lib/common/point"
import { expectTypesMatch } from "lib/typecheck"
import { z } from "zod"
import type { AnySourceComponent, PcbTrace } from "circuit-json"
import {
  manual_edits_file,
  type ManualEditsFile,
  type ManualEditsFileInput,
} from "lib/manual-edits"
import { connectionTarget } from "lib/common/connectionsProp"
import {
  schematicPinArrangement,
  type SchematicPinArrangement,
} from "lib/common/schematicPinDefinitions"
import {
  schematicPinStyle,
  type SchematicPinStyle,
} from "lib/common/schematicPinStyle"
import { url } from "lib/common/url"
import type { Connections } from "lib/utility-types/connections-and-selectors"
import type { ImplicitBreakoutPointSolverFn } from "lib/common/implicitBreakoutPointSolver"

export const layoutConfig = z.object({
  layoutMode: z
    .enum(["grid", "flex", "match-adapt", "relative", "none"])
    .optional(),
  position: z.enum(["absolute", "relative"]).optional(),

  grid: z.boolean().optional(),
  gridCols: z.number().or(z.string()).optional(),
  gridRows: z.number().or(z.string()).optional(),
  gridTemplateRows: z.string().optional(),
  gridTemplateColumns: z.string().optional(),
  gridTemplate: z.string().optional(),
  gridGap: z.number().or(z.string()).optional(),
  gridRowGap: z.number().or(z.string()).optional(),
  gridColumnGap: z.number().or(z.string()).optional(),

  flex: z.boolean().or(z.string()).optional(),
  flexDirection: z.enum(["row", "column"]).optional(),
  alignItems: z.enum(["start", "center", "end", "stretch"]).optional(),
  justifyContent: z
    .enum([
      "start",
      "center",
      "end",
      "stretch",
      "space-between",
      "space-around",
      "space-evenly",
    ])
    .optional(),
  flexRow: z.boolean().optional(),
  flexColumn: z.boolean().optional(),
  gap: z.number().or(z.string()).optional(),

  pack: z
    .boolean()
    .optional()
    .describe("Pack the contents of this group using a packing strategy"),
  packOrderStrategy: z
    .enum([
      "largest_to_smallest",
      "first_to_last",
      "highest_to_lowest_pin_count",
    ])
    .optional(),
  packPlacementStrategy: z
    .enum(["shortest_connection_along_outline"])
    .optional(),

  padding: length.optional(),
  paddingLeft: length.optional(),
  paddingRight: length.optional(),
  paddingTop: length.optional(),
  paddingBottom: length.optional(),
  paddingX: length.optional(),
  paddingY: length.optional(),

  width: length.optional(),
  height: length.optional(),

  matchAdapt: z.boolean().optional(),
  matchAdaptTemplate: z.any().optional(),
})

export interface LayoutConfig {
  layoutMode?: "grid" | "flex" | "match-adapt" | "relative" | "none"
  position?: "absolute" | "relative"

  grid?: boolean
  gridCols?: number | string
  gridRows?: number | string
  gridTemplateRows?: string
  gridTemplateColumns?: string
  gridTemplate?: string
  gridGap?: number | string
  gridRowGap?: number | string
  gridColumnGap?: number | string

  flex?: boolean | string
  flexDirection?: "row" | "column"
  alignItems?: "start" | "center" | "end" | "stretch"
  justifyContent?:
    | "start"
    | "center"
    | "end"
    | "stretch"
    | "space-between"
    | "space-around"
    | "space-evenly"
  flexRow?: boolean
  flexColumn?: boolean
  gap?: number | string

  pack?: boolean
  packOrderStrategy?:
    | "largest_to_smallest"
    | "first_to_last"
    | "highest_to_lowest_pin_count"
  packPlacementStrategy?: "shortest_connection_along_outline"

  padding?: Distance
  paddingLeft?: Distance
  paddingRight?: Distance
  paddingTop?: Distance
  paddingBottom?: Distance
  paddingX?: Distance
  paddingY?: Distance

  width?: Distance
  height?: Distance

  matchAdapt?: boolean
  matchAdaptTemplate?: any
}

expectTypesMatch<LayoutConfig, z.input<typeof layoutConfig>>(true)

export interface Border {
  strokeWidth?: Distance
  dashed?: boolean
  solid?: boolean
}

export const border = z.object({
  strokeWidth: length.optional(),
  dashed: z.boolean().optional(),
  solid: z.boolean().optional(),
})

export interface BaseGroupProps extends CommonLayoutProps, LayoutConfig {
  name?: string
  key?: any
  children?: any

  pcbStyle?: PcbStyle

  /**
   * Title to display above this group in the schematic view
   */
  schTitle?: string

  /**
   * This group will be drawn as part of this sheet e.g. "Main"
   */
  schSheetName?: string

  /**
   * If true, render this group as a single schematic box
   */
  showAsSchematicBox?: boolean

  /**
   * Mapping of external pin names to internal connection targets
   */
  connections?: Connections

  /**
   * Arrangement for pins when rendered as a schematic box
   */
  schPinArrangement?: SchematicPinArrangement

  /**
   * Spacing between pins when rendered as a schematic box
   * @deprecated Use schPinStyle instead.
   */
  schPinSpacing?: Distance

  /**
   * Styles to apply to individual pins in the schematic box representation
   */
  schPinStyle?: SchematicPinStyle

  pcbWidth?: Distance
  pcbHeight?: Distance
  minTraceWidth?: Distance
  nominalTraceWidth?: Distance
  schWidth?: Distance
  schHeight?: Distance

  pcbLayout?: LayoutConfig
  schLayout?: LayoutConfig
  cellBorder?: Border | null
  border?: Border | null
  schPadding?: Distance
  schPaddingLeft?: Distance
  schPaddingRight?: Distance
  schPaddingTop?: Distance
  schPaddingBottom?: Distance

  pcbPadding?: Distance
  pcbPaddingLeft?: Distance
  pcbPaddingRight?: Distance
  pcbPaddingTop?: Distance
  pcbPaddingBottom?: Distance
  /**
   * Anchor to use when interpreting pcbX/pcbY/pcbOffsetX/pcbOffsetY relative to pcbPosition
   */
  pcbAnchorAlignment?: AutocompleteString<z.infer<typeof ninePointAnchor>>

  /** @deprecated Use `pcbGrid` */
  grid?: boolean
  /** @deprecated Use `pcbFlex` */
  flex?: boolean | string

  pcbGrid?: boolean
  pcbGridCols?: number | string
  pcbGridRows?: number | string
  pcbGridTemplateRows?: string
  pcbGridTemplateColumns?: string
  pcbGridTemplate?: string
  pcbGridGap?: number | string
  pcbGridRowGap?: number | string
  pcbGridColumnGap?: number | string

  pcbFlex?: boolean | string
  pcbFlexGap?: number | string
  pcbFlexDirection?: "row" | "column"
  pcbAlignItems?: "start" | "center" | "end" | "stretch"
  pcbJustifyContent?:
    | "start"
    | "center"
    | "end"
    | "stretch"
    | "space-between"
    | "space-around"
    | "space-evenly"
  pcbFlexRow?: boolean
  pcbFlexColumn?: boolean
  pcbGap?: number | string
  pcbPack?: boolean
  pcbPackGap?: number | string

  schGrid?: boolean
  schGridCols?: number | string
  schGridRows?: number | string
  schGridTemplateRows?: string
  schGridTemplateColumns?: string
  schGridTemplate?: string
  schGridGap?: number | string
  schGridRowGap?: number | string
  schGridColumnGap?: number | string

  schFlex?: boolean | string
  schFlexGap?: number | string
  schFlexDirection?: "row" | "column"
  schAlignItems?: "start" | "center" | "end" | "stretch"
  schJustifyContent?:
    | "start"
    | "center"
    | "end"
    | "stretch"
    | "space-between"
    | "space-around"
    | "space-evenly"
  schFlexRow?: boolean
  schFlexColumn?: boolean
  schGap?: number | string
  schPack?: boolean
  schMatchAdapt?: boolean
}

export type PartsEngine = {
  findPart: (params: {
    sourceComponent: AnySourceComponent
    footprinterString?: string
  }) => Promise<SupplierPartNumbers> | SupplierPartNumbers
  fetchPartCircuitJson?: (params: {
    supplierPartNumber?: string
    manufacturerPartNumber?: string
    platformFetch?: typeof fetch
  }) =>
    | Promise<AnyCircuitElement[] | undefined>
    | AnyCircuitElement[]
    | undefined
}

export interface PcbRouteCache {
  pcbTraces: PcbTrace[]
  cacheKey: string
}

export interface RoutingTolerances {
  minTraceWidth?: Distance
  minViaHoleEdgeToViaHoleEdgeClearance?: Distance
  minPlatedHoleDrillEdgeToDrillEdgeClearance?: Distance
  minTraceToPadEdgeClearance?: Distance
  /**
   * Minimum trace copper edge to non-plated hole edge clearance. Numbers are mm;
   * unit strings are normalized to mm. Must be finite and non-negative. Omitted
   * leaves the router default unchanged. Independent of pad clearance, with no aliases.
   */
  minTraceToHoleEdgeClearance?: Distance
  minPadEdgeToPadEdgeClearance?: Distance
  minBoardEdgeClearance?: Distance
  minViaEdgeToPadEdgeClearance?: Distance
  minViaHoleDiameter?: Distance
  minViaPadDiameter?: Distance
}

export interface AutorouterConfig {
  serverUrl?: string
  inputFormat?: "simplified" | "circuit-json"
  serverMode?: "job" | "solve-endpoint"
  serverCacheEnabled?: boolean
  cache?: PcbRouteCache
  traceClearance?: Distance
  availableJumperTypes?: Array<"1206x4" | "0603">
  allowViaInPad?: boolean
  groupMode?:
    | /** @deprecated Disabled by default in core. Use the default autorouter with <autoroutingphase /> or <fanout /> as needed. Legacy support requires platformConfig.allowLegacyAutorouters: true. */ "sequential_trace"
    | "subcircuit"
    | /** @deprecated Disabled by default in core. Use the default autorouter with <autoroutingphase /> or <fanout /> as needed. Legacy support requires platformConfig.allowLegacyAutorouters: true. */ "sequential-trace"
  local?: boolean
  algorithmFn?: (simpleRouteJson: any) => Promise<any>
  /** Override the solver used to place implicit breakout points. */
  implicitBreakoutPointSolverFn?: ImplicitBreakoutPointSolverFn
  preset?:
    | /** @deprecated Disabled by default in core. Use the default autorouter with <autoroutingphase /> or <fanout /> as needed. Legacy support requires platformConfig.allowLegacyAutorouters: true. */ "sequential_trace"
    | "subcircuit"
    | "default"
    | "auto"
    | "auto_local"
    | "auto_cloud"
    | "auto_jumper"
    | "tscircuit_beta"
    | "krt"
    | "freerouting"
    | "simplify"
    | "laser_prefab" // Prefabricated PCB with laser copper ablation
    | "single_layer_fanout"
    | "fanout"
    | "dogbone"
    | "bus_lanes"
    | /** @deprecated Use "auto_jumper" */ "auto-jumper"
    | /** @deprecated Disabled by default in core. Use the default autorouter with <autoroutingphase /> or <fanout /> as needed. Legacy support requires platformConfig.allowLegacyAutorouters: true. */ "sequential-trace"
    | /** @deprecated Use "auto_local" */ "auto-local"
    | /** @deprecated Use "auto_cloud" */ "auto-cloud"
}

export type AutorouterPreset =
  | /** @deprecated Disabled by default in core. Use the default autorouter with <autoroutingphase /> or <fanout /> as needed. Legacy support requires platformConfig.allowLegacyAutorouters: true. */ "sequential_trace"
  | "subcircuit"
  | "default"
  | "auto"
  | "auto_local"
  | "auto_cloud"
  | "auto_jumper"
  | "tscircuit_beta"
  | "krt"
  | "freerouting"
  | "simplify"
  | "laser_prefab"
  | "single_layer_fanout"
  | "fanout"
  /** Local pad-to-via fanout without routing to a breakout boundary. */
  | "dogbone"
  | "bus_lanes"
  | "auto-jumper"
  | /** @deprecated Disabled by default in core. Use the default autorouter with <autoroutingphase /> or <fanout /> as needed. Legacy support requires platformConfig.allowLegacyAutorouters: true. */ "sequential-trace"
  | "auto-local"
  | "auto-cloud"

export type AutorouterProp =
  | AutorouterConfig
  | AutocompleteString<AutorouterPreset>

const pcbAnchorAlignmentAutocomplete = z.custom<
  AutocompleteString<z.infer<typeof ninePointAnchor>>
>((value) => typeof value === "string")

export const routingTolerances = z.object({
  minTraceWidth: length.optional(),
  minViaHoleEdgeToViaHoleEdgeClearance: length.optional(),
  minViaEdgeToPadEdgeClearance: length.optional(),
  minPlatedHoleDrillEdgeToDrillEdgeClearance: length.optional(),
  minTraceToPadEdgeClearance: length.optional(),
  minTraceToHoleEdgeClearance: length
    .refine((value) => Number.isFinite(value) && value >= 0, {
      message: "minTraceToHoleEdgeClearance must be finite and non-negative",
    })
    .optional(),
  minPadEdgeToPadEdgeClearance: length.optional(),
  minBoardEdgeClearance: length.optional(),
  minViaHoleDiameter: length.optional(),
  minViaPadDiameter: length.optional(),
})

export const autorouterConfig = z.object({
  serverUrl: url.optional(),
  inputFormat: z.enum(["simplified", "circuit-json"]).optional(),
  serverMode: z.enum(["job", "solve-endpoint"]).optional(),
  serverCacheEnabled: z.boolean().optional(),
  cache: z.custom<PcbRouteCache>((v) => true).optional(),
  traceClearance: length.optional(),
  availableJumperTypes: z.array(z.enum(["1206x4", "0603"])).optional(),
  allowViaInPad: z
    .boolean()
    .optional()
    .describe(
      "Allows the autorouter to place vias inside connected pads. Omitted or false keeps via-in-pad routing disabled.",
    ),
  groupMode: z
    .enum(["sequential_trace", "subcircuit", "sequential-trace"])
    .optional(),
  algorithmFn: z
    .custom<(simpleRouteJson: any) => Promise<any>>(
      (v) => typeof v === "function" || v === undefined,
    )
    .optional(),
  implicitBreakoutPointSolverFn: z
    .custom<ImplicitBreakoutPointSolverFn>(
      (value) => typeof value === "function" || value === undefined,
    )
    .optional(),
  preset: z
    .enum([
      "sequential_trace",
      "subcircuit",
      "default",
      "auto",
      "auto_local",
      "auto_cloud",
      "auto_jumper",
      "tscircuit_beta",
      "krt",
      "freerouting",
      "simplify",
      "laser_prefab",
      "single_layer_fanout",
      "fanout",
      "dogbone",
      "bus_lanes",
      "auto-jumper",
      "sequential-trace",
      "auto-local",
      "auto-cloud",
    ])
    .optional(),
  local: z.boolean().optional(),
})

export const autorouterPreset = z.union([
  z.literal("sequential_trace"),
  z.literal("subcircuit"),
  z.literal("default"),
  z.literal("auto"),
  z.literal("auto_local"),
  z.literal("auto_cloud"),
  z.literal("auto_jumper"),
  z.literal("tscircuit_beta"),
  z.literal("krt"),
  z.literal("freerouting"),
  z.literal("simplify"),
  z.literal("laser_prefab"), // Prefabricated PCB with laser copper ablation
  z.literal("single_layer_fanout"),
  z.literal("fanout"),
  z.literal("dogbone"),
  z.literal("bus_lanes"),
  z.literal("auto-jumper"),
  z.literal("sequential-trace"),
  z.literal("auto-local"),
  z.literal("auto-cloud"),
])

const autorouterString = z.string() as z.ZodType<
  AutocompleteString<AutorouterPreset>
>

export const autorouterProp: z.ZodType<AutorouterProp> = z.union([
  autorouterConfig,
  autorouterPreset,
  autorouterString,
])

export const autorouterEffortLevel = z.enum(["1x", "2x", "5x", "10x", "100x"])

export const preflightRoutingCheckPolicy = z.enum([
  "none",
  "basic",
  "conservative",
])

export type PreflightRoutingCheckPolicy = z.infer<
  typeof preflightRoutingCheckPolicy
>

export type AutorouterVersion =
  | "beta_pipeline1"
  | "beta_pipeline3"
  | "beta_pipeline4"
  | "beta_pipeline5"
  | "beta_pipeline7"
  | "beta_pipeline9"
  | "latest"

const knownAutorouterVersion = z.enum([
  "beta_pipeline1",
  "beta_pipeline3",
  "beta_pipeline4",
  "beta_pipeline5",
  "beta_pipeline7",
  "beta_pipeline9",
  "latest",
])

const autorouterVersion = z
  .custom<AutocompleteString<AutorouterVersion>>(
    (value) => typeof value === "string",
  )
  .transform((value): AutorouterVersion => {
    const parsedAutorouterVersion = knownAutorouterVersion.safeParse(value)
    if (parsedAutorouterVersion.success) return parsedAutorouterVersion.data

    console.warn(
      `Unknown autorouterVersion "${value}", falling back to "latest".`,
    )
    return "latest"
  })

export interface SubcircuitGroupProps
  extends BaseGroupProps,
    RoutingTolerances {
  manualEdits?: ManualEditsFileInput
  routingDisabled?: boolean
  /**
   * Skip the PCB placement design rule checks for this subcircuit. Placement
   * errors otherwise cause autorouting to be skipped entirely, so this is the
   * escape hatch for a placement the checks flag but you intend to keep.
   */
  placementDrcChecksDisabled?: boolean
  bomDisabled?: boolean
  defaultTraceWidth?: Distance

  nominalTraceWidth?: Distance
  pcbRouteCache?: PcbRouteCache

  autorouter?: AutorouterProp
  preflightRoutingCheckPolicy?: PreflightRoutingCheckPolicy
  autorouterEffortLevel?: "1x" | "2x" | "5x" | "10x" | "100x"
  /**
   * Selects the local autorouting pipeline. Unknown string values emit a
   * warning and fall back to `latest`.
   */
  autorouterVersion?:
    | "beta_pipeline1"
    | "beta_pipeline3"
    | "beta_pipeline4"
    | "beta_pipeline5"
    | "beta_pipeline7"
    | "beta_pipeline9"
    | "latest"
    | (string & {})

  /**
   * Serialized circuit JSON describing a precompiled subcircuit
   */
  circuitJson?: any[]

  /**
   * Nets from this subcircuit that should be exposed to parent circuits
   */
  exposedNets?: string[]

  /**
   * If true, all nets defined within this subcircuit are exposed to parent circuits
   */
  exposeNets?: boolean

  /**
   * If true, we'll automatically layout the schematic for this group. Must be
   * a subcircuit (currently). This is eventually going to be replaced with more
   * sophisticated layout options/modes and will be enabled by default.
   */
  schAutoLayoutEnabled?: boolean

  /**
   * If true, net labels will automatically be created for complex traces
   */
  schTraceAutoLabelEnabled?: boolean

  /** Maximum length a trace can span on the schematic */
  schMaxTraceDistance?: Distance

  partsEngine?: PartsEngine
  _subcircuitCachingEnabled?: boolean

  /** When autosizing, the board will be made square */
  square?: boolean
  /** Desired empty area of the board e.g. "22mm^2" or "20%" */
  emptyArea?: string
  /** Desired filled area of the board e.g. "22mm^2" or "20%" */
  filledArea?: string

  width?: number | string
  height?: number | string
  outline?: Point[]
  outlineOffsetX?: number | string
  outlineOffsetY?: number | string
}

export interface SubcircuitGroupPropsWithBool extends SubcircuitGroupProps {
  subcircuit: true
}

export interface NonSubcircuitGroupProps extends BaseGroupProps {
  subcircuit?: false | undefined
}

export type GroupProps = SubcircuitGroupPropsWithBool | NonSubcircuitGroupProps

export const baseGroupProps = commonLayoutProps.extend({
  name: z.string().optional(),
  children: z.any().optional(),
  schTitle: z.string().optional(),
  schSheetName: z
    .string()
    .optional()
    .describe('This group will be drawn as part of this sheet e.g. "Main"'),
  key: z.any().optional(),
  showAsSchematicBox: z.boolean().optional(),
  connections: z.record(z.string(), connectionTarget.optional()).optional(),
  schPinArrangement: schematicPinArrangement.optional(),
  schPinSpacing: length.optional(),
  schPinStyle: schematicPinStyle.optional(),

  ...layoutConfig.shape,
  grid: layoutConfig.shape.grid.describe("@deprecated use pcbGrid"),
  flex: layoutConfig.shape.flex.describe("@deprecated use pcbFlex"),
  pcbGrid: z.boolean().optional(),
  pcbGridCols: z.number().or(z.string()).optional(),
  pcbGridRows: z.number().or(z.string()).optional(),
  pcbGridTemplateRows: z.string().optional(),
  pcbGridTemplateColumns: z.string().optional(),
  pcbGridTemplate: z.string().optional(),
  pcbGridGap: z.number().or(z.string()).optional(),
  pcbGridRowGap: z.number().or(z.string()).optional(),
  pcbGridColumnGap: z.number().or(z.string()).optional(),
  pcbFlex: z.boolean().or(z.string()).optional(),
  pcbFlexGap: z.number().or(z.string()).optional(),
  pcbFlexDirection: z.enum(["row", "column"]).optional(),
  pcbAlignItems: z.enum(["start", "center", "end", "stretch"]).optional(),
  pcbJustifyContent: z
    .enum([
      "start",
      "center",
      "end",
      "stretch",
      "space-between",
      "space-around",
      "space-evenly",
    ])
    .optional(),
  pcbFlexRow: z.boolean().optional(),
  pcbFlexColumn: z.boolean().optional(),
  pcbGap: z.number().or(z.string()).optional(),
  pcbPack: z.boolean().optional(),
  pcbPackGap: z.number().or(z.string()).optional(),

  schGrid: z.boolean().optional(),
  schGridCols: z.number().or(z.string()).optional(),
  schGridRows: z.number().or(z.string()).optional(),
  schGridTemplateRows: z.string().optional(),
  schGridTemplateColumns: z.string().optional(),
  schGridTemplate: z.string().optional(),
  schGridGap: z.number().or(z.string()).optional(),
  schGridRowGap: z.number().or(z.string()).optional(),
  schGridColumnGap: z.number().or(z.string()).optional(),

  schFlex: z.boolean().or(z.string()).optional(),
  schFlexGap: z.number().or(z.string()).optional(),
  schFlexDirection: z.enum(["row", "column"]).optional(),
  schAlignItems: z.enum(["start", "center", "end", "stretch"]).optional(),
  schJustifyContent: z
    .enum([
      "start",
      "center",
      "end",
      "stretch",
      "space-between",
      "space-around",
      "space-evenly",
    ])
    .optional(),
  schFlexRow: z.boolean().optional(),
  schFlexColumn: z.boolean().optional(),
  schGap: z.number().or(z.string()).optional(),
  schPack: z.boolean().optional(),
  schMatchAdapt: z.boolean().optional(),
  pcbWidth: length.optional(),
  pcbHeight: length.optional(),
  minTraceWidth: length.optional(),
  nominalTraceWidth: length.optional(),
  schWidth: length.optional(),
  schHeight: length.optional(),
  pcbLayout: layoutConfig.optional(),
  schLayout: layoutConfig.optional(),
  cellBorder: border.nullable().optional(),
  border: border.nullable().optional(),
  schPadding: length.optional(),
  schPaddingLeft: length.optional(),
  schPaddingRight: length.optional(),
  schPaddingTop: length.optional(),
  schPaddingBottom: length.optional(),
  pcbPadding: length.optional(),
  pcbPaddingLeft: length.optional(),
  pcbPaddingRight: length.optional(),
  pcbPaddingTop: length.optional(),
  pcbPaddingBottom: length.optional(),
  pcbAnchorAlignment: pcbAnchorAlignmentAutocomplete.optional(),
})

export const partsEngine = z.custom<PartsEngine>((v) => "findPart" in v)

export const subcircuitGroupProps = baseGroupProps.extend({
  manualEdits: manual_edits_file.optional(),
  schAutoLayoutEnabled: z.boolean().optional(),
  schTraceAutoLabelEnabled: z.boolean().optional(),
  schMaxTraceDistance: distance.optional(),
  routingDisabled: z.boolean().optional(),
  placementDrcChecksDisabled: z.boolean().optional(),
  bomDisabled: z.boolean().optional(),
  defaultTraceWidth: length.optional(),
  ...routingTolerances.shape,
  nominalTraceWidth: length.optional(),
  partsEngine: partsEngine.optional(),
  _subcircuitCachingEnabled: z.boolean().optional(),
  pcbRouteCache: z.custom<PcbRouteCache>((v) => true).optional(),
  autorouter: autorouterProp.optional(),
  preflightRoutingCheckPolicy: preflightRoutingCheckPolicy.optional(),
  autorouterEffortLevel: autorouterEffortLevel.optional(),
  autorouterVersion: autorouterVersion.optional(),
  square: z.boolean().optional(),
  emptyArea: z.string().optional(),
  filledArea: z.string().optional(),
  width: distance.optional(),
  height: distance.optional(),
  outline: z.array(point).optional(),
  outlineOffsetX: distance.optional(),
  outlineOffsetY: distance.optional(),
  circuitJson: z.array(z.any()).optional(),
  exposedNets: z.array(z.string()).optional(),
  exposeNets: z.boolean().optional(),
})

export const subcircuitGroupPropsWithBool = subcircuitGroupProps.extend({
  subcircuit: z.literal(true),
})

export const groupProps = z.discriminatedUnion("subcircuit", [
  baseGroupProps.extend({ subcircuit: z.literal(false).optional() }),
  subcircuitGroupPropsWithBool,
])

type InferredBaseGroupProps = z.input<typeof baseGroupProps>
type InferredSubcircuitGroupPropsWithBool = z.input<
  typeof subcircuitGroupPropsWithBool
>

expectTypesMatch<AutorouterProp, z.input<typeof autorouterProp>>(true)
expectTypesMatch<RoutingTolerances, z.input<typeof routingTolerances>>(true)

expectTypesMatch<BaseGroupProps, InferredBaseGroupProps>(true)
expectTypesMatch<
  SubcircuitGroupPropsWithBool,
  InferredSubcircuitGroupPropsWithBool
>(true)

type InferredGroupProps = z.input<typeof groupProps>
expectTypesMatch<GroupProps, InferredGroupProps>(true)
