# Schematic Trace Solver

## Installation

Releases are published to GitHub Packages and served publicly through jscdn:

```sh
bun add https://jscdn.tscircuit.com/@tscircuit/schematic-trace-solver/latest.tgz
```

Pin the resolved release version in your dependency URL for reproducible installs.
The release contains bundled JavaScript and TypeScript declarations in `dist`;
Git checkouts, test fixtures, examples, and development dependencies are excluded.

Run `bun run test:package` to build and validate the actual tarball in an isolated
consumer before publishing.

Solve for the correct positions and routing for schematic traces and net labels. For use inside [@tscircuit/core](https://github.com/tscircuit/core)

[Online Playground](https://schematic-trace-solver.vercel.app) ・ [tscircuit](https://github.com/tscircuit/tscircuit) ・ [@tscircuit/core](https://github.com/tscircuit/core)

<img width="1740" height="896" alt="image" src="https://github.com/user-attachments/assets/53032b97-d7b5-4a00-9eab-58b58e3adecc" />

## Overview

The Schematic Trace Solver is a pipeline that figures out how to route schematic traces
and place net labels for a given schematic layout.

Chips are defined by their center point, width, and height and pins.

You then pass in direct connections and net connections. Direct connections are
explicit pin-to-pin connections. When there's a direct connection between two
pins, there is guaranteed to be a routed trace between them.

Net connections will not be routed, net labels are placed instead.

The solver first constructs minimum spanning tree to determine what pin-pairs
to draw via the `MspConnectionPairSolver`. If there are two pins A and B that both connect to C, this phase will
determine how to route traces to minimize overlap or crossings. e.g. we may
decide to route a trace from A to B, then B to C OR we may decide to route a
trace from A to C, then C to B. The pairs of traces are the mspConnectionPairs,
these are used in future phases.

After the minimum spanning tree is constructed, we draw the schematic traces
for each mspConnectionPair via the `SchematicTraceLinesSolver`. The `TraceOverlapShiftSolver`
then shifts the schematic traces to make sure there are no parallel overlapping traces by
shifting parallel traces orthogonally by a small amount.

Finally, the `NetLabelPlacementSolver` places net labels for each net connection. Often
this requires drawing small traces to adapt to the `availableFacingDirections` of the net connection.
If there is crowding at the pin, we look for an available spot along the trace connected to the pin.

### Inline net labels

A point-to-point signal trace can be labeled *inline*: the net name is drawn
parallel to the wire (above a horizontal trace, to the left of a vertical one)
instead of as an anchored label hanging off the end of it. This keeps the visual
line between the two pins intact.

Inline labels are opt-in per direct connection - set `allowInlineNetLabel: true`
on the `directConnection`. The caller (usually [@tscircuit/core](https://github.com/tscircuit/core))
decides which connections deserve one; the solver only honors the request when
the connection actually got routed, since there is nothing to run parallel to
otherwise.

The `InlineNetLabelSolver` exposes `inlineNetLabelPlacements`. A net that
receives an inline label has its anchored `NetLabelPlacement` removed from
`getOutput().netLabelPlacements`, so a net is never labeled twice.
`NetLabelToTraceSolver` then replaces pairs of port-only fallback labels with
real traces whenever the router finds a clear path. Its `getOutput()` is the
pipeline's final output.

```tsx
directConnections: [
  {
    pinIds: ["U1.1", "D1.1"],
    netId: "USER_LED_ANODE",
    allowInlineNetLabel: true,
  },
]
```

## Usage

```tsx
import { SchematicTracePipelineSolver } from "@tscircuit/schematic-trace-solver"

type ChipId = string
type PinId = string

const solver = new SchematicTracePipelineSolver({
  chips: {
    chipId: "U1",
    center: { x: 0, y: 0 },
    width: 1.6,
    height: 0.6,
    pins: [
      {
        pinId: "U1.1",
        x: -0.8,
        y: 0.2,
      },
      // ...
    ],
  },
  directConnections: [
    {
      pinIds: ["U1.1", "C1.1"],
      netId: "VCC",
    },
    // ...
  ],
  netConnections: [
    {
      availableFacingDirections: ["y-"],
      netId: "GND",
      pinIds: ["U1.3", "C1.2", "C2.2"],
    },
    // ...
  ],
  availableNetLabelOrientations: {
    VCC: ["y+", "y-"],
    GND: ["y+", "y-"],
  },
})

solver.solve()
```

## Development

### Running locally

Every `*.page.tsx` file in the `site` directory automatically appears in the
browser when you run `bun run start`. You should add pages to help you debug
various solvers.

By clicking the solver name at the top of the page, you can download specific
inputs for each solver. This can help to reproduce bugs in the solvers that
only appear at certain iterations.

### Downloading input problems from tscircuit

1. Create a test in [tscircuit/core](https://github.com/tscircuit/core)
2. Set `DEBUG=Group_doInitialSchematicTraceRender`
3. Run the test with `bun test`
4. The console output will show the location of the input problem
5. Copy the input problem and [paste it into the input debugger](https://schematic-trace-solver.vercel.app/?fixture=%7B%22path%22%3A%22site%2Fexamples%2Fexample01.page.tsx%22%7D)
6. Download the `page.tsx` or `test.tsx` file and put it in the `site` or `tests` directories.

<img width="1288" height="1128" alt="image" src="https://github.com/user-attachments/assets/c067f7f9-c46c-4600-a0a4-5112440bd2f4" />

### Updating Test Snapshots

1. `export BUN_UPDATE_SNAPSHOTS=1`
2. `bun test`
