export { getPlatformConfig } from "./getPlatformConfig"
