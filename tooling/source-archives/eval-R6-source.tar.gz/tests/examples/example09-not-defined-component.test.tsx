import { expect, test } from "bun:test"
import { createCircuitWebWorker } from "lib/index"

test("example9-not-defined-component", async () => {
  const circuitWebWorker = await createCircuitWebWorker({
    webWorkerUrl: new URL("../../webworker/entrypoint.ts", import.meta.url),
  })

  expect(async () => {
    await circuitWebWorker.execute(`  
        import { NotExportedComponent } from "@tsci/seveibar.a555timer";
    
        circuit.add(
            <board width="10mm" height="10mm">
                <NotExportedComponent name="01" />
            </board>
        );
      `)
  }).toThrowError(
    `Error evaluating \"entrypoint.tsx\": \"NotExportedComponent\" is not exported by \"@tsci/seveibar.a555timer\".\nIf \"NotExportedComponent\" is a type, use \"export type { NotExportedComponent }\" instead of \"export { NotExportedComponent }\"`,
  )

  await circuitWebWorker.kill()
})
