import fs from "node:fs"
import path from "node:path"
import type {
  AnyCircuitElement,
  CircuitJson,
  PcbTrace,
  PcbTraceRoutePointThroughPad,
  SourcePort,
  SourceTrace,
} from "circuit-json"
import { convertCircuitJsonToPcbSvg } from "circuit-to-svg"
import kleur from "kleur"
import { convertSvgToPngBuffer } from "./convert-svg-to-png"

export type AutorouterDumpSrjMode = "all" | "failed" | `phase:${number}`

export type AutorouterDiagnosticsOptions = {
  enabled?: boolean
  /** Enable debugging through the autorouting phase with this name. */
  phaseName?: string
  timeoutMs?: number
  debugDir?: string
  dumpSrj?: AutorouterDumpSrjMode
  logOnError?: boolean
  longRunningLogThresholdMs?: number
  log?: (message: string) => void
}

type SimpleRouteJson = {
  connections?: Array<Record<string, unknown>>
  obstacles?: unknown[]
  traces?: AutorouterTrace[]
  jumpers?: unknown[]
  [key: string]: unknown
}

type ThroughObstacleRoutePoint = {
  route_type: "through_obstacle"
  start: { x: number; y: number }
  end: { x: number; y: number }
  from_layer: PcbTraceRoutePointThroughPad["start_layer"]
  to_layer: PcbTraceRoutePointThroughPad["end_layer"]
  width: number
}

type AutorouterTrace = Omit<PcbTrace, "route"> & {
  route: Array<PcbTrace["route"][number] | ThroughObstacleRoutePoint>
}

type CircuitJsonLookup = {
  circuitJson: CircuitJson
  elementById: Map<string, AnyCircuitElement>
}

type AutoroutingEventPayload = {
  subcircuit_id?: string
  subcircuitId?: string
  componentDisplayName?: string
  phaseName?: string
  phaseStageIndex?: number
  phaseStageCount?: number
  routingPhaseIndex?: number | null
  phaseOrdinal?: number
  phaseCount?: number
  connectionCount?: number
  obstacleCount?: number
  previousTraceCount?: number
  isReroutePhase?: boolean
  autorouterName?: string
  autorouterVersion?: string
  effort?: number
  solverName?: string
  cacheStatus?: "disabled" | "hit" | "miss"
  cacheKey?: string
  cacheDisabledReason?:
    | "custom_algorithm"
    | "strategy_not_cacheable"
    | "no_cache_engine"
  iteration?: number
  steps?: number
  progress?: number
  phase?: string
  iterationsPerSecond?: number
  elapsedMs?: number
  simpleRouteJson?: SimpleRouteJson
  error?: { message?: string; stack?: string } | Error | string
}

type ActivePhase = {
  subcircuitId: string
  componentDisplayName: string
  phaseName?: string
  phaseStageIndex?: number
  phaseStageCount?: number
  routingPhaseIndex: number
  phaseOrdinal: number
  phaseCount?: number
  connectionCount: number
  obstacleCount: number
  previousTraceCount: number
  startedAt: number
  startedAtIso: string
  simpleRouteJson?: SimpleRouteJson
  autorouterName?: string
  autorouterVersion?: string
  solverName?: string
  effort?: number
  cacheStatus?: "disabled" | "hit" | "miss"
  cacheKey?: string
  cacheDisabledReason?:
    | "custom_algorithm"
    | "strategy_not_cacheable"
    | "no_cache_engine"
  routerDescription: string
  lastProgressLogAt: number
  hasLoggedStart: boolean
  longRunningLoggingStarted: boolean
  lastProgress?: AutoroutingEventPayload
}

const DEFAULT_DEBUG_DIR = path.join("dist", "autorouter-debug")
const PROGRESS_LOG_INTERVAL_MS = 10_000
const CIRCUIT_JSON_ID_PATTERN =
  /\b(?:source|pcb|schematic|subcircuit|cad|simulation)_[a-z0-9_]*_\d+\b/gi

export const parseAutorouterTimeout = (duration: string): number => {
  const trimmed = duration.trim()
  const match = trimmed.match(/^(\d+(?:\.\d+)?)(ms|s|m)?$/)
  if (!match) {
    throw new Error(
      `Invalid --autorouter-timeout value "${duration}". Use values like "120s", "2m", or "5000ms".`,
    )
  }

  const value = Number.parseFloat(match[1])
  const unit = match[2] ?? "ms"
  const multiplier = unit === "m" ? 60_000 : unit === "s" ? 1_000 : 1
  const timeoutMs = Math.round(value * multiplier)
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    throw new Error("--autorouter-timeout must be greater than zero")
  }
  return timeoutMs
}

export const parseAutorouterPhaseName = (value: string): string => {
  const phaseName = value.trim()
  if (!phaseName) {
    throw new Error(
      "Invalid --autorouter-phase value. The phase name must not be empty.",
    )
  }
  return phaseName
}

export const parseAutorouterDumpSrjMode = (
  value: string | boolean | undefined,
): AutorouterDumpSrjMode | undefined => {
  if (value === undefined || value === false) return undefined
  if (value === true || value === "") return "failed"
  if (value === "all" || value === "failed") return value
  const phaseMatch = value.match(/^phase:(\d+)$/)
  if (phaseMatch) return `phase:${Number.parseInt(phaseMatch[1], 10)}`
  throw new Error(
    `Invalid --autorouter-dump-srj value "${value}". Use "all", "failed", or "phase:<index>".`,
  )
}

export class AutorouterPhaseTimeoutError extends Error {
  debugArtifactPath?: string

  constructor(message: string, debugArtifactPath?: string) {
    super(message)
    this.name = "AutorouterPhaseTimeoutError"
    this.debugArtifactPath = debugArtifactPath
  }
}

export class AutorouterDiagnostics {
  private options: Required<Pick<AutorouterDiagnosticsOptions, "log">> &
    Omit<AutorouterDiagnosticsOptions, "log">
  private phaseOrdinalBySubcircuit = new Map<string, number>()
  private traceCountBySubcircuit = new Map<string, number>()
  private activePhase: ActivePhase | null = null
  private completedPhaseTraces: AutorouterTrace[] = []
  private hasWrittenPlacementSnapshot = false
  private targetPhaseReached = false
  private summary: Array<Record<string, unknown>> = []
  private rootCircuit: any

  constructor(options: AutorouterDiagnosticsOptions = {}) {
    const phaseName = options.phaseName?.trim() || undefined
    this.options = {
      ...options,
      enabled: options.enabled || phaseName !== undefined,
      phaseName,
      debugDir: options.debugDir ?? DEFAULT_DEBUG_DIR,
      log: options.log ?? console.log,
    }
  }

  get isActive() {
    return Boolean(
      this.options.enabled ||
        this.options.phaseName ||
        this.options.timeoutMs ||
        this.options.dumpSrj ||
        this.options.logOnError ||
        this.options.longRunningLogThresholdMs,
    )
  }

  attachToRootCircuit(rootCircuit: any) {
    if (!this.isActive) return
    this.rootCircuit = rootCircuit

    rootCircuit.on?.("autorouting:start", (event: AutoroutingEventPayload) =>
      this.handleStart(event),
    )
    rootCircuit.on?.("autorouting:progress", (event: AutoroutingEventPayload) =>
      this.handleProgress(event),
    )
    rootCircuit.on?.("autorouting:end", (event: AutoroutingEventPayload) =>
      this.handleEnd(event),
    )
    rootCircuit.on?.("autorouting:error", (event: AutoroutingEventPayload) =>
      this.handleError(event),
    )
  }

  checkTimeout() {
    this.checkLongRunning()

    if (!this.options.timeoutMs || !this.activePhase) return

    const elapsedMs = performance.now() - this.activePhase.startedAt
    if (elapsedMs < this.options.timeoutMs) return

    const artifactPath = this.writeTimeoutArtifact(this.activePhase, elapsedMs)
    const phaseLabel = this.getPhaseLabel(this.activePhase)
    const message = `Autorouter timeout after ${this.formatElapsed(elapsedMs)} in ${phaseLabel}. Set a different timeout with \`--autorouter-timeout <duration>\` (for example, \`--autorouter-timeout 2m\`).`
    this.log(kleur.red(message))

    throw new AutorouterPhaseTimeoutError(message, artifactPath)
  }

  finalize(circuitJson?: CircuitJson) {
    if (
      !this.isActive ||
      this.summary.length === 0 ||
      (!this.options.enabled && !this.options.dumpSrj)
    ) {
      return
    }
    this.writeJson("board.meta.json", {
      type: "autorouter_debug_summary",
      generatedAt: new Date().toISOString(),
      phaseCount: this.summary.length,
      phases: this.summary,
      circuitJsonElementCount: circuitJson?.length,
      targetPhaseName: this.options.phaseName,
      targetPhaseReached: this.targetPhaseReached,
    })
  }

  private handleStart(event: AutoroutingEventPayload) {
    if (this.targetPhaseReached) return

    const simpleRouteJson = event.simpleRouteJson
    const subcircuitId =
      event.subcircuit_id ?? event.subcircuitId ?? "unknown-subcircuit"
    const previousOrdinal = this.phaseOrdinalBySubcircuit.get(subcircuitId) ?? 0
    const phaseOrdinal = event.phaseOrdinal ?? previousOrdinal + 1
    this.phaseOrdinalBySubcircuit.set(subcircuitId, phaseOrdinal)
    const routingPhaseIndex = event.routingPhaseIndex ?? phaseOrdinal - 1
    const connectionCount =
      event.connectionCount ?? simpleRouteJson?.connections?.length ?? 0
    const obstacleCount =
      event.obstacleCount ?? simpleRouteJson?.obstacles?.length ?? 0
    const previousTraceCount =
      event.previousTraceCount ??
      this.traceCountBySubcircuit.get(subcircuitId) ??
      0

    this.activePhase = {
      subcircuitId,
      componentDisplayName: event.componentDisplayName ?? "subcircuit",
      phaseName: event.phaseName,
      phaseStageIndex: event.phaseStageIndex,
      phaseStageCount: event.phaseStageCount,
      routingPhaseIndex,
      phaseOrdinal,
      phaseCount: event.phaseCount,
      connectionCount,
      obstacleCount,
      previousTraceCount,
      startedAt: performance.now(),
      startedAtIso: new Date().toISOString(),
      simpleRouteJson,
      autorouterName: event.autorouterName,
      autorouterVersion: event.autorouterVersion,
      solverName: event.solverName,
      effort: event.effort,
      cacheStatus: event.cacheStatus,
      cacheKey: event.cacheKey,
      cacheDisabledReason: event.cacheDisabledReason,
      routerDescription: this.formatRouter(event),
      lastProgressLogAt: 0,
      hasLoggedStart: false,
      longRunningLoggingStarted: false,
    }

    if (this.options.enabled && !this.hasWrittenPlacementSnapshot) {
      const placementCircuitJson = this.getCurrentCircuitJson().filter(
        (element) => !this.isRouteElement(element),
      ) as AnyCircuitElement[]
      this.writePngSnapshot("placement-unrouted.png", placementCircuitJson, {
        shouldDrawRatsNest: true,
      })
      this.hasWrittenPlacementSnapshot = true
    }

    if (this.options.enabled) {
      this.logPhaseStart(this.activePhase)
    }

    if (this.shouldDumpInput(routingPhaseIndex)) {
      this.writeJson(
        this.getPhaseFileName(this.activePhase, "input.simple-route.json"),
        simpleRouteJson ?? {},
      )
    }
  }

  private handleProgress(event: AutoroutingEventPayload) {
    if (!this.activePhase) return
    const now = performance.now()
    this.activePhase.lastProgress = event
    if (!this.shouldLogPhaseDetails(this.activePhase)) return

    if (
      this.activePhase.lastProgressLogAt > 0 &&
      now - this.activePhase.lastProgressLogAt < PROGRESS_LOG_INTERVAL_MS
    ) {
      return
    }
    this.activePhase.lastProgressLogAt = now

    this.logProgress(this.activePhase, event, now)
  }

  private handleEnd(event: AutoroutingEventPayload) {
    const activePhase = this.matchActivePhase(event)
    if (!activePhase) return

    const elapsedMs = performance.now() - activePhase.startedAt
    const outputSrj = event.simpleRouteJson
    const outputTraceCount = outputSrj?.traces?.length ?? 0
    const outputJumperCount = outputSrj?.jumpers?.length ?? 0
    const errorCount = this.countErrors(outputSrj)
    const cumulativeTraceCount =
      activePhase.previousTraceCount + outputTraceCount

    this.traceCountBySubcircuit.set(
      activePhase.subcircuitId,
      cumulativeTraceCount,
    )
    this.completedPhaseTraces.push(...(outputSrj?.traces ?? []))
    this.summary.push({
      subcircuit_id: activePhase.subcircuitId,
      componentDisplayName: activePhase.componentDisplayName,
      phaseName: activePhase.phaseName,
      phaseStageIndex: activePhase.phaseStageIndex,
      phaseStageCount: activePhase.phaseStageCount,
      routingPhaseIndex: activePhase.routingPhaseIndex,
      phaseOrdinal: activePhase.phaseOrdinal,
      phaseCount: activePhase.phaseCount,
      connectionCount: activePhase.connectionCount,
      obstacleCount: activePhase.obstacleCount,
      previousTraceCount: activePhase.previousTraceCount,
      ...this.getExecutionMetadata(activePhase),
      outputTraceCount,
      outputJumperCount,
      errorCount,
      elapsedMs: Math.round(elapsedMs),
      startedAt: activePhase.startedAtIso,
      completedAt: new Date().toISOString(),
    })

    if (
      this.shouldLogPhaseDetails(activePhase) ||
      this.didCrossLongRunningThreshold(activePhase, elapsedMs)
    ) {
      if (!activePhase.hasLoggedStart) {
        this.startLongRunningLogging(activePhase, elapsedMs)
      }
      this.logPhaseEnd(activePhase, {
        outputTraceCount,
        outputJumperCount,
        errorCount,
        elapsedMs,
      })
    }

    if (this.shouldDumpSuccessfulOutput(activePhase.routingPhaseIndex)) {
      this.writeJson(
        this.getPhaseFileName(activePhase, "output.traces.json"),
        outputSrj?.traces ?? [],
      )
    }

    if (this.options.enabled) {
      this.writePngSnapshot(
        `phase-${activePhase.routingPhaseIndex}-routed.png`,
        this.getCircuitJsonWithCompletedPhaseTraces(),
      )
    }

    if (this.isFinalTargetPhaseStage(activePhase)) {
      this.targetPhaseReached = true
    }

    if (this.activePhase === activePhase) {
      this.activePhase = null
    }
  }

  private handleError(event: AutoroutingEventPayload) {
    const activePhase = this.matchActivePhase(event)
    if (!activePhase) return

    const elapsedMs = performance.now() - activePhase.startedAt
    const error = this.serializeError(event.error)
    this.summary.push({
      subcircuit_id: activePhase.subcircuitId,
      componentDisplayName: activePhase.componentDisplayName,
      phaseName: activePhase.phaseName,
      phaseStageIndex: activePhase.phaseStageIndex,
      phaseStageCount: activePhase.phaseStageCount,
      routingPhaseIndex: activePhase.routingPhaseIndex,
      phaseOrdinal: activePhase.phaseOrdinal,
      phaseCount: activePhase.phaseCount,
      connectionCount: activePhase.connectionCount,
      obstacleCount: activePhase.obstacleCount,
      previousTraceCount: activePhase.previousTraceCount,
      ...this.getExecutionMetadata(activePhase),
      elapsedMs: Math.round(elapsedMs),
      error,
      startedAt: activePhase.startedAtIso,
      completedAt: new Date().toISOString(),
    })

    if (this.options.enabled || this.options.logOnError) {
      if (!activePhase.hasLoggedStart) {
        this.logPhaseStart(activePhase, "failed")
      }
      this.log(
        `  ${this.getPhaseLabel(activePhase)} error after ${this.formatElapsed(elapsedMs)}: ${this.formatUserFacingText(error.message)}`,
      )
    }

    if (this.shouldDumpFailedInput(activePhase.routingPhaseIndex)) {
      this.writeJson(
        this.getPhaseFileName(activePhase, "input.simple-route.json"),
        event.simpleRouteJson ?? activePhase.simpleRouteJson ?? {},
      )
      this.writeJson(this.getPhaseFileName(activePhase, "error.json"), {
        type: "autorouter_phase_error",
        subcircuit_id: activePhase.subcircuitId,
        routingPhaseIndex: activePhase.routingPhaseIndex,
        phaseName: activePhase.phaseName,
        phaseStageIndex: activePhase.phaseStageIndex,
        phaseStageCount: activePhase.phaseStageCount,
        phaseOrdinal: activePhase.phaseOrdinal,
        phaseCount: activePhase.phaseCount,
        elapsedMs: Math.round(elapsedMs),
        connectionCount: activePhase.connectionCount,
        obstacleCount: activePhase.obstacleCount,
        previousTraceCount: activePhase.previousTraceCount,
        ...this.getExecutionMetadata(activePhase),
        error,
      })
    }

    if (this.isFinalTargetPhaseStage(activePhase)) {
      this.targetPhaseReached = true
    }

    if (this.activePhase === activePhase) {
      this.activePhase = null
    }
  }

  private writeTimeoutArtifact(activePhase: ActivePhase, elapsedMs: number) {
    const inputFile = this.getPhaseFileName(
      activePhase,
      "input.simple-route.json",
    )
    const previousTracesFile = this.getPhaseFileName(
      activePhase,
      "previous-output.traces.json",
    )
    const timeoutFile = this.getPhaseFileName(activePhase, "timeout.json")
    const boardFile = "board.source-and-pcb.circuit.json"

    this.writeJson(inputFile, activePhase.simpleRouteJson ?? {})
    this.writeJson(previousTracesFile, this.completedPhaseTraces)
    this.writeJson(boardFile, this.getCurrentCircuitJson())

    return this.writeJson(timeoutFile, {
      type: "autorouter_phase_timeout",
      subcircuit_id: activePhase.subcircuitId,
      componentDisplayName: activePhase.componentDisplayName,
      routingPhaseIndex: activePhase.routingPhaseIndex,
      phaseName: activePhase.phaseName,
      phaseStageIndex: activePhase.phaseStageIndex,
      phaseStageCount: activePhase.phaseStageCount,
      phaseOrdinal: activePhase.phaseOrdinal,
      phaseCount: activePhase.phaseCount,
      elapsedMs: Math.round(elapsedMs),
      connectionCount: activePhase.connectionCount,
      obstacleCount: activePhase.obstacleCount,
      previousTraceCount: activePhase.previousTraceCount,
      ...this.getExecutionMetadata(activePhase),
      files: {
        inputSimpleRouteJson: inputFile,
        previousOutputTraces: previousTracesFile,
        boardCircuitJson: boardFile,
      },
      lastProgress: activePhase.lastProgress,
    })
  }

  private checkLongRunning() {
    if (!this.activePhase) return
    const elapsedMs = performance.now() - this.activePhase.startedAt
    if (!this.didCrossLongRunningThreshold(this.activePhase, elapsedMs)) return
    this.startLongRunningLogging(this.activePhase, elapsedMs)
  }

  private didCrossLongRunningThreshold(
    activePhase: ActivePhase,
    elapsedMs: number,
  ) {
    return Boolean(
      !this.options.enabled &&
        this.options.longRunningLogThresholdMs &&
        !activePhase.longRunningLoggingStarted &&
        elapsedMs >= this.options.longRunningLogThresholdMs,
    )
  }

  private startLongRunningLogging(activePhase: ActivePhase, elapsedMs: number) {
    activePhase.longRunningLoggingStarted = true
    this.log(
      kleur.yellow(
        `Autorouting ${this.getPhaseLabel(activePhase)} has been running for ${this.formatElapsed(elapsedMs)}; enabling phase diagnostics. Re-run with --autorouter-debug for full autorouter logs from the start.`,
      ),
    )
    this.logPhaseStart(activePhase, "long-running")
    if (activePhase.lastProgress) {
      this.logProgress(activePhase, activePhase.lastProgress, performance.now())
    }
  }

  private shouldLogPhaseDetails(activePhase: ActivePhase) {
    return Boolean(
      this.options.enabled || activePhase.longRunningLoggingStarted,
    )
  }

  private logPhaseStart(activePhase: ActivePhase, reason?: string) {
    const reasonText = reason ? ` ${reason}` : ""
    this.log(
      `Autorouting ${this.formatUserFacingText(activePhase.componentDisplayName)} ${this.getPhaseLabel(activePhase)}${reasonText} start: connections=${activePhase.connectionCount}, obstacles=${activePhase.obstacleCount}, previous_traces=${activePhase.previousTraceCount}${activePhase.routerDescription ? `, ${activePhase.routerDescription}` : ""}`,
    )

    const connectionNames = this.getConnectionNames(activePhase.simpleRouteJson)
    if (connectionNames.length > 0) {
      this.log(`  connections: ${connectionNames.join(", ")}`)
    }
    activePhase.hasLoggedStart = true
  }

  private logProgress(
    activePhase: ActivePhase,
    event: AutoroutingEventPayload,
    now: number,
  ) {
    const elapsedMs = event.elapsedMs ?? now - activePhase.startedAt
    const details = [
      event.solverName ? `solver=${event.solverName}` : null,
      event.phase ? `solver_phase=${event.phase}` : null,
      event.iteration !== undefined
        ? `iter=${event.iteration}`
        : event.steps !== undefined
          ? `steps=${event.steps}`
          : null,
      event.progress !== undefined
        ? `progress=${Math.round(event.progress * 100)}%`
        : null,
      event.iterationsPerSecond !== undefined
        ? `iterations_per_second=${Math.round(event.iterationsPerSecond)}`
        : null,
      `elapsed=${this.formatElapsed(elapsedMs)}`,
    ].filter(Boolean)

    this.log(
      `  ${this.getPhaseLabel(activePhase)} progress: ${details.join(" ")}`,
    )
  }

  private logPhaseEnd(
    activePhase: ActivePhase,
    {
      outputTraceCount,
      outputJumperCount,
      errorCount,
      elapsedMs,
    }: {
      outputTraceCount: number
      outputJumperCount: number
      errorCount: number
      elapsedMs: number
    },
  ) {
    this.log(
      `  ${this.getPhaseLabel(activePhase)} done: routed_traces=${outputTraceCount}, jumpers=${outputJumperCount}, errors=${errorCount}, elapsed=${this.formatElapsed(elapsedMs)}`,
    )
  }

  private matchActivePhase(event: AutoroutingEventPayload) {
    if (!this.activePhase) return null
    const subcircuitId = event.subcircuit_id ?? event.subcircuitId
    if (subcircuitId && subcircuitId !== this.activePhase.subcircuitId) {
      return null
    }
    return this.activePhase
  }

  private shouldDumpInput(routingPhaseIndex: number) {
    return (
      this.options.dumpSrj === "all" ||
      this.options.dumpSrj === `phase:${routingPhaseIndex}`
    )
  }

  private shouldDumpSuccessfulOutput(routingPhaseIndex: number) {
    return (
      this.options.dumpSrj === "all" ||
      this.options.dumpSrj === `phase:${routingPhaseIndex}`
    )
  }

  private shouldDumpFailedInput(routingPhaseIndex: number) {
    return (
      this.options.dumpSrj === "all" ||
      this.options.dumpSrj === "failed" ||
      this.options.dumpSrj === `phase:${routingPhaseIndex}`
    )
  }

  private writeJson(fileName: string, value: unknown) {
    const debugDir = path.resolve(this.options.debugDir ?? DEFAULT_DEBUG_DIR)
    fs.mkdirSync(debugDir, { recursive: true })
    const filePath = path.join(debugDir, fileName)
    fs.writeFileSync(filePath, JSON.stringify(value, null, 2))
    this.logArtifact(filePath)
    return filePath
  }

  private writePngSnapshot(
    fileName: string,
    circuitJson: CircuitJson,
    options?: { shouldDrawRatsNest?: boolean },
  ) {
    try {
      const pcbSvg = convertCircuitJsonToPcbSvg(circuitJson, options)
      const png = convertSvgToPngBuffer(pcbSvg)
      const debugDir = path.resolve(this.options.debugDir ?? DEFAULT_DEBUG_DIR)
      fs.mkdirSync(debugDir, { recursive: true })
      const filePath = path.join(debugDir, fileName)
      fs.writeFileSync(filePath, png)
      this.logArtifact(filePath)
    } catch (error) {
      const serializedError = this.serializeError(
        error instanceof Error ? error : String(error),
      )
      this.log(
        kleur.yellow(
          `Could not write autorouter debug image ${fileName}: ${serializedError.message}`,
        ),
      )
    }
  }

  private logArtifact(filePath: string) {
    this.log(`Wrote debug artifact: ${path.relative(process.cwd(), filePath)}`)
  }

  private getCircuitJsonWithCompletedPhaseTraces() {
    const circuitJson = [...this.getCurrentCircuitJson()]
    const elementIndexById = new Map<string, number>()

    for (const [index, element] of circuitJson.entries()) {
      const id = this.getCircuitElementId(element)
      if (id) elementIndexById.set(id, index)
    }

    for (const autorouterTrace of this.completedPhaseTraces) {
      const trace = this.normalizeTraceForPcbSnapshot(autorouterTrace)
      if (!trace || typeof trace !== "object") continue
      const id = this.getCircuitElementId(trace)
      const existingIndex = id ? elementIndexById.get(id) : undefined
      if (existingIndex === undefined) {
        circuitJson.push(trace)
        if (id) elementIndexById.set(id, circuitJson.length - 1)
      } else {
        circuitJson[existingIndex] = trace
      }
    }

    return circuitJson
  }

  private normalizeTraceForPcbSnapshot(trace: AutorouterTrace): PcbTrace {
    return {
      ...trace,
      route: trace.route.map((point) => {
        if (point.route_type !== "through_obstacle") return point
        return {
          route_type: "through_pad",
          start: point.start,
          end: point.end,
          start_layer: point.from_layer,
          end_layer: point.to_layer,
          width: point.width,
        }
      }),
    }
  }

  private getCircuitElementId(element: AnyCircuitElement) {
    const idEntry = Object.entries(element).find(
      ([key, value]) =>
        key === `${element.type}_id` && typeof value === "string",
    )
    const id = idEntry?.[1]
    return typeof id === "string" ? id : undefined
  }

  private isRouteElement(element: AnyCircuitElement) {
    return element.type === "pcb_trace" || element.type === "pcb_via"
  }

  private getPhaseFileName(activePhase: ActivePhase, suffix: string) {
    const phaseNumber = activePhase.routingPhaseIndex
    return `phase-${phaseNumber}.${suffix}`
  }

  private getPhaseLabel(activePhase: ActivePhase) {
    const phaseName = activePhase.phaseName ? ` "${activePhase.phaseName}"` : ""
    const stageLabel =
      activePhase.phaseStageIndex !== undefined &&
      activePhase.phaseStageCount !== undefined &&
      activePhase.phaseStageCount > 1
        ? ` stage ${activePhase.phaseStageIndex + 1}/${activePhase.phaseStageCount}`
        : ""
    if (activePhase.phaseCount) {
      return `phase ${activePhase.phaseOrdinal}/${activePhase.phaseCount}${phaseName}${stageLabel}`
    }
    return `phase ${activePhase.phaseOrdinal}${phaseName}${stageLabel}`
  }

  private isFinalTargetPhaseStage(activePhase: ActivePhase) {
    if (!this.options.phaseName) return false
    if (activePhase.phaseName !== this.options.phaseName) return false
    if (
      activePhase.phaseStageIndex === undefined ||
      activePhase.phaseStageCount === undefined
    ) {
      return true
    }
    return activePhase.phaseStageIndex >= activePhase.phaseStageCount - 1
  }

  private formatElapsed(elapsedMs: number) {
    if (elapsedMs < 1_000) return `${Math.round(elapsedMs)}ms`
    return `${(elapsedMs / 1_000).toFixed(1)}s`
  }

  private formatRouter(event: AutoroutingEventPayload) {
    const cacheDescription = event.cacheStatus
      ? event.cacheStatus === "disabled" && event.cacheDisabledReason
        ? `cache=disabled(${event.cacheDisabledReason})`
        : `cache=${event.cacheStatus}`
      : null
    const parts = [
      event.autorouterName ? `router=${event.autorouterName}` : null,
      event.autorouterVersion ? `version=${event.autorouterVersion}` : null,
      event.solverName ? `solver=${event.solverName}` : null,
      event.effort !== undefined ? `effort=${event.effort}x` : null,
      cacheDescription,
      event.cacheKey
        ? `cache_id=${this.formatCacheKeyForLog(event.cacheKey)}`
        : null,
    ].filter(Boolean)
    return parts.join(", ")
  }

  private formatCacheKeyForLog(cacheKey: string) {
    const localPhaseCacheMatch = cacheKey.match(
      /:solver:([a-f0-9]{16}):srj:([a-f0-9]{16})$/,
    )
    if (localPhaseCacheMatch) {
      return `${localPhaseCacheMatch[1].slice(0, 8)}/${localPhaseCacheMatch[2].slice(0, 8)}`
    }
    if (cacheKey.length <= 24) return cacheKey
    return `${cacheKey.slice(0, 10)}…${cacheKey.slice(-10)}`
  }

  private getExecutionMetadata(activePhase: ActivePhase) {
    return {
      autorouterName: activePhase.autorouterName,
      autorouterVersion: activePhase.autorouterVersion,
      solverName: activePhase.solverName,
      effort: activePhase.effort,
      cacheStatus: activePhase.cacheStatus,
      cacheKey: activePhase.cacheKey,
      cacheDisabledReason: activePhase.cacheDisabledReason,
    }
  }

  private getConnectionNames(simpleRouteJson?: SimpleRouteJson) {
    const circuitJsonLookup = this.createCircuitJsonLookup()

    return [
      ...new Set(
        (simpleRouteJson?.connections ?? [])
          .map((connection) =>
            [
              connection.rootConnectionName,
              connection.name,
              connection.source_trace_id,
            ]
              .filter((value): value is string => typeof value === "string")
              .map((value) =>
                this.resolveCircuitJsonId(value, circuitJsonLookup),
              )
              .find((value) => value !== null),
          )
          .filter((name): name is string => name !== null),
      ),
    ]
  }

  private resolveCircuitJsonId(
    value: string,
    lookup = this.createCircuitJsonLookup(),
  ): string | null {
    const { circuitJson, elementById } = lookup
    const element = elementById.get(value)

    if (!element) return value

    if (element.type === "source_trace") {
      if (typeof element.name === "string") return element.name
      return this.getTraceSelector(element, circuitJson)
    }

    if (element.type === "source_net" && typeof element.name === "string") {
      return `net.${element.name}`
    }

    if (element.type === "source_port") {
      return this.getPortSelector(element, circuitJson)
    }

    return null
  }

  private formatUserFacingText(value: string) {
    const circuitJsonLookup = this.createCircuitJsonLookup()
    let formattedValue = value

    // Resolve only ids that occur in the message. Sorting by length avoids
    // replacing an id such as source_trace_1 inside source_trace_10.
    const idsInMessage = [...circuitJsonLookup.elementById.keys()]
      .filter((id) => formattedValue.includes(id))
      .sort((a, b) => b.length - a.length)

    for (const id of idsInMessage) {
      formattedValue = formattedValue.replaceAll(
        id,
        this.resolveCircuitJsonId(id, circuitJsonLookup) ?? "internal element",
      )
    }

    return formattedValue.replace(CIRCUIT_JSON_ID_PATTERN, "internal element")
  }

  private createCircuitJsonLookup(): CircuitJsonLookup {
    const circuitJson = this.getCurrentCircuitJson()
    const elementById = new Map<string, AnyCircuitElement>()

    for (const element of circuitJson) {
      for (const [key, id] of Object.entries(element)) {
        if (!key.endsWith("_id") || typeof id !== "string" || id.length === 0)
          continue
        // Preserve the previous Array.find behavior by keeping the first
        // element that references a given id.
        if (!elementById.has(id)) {
          elementById.set(id, element)
        }
      }
    }

    return { circuitJson, elementById }
  }

  private getTraceSelector(trace: SourceTrace, circuitJson: CircuitJson) {
    const portIds = trace.connected_source_port_ids
    if (!Array.isArray(portIds)) return null

    const selectors = portIds
      .map((portId) =>
        typeof portId === "string"
          ? this.getPortSelectorById(portId, circuitJson)
          : null,
      )
      .filter((selector): selector is string => selector !== null)

    return selectors.length >= 2 ? selectors.join(" to ") : null
  }

  private getPortSelectorById(sourcePortId: string, circuitJson: CircuitJson) {
    const port = circuitJson.find(
      (element): element is SourcePort =>
        element.type === "source_port" &&
        element.source_port_id === sourcePortId,
    )
    return port ? this.getPortSelector(port, circuitJson) : null
  }

  private getPortSelector(port: SourcePort, circuitJson: CircuitJson) {
    const portName =
      typeof port.most_frequently_referenced_by_name === "string"
        ? port.most_frequently_referenced_by_name
        : typeof port.name === "string"
          ? port.name
          : null
    if (!portName) return null

    const component = circuitJson.find(
      (element) =>
        element.type === "source_component" &&
        element.source_component_id === port.source_component_id,
    )
    const componentName =
      component && "name" in component && typeof component.name === "string"
        ? component.name
        : null

    return componentName ? `${componentName}.${portName}` : portName
  }

  private countErrors(simpleRouteJson?: SimpleRouteJson) {
    const errors = simpleRouteJson?.errors
    return Array.isArray(errors) ? errors.length : 0
  }

  private getCurrentCircuitJson(): CircuitJson {
    try {
      const circuitJson = this.rootCircuit?.db?.toArray?.()
      return Array.isArray(circuitJson) ? (circuitJson as CircuitJson) : []
    } catch {
      return []
    }
  }

  private serializeError(error: AutoroutingEventPayload["error"]) {
    if (error instanceof Error) {
      return { message: error.message, stack: error.stack }
    }
    if (typeof error === "string") {
      return { message: error }
    }
    return {
      message: error?.message ?? "Unknown autorouting error",
      stack: error?.stack,
    }
  }

  private log(message: string) {
    this.options.log(message)
  }
}
