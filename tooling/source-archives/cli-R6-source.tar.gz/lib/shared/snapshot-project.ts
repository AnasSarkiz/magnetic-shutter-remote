import fs from "node:fs"
import path from "node:path"
import type { PlatformConfig } from "@tscircuit/props"
import type { VisibleLayerRef } from "circuit-json"
import { snapshotFilesWithWorkerPool } from "cli/snapshot/worker-pool"
import kleur from "kleur"
import {
  getBoardFilePatterns,
  getSnapshotsDir,
  loadRuntimeProjectConfig,
} from "lib/project-config"
import type { PcbSnapshotSettings } from "lib/project-config/project-config-schema"
import type { CameraPreset } from "circuit-json-to-3d-png"
import { findBoardFilesAsync } from "lib/shared/find-board-files"
import { mergePlatformConfigs } from "lib/shared/platform-config-utils"
import { processSnapshotFile } from "lib/shared/process-snapshot-file"
import {
  DEFAULT_IGNORED_PATTERNS,
  normalizeIgnorePattern,
} from "lib/shared/should-ignore-path"

type SnapshotOptions = {
  update?: boolean
  ignored?: string[]
  /** Enable generation of 3d preview snapshots */
  threeD?: boolean
  /** Only generate PCB snapshots */
  pcbOnly?: boolean
  /** Only generate schematic snapshots */
  schematicOnly?: boolean
  /** Only generate simulation snapshots */
  simulationOnly?: boolean
  /** Snapshot only the specified files */
  filePaths?: string[]
  /** Force updating snapshots even if they match */
  forceUpdate?: boolean
  /** Optional platform configuration overrides */
  platformConfig?: PlatformConfig
  /** Overrides pcbSnapshotSettings from project config (merged on top) */
  pcbSnapshotSettingsOverride?: PcbSnapshotSettings
  /** Create visual diff artifacts when snapshots mismatch */
  createDiff?: boolean
  /** Camera preset name for 3D snapshots (implies --3d) */
  cameraPreset?: CameraPreset
  /** Limit PCB snapshots to one layer */
  pcbLayer?: VisibleLayerRef
  /** Number of files to process in parallel (default: 1) */
  concurrency?: number
  onExit?: (code: number) => void
  onError?: (message: string) => void
  onSuccess?: (message: string) => void
}

const hasConfiguredIncludeBoardFiles = (
  projectConfig: Awaited<ReturnType<typeof loadRuntimeProjectConfig>>,
): boolean => {
  const hasConfiguredPatterns = Boolean(
    projectConfig?.includeBoardFiles?.some((pattern) => pattern.trim()),
  )

  return hasConfiguredPatterns
}

export const snapshotProject = async ({
  update = false,
  ignored = [],
  threeD = false,
  pcbOnly = false,
  schematicOnly = false,
  simulationOnly = false,
  filePaths = [],
  forceUpdate = false,
  onExit = (code) => process.exit(code),
  onError = (msg) => console.error(msg),
  onSuccess = (msg) => console.log(msg),
  platformConfig,
  pcbSnapshotSettingsOverride,
  createDiff = false,
  cameraPreset,
  pcbLayer,
  concurrency = 1,
}: SnapshotOptions = {}) => {
  // --camera-preset implies --3d
  if (cameraPreset) {
    threeD = true
  }
  const projectDir = process.cwd()
  const projectConfig = await loadRuntimeProjectConfig(projectDir)
  const ignore = [
    ...DEFAULT_IGNORED_PATTERNS,
    ...ignored.map(normalizeIgnorePattern),
  ]

  const resolvedPaths = filePaths.map((f) => path.resolve(projectDir, f))
  const explicitDirectoryTarget = resolvedPaths.find((resolvedPath) => {
    if (!fs.existsSync(resolvedPath)) {
      return false
    }

    return fs.statSync(resolvedPath).isDirectory()
  })
  const boardFiles = await findBoardFilesAsync({
    projectDir,
    ignore,
    filePaths: resolvedPaths,
  })

  if (boardFiles.length === 0) {
    if (explicitDirectoryTarget) {
      const relativeDirectory =
        path.relative(projectDir, explicitDirectoryTarget) || "."
      const runtimeIncludeBoardFilePatterns =
        projectConfig?.includeBoardFiles?.filter((pattern) => pattern.trim()) ??
        []
      const includeBoardFilePatterns =
        runtimeIncludeBoardFilePatterns.length > 0
          ? runtimeIncludeBoardFilePatterns
          : getBoardFilePatterns(projectDir)
      const patternSourceMessage = hasConfiguredIncludeBoardFiles(projectConfig)
        ? "Searched using tscircuit.config.json includeBoardFiles"
        : "Searched using default includeBoardFiles"

      onError(
        [
          `No circuit files found to create snapshots in directory: "${relativeDirectory}"`,
          `${patternSourceMessage}: ${JSON.stringify(includeBoardFilePatterns)}`,
        ].join("\n"),
      )
      return onExit(1)
    }

    console.log(
      "No entrypoint found. Run 'tsci init' to bootstrap a project or specify a file with 'tsci snapshot <file>'",
    )
    return onExit(0)
  }

  const snapshotsDirName =
    projectConfig?.snapshotsDir ?? getSnapshotsDir(projectDir)
  const pcbSnapshotSettings = pcbSnapshotSettingsOverride
    ? { ...projectConfig?.pcbSnapshotSettings, ...pcbSnapshotSettingsOverride }
    : projectConfig?.pcbSnapshotSettings
  const mergedPlatformConfig = mergePlatformConfigs(
    projectConfig?.platformConfig,
    platformConfig,
  )
  const mismatches: string[] = []
  let didUpdate = false

  const concurrencyValue = Math.max(1, concurrency)
  const processResult = (
    result: Awaited<ReturnType<typeof processSnapshotFile>>,
  ) => {
    for (const warningMessage of result.warningMessages) {
      console.log(warningMessage)
    }

    for (const successPath of result.successPaths) {
      console.log("✅", kleur.gray(successPath))
    }

    didUpdate = didUpdate || result.didUpdate
    mismatches.push(...result.mismatches)
  }

  if (concurrencyValue > 1 && boardFiles.length > 1) {
    console.log(
      `Generating snapshots for ${boardFiles.length} file(s) with concurrency ${concurrencyValue}...`,
    )

    let firstErrorMessage: string | undefined

    try {
      await snapshotFilesWithWorkerPool({
        files: boardFiles,
        projectDir,
        snapshotsDirName,
        concurrency: concurrencyValue,
        snapshotOptions: {
          update,
          threeD,
          pcbOnly,
          schematicOnly,
          simulationOnly,
          forceUpdate,
          platformConfig,
          pcbSnapshotSettings,
          createDiff,
          cameraPreset,
          pcbLayer,
        },
        stopOnFailure: true,
        onLog: (lines) => {
          for (const line of lines) {
            console.log(line)
          }
        },
        onJobComplete: (jobResult) => {
          const { result } = jobResult
          processResult(result)
          if (!result.ok && !firstErrorMessage) {
            firstErrorMessage =
              result.errorMessage ?? "Snapshot generation failed"
          }
        },
      })
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : String(error)
      onError(kleur.red(errorMessage))
      return onExit(1)
    }

    if (firstErrorMessage) {
      onError(firstErrorMessage)
      return onExit(1)
    }
  } else {
    for (const file of boardFiles) {
      const result = await processSnapshotFile({
        file,
        projectDir,
        snapshotsDirName,
        update,
        threeD,
        pcbOnly,
        schematicOnly,
        simulationOnly,
        forceUpdate,
        platformConfig: mergedPlatformConfig,
        pcbSnapshotSettings,
        createDiff,
        cameraPreset,
        pcbLayer,
      })

      processResult(result)

      if (!result.ok) {
        onError(result.errorMessage ?? "Snapshot generation failed")
        return onExit(1)
      }
    }
  }

  if (update) {
    didUpdate
      ? onSuccess("Created snapshots")
      : onSuccess("All snapshots already up to date")
    return onExit(0)
  }

  if (mismatches.length) {
    onError(
      `Snapshot mismatch:\n${mismatches.join("\n")}\n\nRun with --update to fix.`,
    )
    return onExit(1)
  }

  onSuccess("All snapshots match")
  return onExit(0)
}
