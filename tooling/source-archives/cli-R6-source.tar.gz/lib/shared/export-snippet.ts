import { convertSvgToPngBuffer } from "./convert-svg-to-png"
import { convertCircuitJsonToPcbSvg } from "lib/shared/render-pcb-svg"
import fs from "node:fs"
import path from "node:path"
import { promisify } from "node:util"
import type { PlatformConfig } from "@tscircuit/props"
import type { AnyCircuitElement } from "circuit-json"
import {
  convertBomRowsToCsv,
  convertCircuitJsonToBomRows,
} from "circuit-json-to-bom-csv"
import { convertCircuitJsonToGerberFiles } from "circuit-json-to-gerber"
import { convertCircuitJsonToGltf } from "circuit-json-to-gltf"
import {
  CircuitJsonToKicadPcbConverter,
  CircuitJsonToKicadProConverter,
  CircuitJsonToKicadSchConverter,
  resolveAndLoadKicad3dModelFiles,
} from "circuit-json-to-kicad"
import { convertCircuitJsonToPickAndPlaceCsv } from "circuit-json-to-pnp-csv"
import { convertCircuitJsonToReadableNetlist } from "circuit-json-to-readable-netlist"
import { circuitJsonToStep } from "circuit-json-to-step"
import { circuitJsonToFdmComponentBox } from "circuit-json-to-fdm-component-box"
import {
  convertCircuitJsonToAssemblySvg,
  convertCircuitJsonToStackedSchematicSheetsSvg,
} from "circuit-to-svg"
import { convertCircuitJsonToDsnString } from "dsn-converter"
import JSZip from "jszip"
import type { PcbSnapshotSettings } from "lib/project-config/project-config-schema"
import { generateCircuitJson } from "lib/shared/generate-circuit-json"
import { getCircuitJsonToGltfOptions } from "lib/shared/get-circuit-json-to-gltf-options"
import { getOrGenerateCircuitJson } from "lib/shared/get-or-generate-circuit-json"
import { getPlatformConfigWithCliDefaults } from "lib/shared/get-platform-config-with-cli-defaults"
import { loadLocalStepModelFsMap } from "lib/shared/load-local-step-model-fs-map"
import { mergePlatformConfigs } from "lib/shared/platform-config-utils"
import { convertCircuitJsonToSchematicPdf } from "./convert-circuit-json-to-schematic-pdf"
import { convertToKicadLibrary } from "./convert-to-kicad-library"
import { importFromUserLand } from "./importFromUserLand"
import { isCircuitJsonFile } from "./is-circuit-json-file"

const writeFileAsync = promisify(fs.writeFile)

export const ALLOWED_EXPORT_FORMATS = [
  "json",
  "circuit-json",
  "schematic-svg",
  "schematic-pdf",
  "pcb-svg",
  "pcb-png",
  "gerbers",
  "readable-netlist",
  "gltf",
  "glb",
  "specctra-dsn",
  "kicad_sch",
  "kicad_pcb",
  "kicad_zip",
  "altium",
  "kicad-library",
  "srj",
  "step",
  "assembly-svg",
  "component-box-3mf",
] as const

export type ExportFormat = (typeof ALLOWED_EXPORT_FORMATS)[number]

const OUTPUT_EXTENSIONS: Record<ExportFormat, string> = {
  json: ".circuit.json",
  "circuit-json": ".circuit.json",
  "schematic-svg": "-schematic.svg",
  "schematic-pdf": "-schematic.pdf",
  "pcb-svg": "-pcb.svg",
  "pcb-png": "-pcb.png",
  "assembly-svg": "-assembly.svg",
  gerbers: "-gerbers.zip",
  "readable-netlist": "-readable.netlist",
  gltf: ".gltf",
  glb: ".glb",
  "specctra-dsn": ".dsn",
  kicad_sch: ".kicad_sch",
  kicad_pcb: ".kicad_pcb",
  kicad_zip: "-kicad.zip",
  altium: "-altium.zip",
  "kicad-library": "",
  srj: ".simple-route.json",
  step: ".step",
  "component-box-3mf": "-component-box.3mf",
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null

const unwrapSimpleRouteJson = (value: unknown) => {
  if (
    isRecord(value) &&
    isRecord(value.simpleRouteJson) &&
    ("connections" in value.simpleRouteJson ||
      "obstacles" in value.simpleRouteJson ||
      "bounds" in value.simpleRouteJson)
  ) {
    return value.simpleRouteJson
  }

  return value
}

type ExportOptions = {
  filePath: string
  format: ExportFormat
  writeFile?: boolean
  outputPath?: string
  platformConfig?: PlatformConfig
  pcbSnapshotSettings?: PcbSnapshotSettings
  onExit?: (code: number) => void
  onError?: (message: string) => void
  onSuccess: (data: {
    outputDestination: string
    outputContent: string | Buffer
  }) => void
}

export const exportSnippet = async ({
  filePath,
  format,
  outputPath,
  platformConfig,
  pcbSnapshotSettings,
  writeFile = true,
  onExit = (code) => process.exit(code),
  onError = (message) => console.error(message),
  onSuccess = (result: unknown) => console.log(result),
}: ExportOptions) => {
  if (!ALLOWED_EXPORT_FORMATS.includes(format)) {
    onError(`Invalid format: ${format}`)
    return onExit(1)
  }

  const projectDir = path.dirname(filePath)
  const outputBaseName = path.basename(filePath).replace(/\.[^.]+$/, "")
  const outputFileName = `${outputBaseName}${OUTPUT_EXTENSIONS[format]}`
  const outputDestination =
    outputPath && path.isAbsolute(outputPath)
      ? outputPath
      : path.join(projectDir, outputPath ?? outputFileName)

  // Handle kicad-library separately - it doesn't need generateCircuitJson
  if (format === "kicad-library") {
    try {
      const result = await convertToKicadLibrary({
        filePath,
        libraryName: outputBaseName,
        outputDir: outputDestination,
      })
      if (writeFile) {
        onSuccess({ outputDestination: result.outputDir, outputContent: "" })
      }
      return onExit(0)
    } catch (err) {
      onError(`Error exporting KiCad library: ${err}`)
      return onExit(1)
    }
  }

  let circuitJson: AnyCircuitElement[]

  if (isCircuitJsonFile(filePath)) {
    const rawCircuitJson = await fs.promises
      .readFile(filePath, "utf-8")
      .catch((err) => {
        onError(`Error reading circuit JSON file: ${err}`)
        return null
      })

    if (!rawCircuitJson) return onExit(1)

    try {
      const parsedCircuitJson = JSON.parse(rawCircuitJson)
      if (!Array.isArray(parsedCircuitJson)) {
        onError("Error parsing circuit JSON file: expected an array")
        return onExit(1)
      }
      circuitJson = parsedCircuitJson as AnyCircuitElement[]
    } catch (err) {
      onError(`Error parsing circuit JSON file: ${err}`)
      return onExit(1)
    }
  } else {
    const isJlcpcbFabricationExport = format === "gerbers"
    const fabricationPlatformConfig = isJlcpcbFabricationExport
      ? getPlatformConfigWithCliDefaults(
          mergePlatformConfigs(platformConfig, {
            enablePartOrientationAnalysis: true,
          }),
        )
      : platformConfig
    const generateCircuitData = isJlcpcbFabricationExport
      ? generateCircuitJson
      : getOrGenerateCircuitJson
    const circuitData = await generateCircuitData({
      filePath,
      saveToFile: format === "circuit-json",
      platformConfig: fabricationPlatformConfig,
    }).catch((err) => {
      onError(`Error generating circuit JSON: ${err}`)
      return null
    })

    if (!circuitData) return onExit(1)
    circuitJson = circuitData.circuitJson
  }

  let outputContent: string | Buffer

  switch (format) {
    case "schematic-svg":
      outputContent = convertCircuitJsonToStackedSchematicSheetsSvg(circuitJson)
      break
    case "schematic-pdf":
      outputContent = await convertCircuitJsonToSchematicPdf(circuitJson)
      break
    case "pcb-svg":
    case "pcb-png":
      try {
        const svg = convertCircuitJsonToPcbSvg(circuitJson, pcbSnapshotSettings)
        outputContent =
          format === "pcb-png" ? Buffer.from(convertSvgToPngBuffer(svg)) : svg
      } catch (error) {
        onError(
          `Error rendering PCB image: ${error instanceof Error ? error.message : String(error)}`,
        )
        return onExit(1)
      }
      break
    case "specctra-dsn":
      outputContent = convertCircuitJsonToDsnString(circuitJson)
      break
    case "readable-netlist":
      outputContent = convertCircuitJsonToReadableNetlist(circuitJson)
      break
    case "gltf":
      outputContent = JSON.stringify(
        await convertCircuitJsonToGltf(
          circuitJson,
          getCircuitJsonToGltfOptions({ format: "gltf" }),
        ),
        null,
        2,
      )
      break
    case "glb":
      outputContent = Buffer.from(
        (await convertCircuitJsonToGltf(
          circuitJson,
          getCircuitJsonToGltfOptions({ format: "glb" }),
        )) as ArrayBuffer,
      )
      break
    case "srj":
      {
        const userLandTscircuit = await importFromUserLand("tscircuit")
        const simpleRouteJson = unwrapSimpleRouteJson(
          userLandTscircuit.getSimpleRouteJsonFromCircuitJson({
            circuitJson,
          }),
        )
        outputContent = JSON.stringify(simpleRouteJson, null, 2)
      }
      break
    case "altium": {
      const { convertCircuitJsonToAltiumZip } = await import(
        "circuit-json-to-altium"
      )
      outputContent = Buffer.from(
        await convertCircuitJsonToAltiumZip(circuitJson, outputBaseName),
      )
      break
    }
    case "kicad_sch": {
      const converter = new CircuitJsonToKicadSchConverter(circuitJson)
      converter.runUntilFinished()
      outputContent = converter.getOutputString()
      break
    }
    case "kicad_pcb": {
      const converter = new CircuitJsonToKicadPcbConverter(circuitJson)
      converter.runUntilFinished()
      outputContent = converter.getOutputString()
      break
    }
    case "kicad_zip": {
      const schConverter = new CircuitJsonToKicadSchConverter(circuitJson)
      schConverter.runUntilFinished()
      const pcbConverter = new CircuitJsonToKicadPcbConverter(circuitJson, {
        includeBuiltin3dModels: true,
        projectName: outputBaseName,
      })
      pcbConverter.runUntilFinished()
      const proConverter = new CircuitJsonToKicadProConverter(circuitJson, {
        projectName: outputBaseName,
        schematicFilename: `${outputBaseName}.kicad_sch`,
        pcbFilename: `${outputBaseName}.kicad_pcb`,
      })
      proConverter.runUntilFinished()

      const zip = new JSZip()
      zip.file(`${outputBaseName}.kicad_sch`, schConverter.getOutputString())
      zip.file(`${outputBaseName}.kicad_pcb`, pcbConverter.getOutputString())
      zip.file(`${outputBaseName}.kicad_pro`, proConverter.getOutputString())

      await resolveAndLoadKicad3dModelFiles({
        model3dSourcePaths: pcbConverter.getModel3dSourcePaths(),
        projectName: outputBaseName,
        fetch: platformConfig?.platformFetch ?? globalThis.fetch,
        readFile: (modelPath) =>
          fs.promises.readFile(path.resolve(projectDir, modelPath)),
        onModelFile: ({ outputPath, content }) => {
          zip.file(outputPath, content)
        },
        onError: ({ sourcePath }) => {
          console.warn(`Failed to load 3D model from ${sourcePath}`)
        },
      })

      outputContent = await zip.generateAsync({ type: "nodebuffer" })
      break
    }
    case "gerbers": {
      const zip = new JSZip()

      const gerberFiles = convertCircuitJsonToGerberFiles(circuitJson, {
        flip_y_axis: false,
      })
      for (const [fileName, fileContents] of Object.entries(gerberFiles)) {
        zip.file(fileName, fileContents)
      }

      const bomRows = await convertCircuitJsonToBomRows({ circuitJson })
      const bomCsv = await convertBomRowsToCsv(bomRows)
      zip.file("bom.csv", bomCsv)

      const pnpCsv = await convertCircuitJsonToPickAndPlaceCsv(circuitJson, {
        supplier: "jlcpcb",
      })
      zip.file("pick_and_place.csv", pnpCsv)

      outputContent = await zip.generateAsync({ type: "nodebuffer" })
      break
    }

    case "step":
      outputContent = await circuitJsonToStep(circuitJson, {
        includeComponents: true,
        includeExternalMeshes: true,
        fsMap: await loadLocalStepModelFsMap(circuitJson),
      })
      break
    case "assembly-svg":
      outputContent = convertCircuitJsonToAssemblySvg(circuitJson)
      break
    case "component-box-3mf":
      outputContent = Buffer.from(
        await circuitJsonToFdmComponentBox(circuitJson),
      )
      break
    default:
      outputContent = JSON.stringify(circuitJson, null, 2)
  }
  if (writeFile) {
    await writeFileAsync(outputDestination, outputContent).catch((err) => {
      onError(`Error writing file: ${err}`)
      return onExit(1)
    })
  }

  onSuccess({
    outputDestination,
    outputContent,
  })

  onExit(0)
}
