import { cliConfig, getSessionToken } from "lib/cli-config"
import { fetchAccount } from "lib/registry-api/fetch-account"
import { getRegistryApiKy } from "lib/registry-api/get-ky"
import * as fs from "node:fs"
import * as path from "node:path"
import semver from "semver"
import Debug from "debug"
import kleur from "kleur"
import { getEntrypoint } from "./get-entrypoint"
import prompts from "lib/utils/prompts"
import { getUnscopedPackageName } from "lib/utils/get-unscoped-package-name"
import { getPackageAuthor } from "lib/utils/get-package-author"
import { validatePackageName } from "lib/utils/validate-package-name"
import { getPackageFilePaths } from "lib/dev/get-package-file-paths"
import { checkOrgAccess } from "lib/utils/check-org-access"
import { isBinaryFile } from "./is-binary-file"
import { hasBinaryContent } from "./has-binary-content"
import { gzipSync } from "node:zlib"

type PushOptions = {
  filePath?: string
  isPrivate?: boolean
  versionTag?: string
  includeDist?: boolean
  compress?: boolean
  log?: (message: string) => void
  onExit?: (code: number) => void
  onError?: (message: string) => void
  onSuccess?: (message: string) => void
}

const debug = Debug("tsci:push-snippet")

const findPushProject = async ({
  filePath,
  onError,
}: {
  filePath?: string
  onError: (message: string) => void
}): Promise<{
  snippetFilePath?: string
  packageJsonPath?: string
  projectDir: string
} | null> => {
  if (filePath) {
    const snippetFilePath = await getEntrypoint({
      filePath,
      onSuccess: () => {},
      onError,
    })

    if (!snippetFilePath) {
      return null
    }

    const packageJsonPath = [
      path.resolve(path.join(path.dirname(snippetFilePath), "package.json")),
      path.resolve(path.join(process.cwd(), "package.json")),
    ].find((candidatePath) => fs.existsSync(candidatePath))
    const projectDir = packageJsonPath
      ? path.dirname(packageJsonPath)
      : path.dirname(snippetFilePath)

    return { snippetFilePath, packageJsonPath, projectDir }
  }

  const projectDir = process.cwd()
  const packageJsonPath = path.resolve(path.join(projectDir, "package.json"))
  if (!fs.existsSync(packageJsonPath)) {
    return { projectDir }
  }

  const snippetFilePath =
    (await getEntrypoint({
      projectDir,
      onSuccess: () => {},
      onError: () => {},
    })) ?? undefined

  return { snippetFilePath, packageJsonPath, projectDir }
}

export const getArchivePayload = (
  filePaths: string[],
  projectDir: string,
  packageNameWithVersion: string,
) => {
  const files = filePaths.map((fullFilePath) => {
    const relativeFilePath = path.relative(projectDir, fullFilePath)
    const fileBuffer = fs.readFileSync(fullFilePath)
    const isBinary =
      isBinaryFile(relativeFilePath) || hasBinaryContent(fileBuffer)

    return isBinary
      ? {
          file_path: relativeFilePath,
          content_base64: fileBuffer.toString("base64"),
        }
      : {
          file_path: relativeFilePath,
          content_text: fileBuffer.toString("utf8"),
        }
  })
  const archive = gzipSync(JSON.stringify({ files }), { level: 9 })

  return {
    package_name_with_version: packageNameWithVersion,
    archive_base64: archive.toString("base64"),
  }
}

export const pushSnippet = async ({
  filePath,
  isPrivate,
  versionTag,
  includeDist = false,
  compress = false,
  log = console.log,
  onExit = (code) => process.exit(code),
  onError = (message) => console.error(message),
  onSuccess = (message) => console.log(message),
}: PushOptions) => {
  const sessionToken = getSessionToken()
  if (!sessionToken) {
    onError(
      "You need to log in to save package. Run 'tsci login' to authenticate.",
    )
    return onExit(1)
  }

  const pushProject = await findPushProject({
    filePath,
    onError,
  })

  if (!pushProject) {
    return onExit(1)
  }

  const { snippetFilePath, packageJsonPath, projectDir } = pushProject

  if (!packageJsonPath) {
    onError(
      "No package.json found, try running 'tsci init' to bootstrap the project",
    )
    return onExit(1)
  }

  let packageJson: {
    name?: string
    author?: string
    version?: string
    license?: string
  } = {}
  if (fs.existsSync(packageJsonPath)) {
    try {
      packageJson = JSON.parse(fs.readFileSync(packageJsonPath).toString())
    } catch {
      onError("Invalid package.json")
      return onExit(1)
    }
  }

  if (snippetFilePath && !fs.existsSync(snippetFilePath)) {
    onError(`File not found: ${snippetFilePath}`)
    return onExit(1)
  }

  const ky = getRegistryApiKy({ sessionToken })
  const currentUsername = process.env.TSCIRCUIT_TOKEN
    ? (await fetchAccount())?.tscircuit_handle
    : cliConfig.get("tscircuitHandle")
  if (!currentUsername) {
    onError("You need to set your tscircuit handle to publish packages")
    return onExit(1)
  }
  let unscopedPackageName = getUnscopedPackageName(packageJson.name ?? "")
  const packageJsonAuthor = getPackageAuthor(packageJson.name ?? "")

  // Validate the unscoped package name if it already exists
  if (unscopedPackageName) {
    const validationError = validatePackageName(unscopedPackageName)
    if (validationError) {
      onError(
        `Invalid package name "${unscopedPackageName}": ${validationError}\n` +
          `Please fix the package name in: ${packageJsonPath}`,
      )
      return onExit(1)
    }
  }

  const packageJsonHasName = Boolean(packageJson.name)
  if (!packageJsonHasName) {
    console.log(kleur.gray("No package name found in package.json"))
    let inputName: string
    ;({ unscopedPackageName: inputName } = await prompts({
      type: "text",
      name: "unscopedPackageName",
      message: `Enter the unscoped package name:`,
      instructions: `Your package will be published as "@tsci/${currentUsername}.<unscoped package name>"`,
    }))

    if (!inputName) {
      onError("Package name is required")
      return onExit(1)
    }

    // Validate the package name
    const validationError = validatePackageName(inputName)
    if (validationError) {
      onError(`Invalid package name: ${validationError}`)
      return onExit(1)
    }

    unscopedPackageName = inputName

    // Write the package name to the package.json file
    packageJson.name = `@tsci/${currentUsername}.${unscopedPackageName}`
    fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2))
  }

  // Determine the account name to use (either user or org)
  let accountName = currentUsername

  if (packageJsonAuthor && currentUsername !== packageJsonAuthor) {
    const hasOrgAccess = await checkOrgAccess(ky, packageJsonAuthor)
    if (hasOrgAccess) {
      accountName = packageJsonAuthor
      console.log(
        kleur.gray(
          `Publishing to org "${packageJsonAuthor}" (user: ${accountName})`,
        ),
      )
    } else {
      onError(
        `You don't have access to the org "${packageJsonAuthor}". Either:\n` +
          `  1. Get added as a member of the "${packageJsonAuthor}" org, or\n` +
          `  2. Change the package name in package.json to use your username: "@tsci/${currentUsername}.${unscopedPackageName}"`,
      )
      return onExit(1)
    }
  }

  const scopedPackageName = `${accountName}/${unscopedPackageName}`
  const tsciPackageName = `@tsci/${accountName}.${unscopedPackageName}`

  const previousPackageReleases = await ky
    .post<{
      error?: { error_code: string }
      package_releases?: { version: string; is_latest: boolean }[]
    }>("package_releases/list", {
      json: { package_name: scopedPackageName },
    })
    .json()
    .then((response) => response.package_releases)

  const lastKnownVersion =
    packageJson.version ??
    previousPackageReleases?.[previousPackageReleases.length - 1]?.version

  let packageVersion: string
  if (!lastKnownVersion) {
    console.log(
      "No package version found in package.json or previous releases, setting to 0.0.1",
    )
    packageVersion = "0.0.1"
  } else {
    packageVersion = lastKnownVersion
  }

  const updatePackageJsonVersion = (newVersion?: string) => {
    try {
      packageJson.version = newVersion ?? `${packageVersion}`
      fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2))
    } catch (error) {
      onError(`Failed to update package.json version: ${error}`)
    }
  }

  const doesPackageExist = await ky
    .post<{ error?: { error_code: string } }>("packages/get", {
      json: { name: scopedPackageName },
    })
    .json()
    .then((response) => {
      debug("doesPackageExist", response)
      return true
    })
    .catch((error) => {
      // Package not found
      if (error.response.status === 404) {
        return false
      }
    })

  if (!doesPackageExist) {
    const { createPackage, visibility } = await prompts([
      {
        type: "confirm",
        name: "createPackage",
        initial: true,
        message: `Package "${tsciPackageName}" does not exist. Create it?`,
      },
      {
        name: "visibility",
        type: "select",
        message: "Package Visibility:",
        choices: [
          { title: "Public", value: "public", selected: !isPrivate },
          { title: "Private", value: "private", selected: isPrivate },
        ],
      },
    ])
    if (!createPackage || !visibility) {
      onError(`aborted`)
      return onExit(1)
    }

    await ky
      .post("packages/create", {
        json: {
          name: scopedPackageName,
          is_private: visibility === "private",
        },
        headers: { Authorization: `Bearer ${sessionToken}` },
      })
      .json()
      .then((response) => {
        debug("createPackage", response)
        log(`Package created`)
      })
      .catch((error) => {
        onError(`Error creating package: ${error}`)
        return onExit(1)
      })
  }

  const buildReleaseVersion = (baseVersion: string) =>
    versionTag ? `${baseVersion}-${versionTag}` : baseVersion

  let releaseVersion = buildReleaseVersion(packageVersion)

  while (true) {
    const releaseExists = await ky
      .post<{
        error?: { error_code: string }
        package_release?: { version: string }
      }>("package_releases/get", {
        json: {
          package_name_with_version: `${scopedPackageName}@${releaseVersion}`,
        },
      })
      .json()
      .then((response) => {
        debug("doesReleaseExist", response)
        if (response.package_release?.version) {
          return true
        }
        return !(response.error?.error_code === "package_release_not_found")
      })
      .catch((error: unknown) => {
        const httpError = error as { response?: { status?: number } }
        // Package release not found
        if (httpError?.response?.status === 404) {
          return false
        }
        onError(`Error checking if release exists: ${error}`)
        return undefined
      })

    if (releaseExists === undefined) {
      return onExit(1)
    }

    if (!releaseExists) {
      break
    }

    const bumpedVersion = semver.inc(packageVersion, "patch")
    if (!bumpedVersion) {
      onError(`Failed to increment version from ${packageVersion}`)
      return onExit(1)
    }

    log(`Incrementing Package Version ${packageVersion} -> ${bumpedVersion}`)
    packageVersion = bumpedVersion
    updatePackageJsonVersion(packageVersion)
    releaseVersion = buildReleaseVersion(packageVersion)
  }

  await ky
    .post("package_releases/create", {
      json: {
        package_name_with_version: `${scopedPackageName}@${releaseVersion}`,
      },
    })
    .catch((error) => {
      onError(`Error creating release: ${error}`)
      return onExit(1)
    })

  const filePaths = getPackageFilePaths(
    projectDir,
    includeDist ? [] : ["**/dist/**"],
  )
  const uploadResults: {
    succeeded: string[]
    failed: { file: string; error: string }[]
  } = { succeeded: [], failed: [] }

  const packageNameWithVersion = `${scopedPackageName}@${releaseVersion}`
  const shouldUploadArchive = compress || process.env.TSCI_PUSH_ARCHIVE === "1"

  if (shouldUploadArchive) {
    log(kleur.gray("Uploading package archive..."))
    try {
      const archivePayload = getArchivePayload(
        filePaths,
        projectDir,
        packageNameWithVersion,
      )
      await ky.post("package_files/upload_archive", {
        json: archivePayload,
      })
      for (const fullFilePath of filePaths) {
        const relativeFilePath = path.relative(projectDir, fullFilePath)
        uploadResults.succeeded.push(relativeFilePath)
      }
      log(kleur.gray(`📦 Uploaded archive with ${filePaths.length} files`))
    } catch (error) {
      log(
        kleur.yellow(
          `Archive upload failed, falling back to file-by-file upload: ${error}`,
        ),
      )
    }
  }

  if (uploadResults.succeeded.length === 0) {
    for (const fullFilePath of filePaths) {
      const relativeFilePath = path.relative(projectDir, fullFilePath)

      // Check if file is binary by extension first, then by content if needed
      const fileBuffer = fs.readFileSync(fullFilePath)
      const isBinary =
        isBinaryFile(relativeFilePath) || hasBinaryContent(fileBuffer)

      // Build the request payload based on whether the file is binary or text
      const payload: {
        file_path: string
        package_name_with_version: string
        content_text?: string
        content_base64?: string
      } = {
        file_path: relativeFilePath,
        package_name_with_version: packageNameWithVersion,
      }

      if (isBinary) {
        payload.content_base64 = fileBuffer.toString("base64")
      } else {
        payload.content_text = fileBuffer.toString("utf-8")
      }

      await ky
        .post("package_files/create", {
          json: payload,
        })
        .then(() => {
          const icon = isBinary ? "📦" : "⬆︎"
          console.log(kleur.gray(`${icon} ${relativeFilePath}`))
          uploadResults.succeeded.push(relativeFilePath)
        })
        .catch(async (error) => {
          const errorDetails = String(error)?.split(`\n\nRequest Body:`)?.[0]
          console.log(kleur.red(`  ${relativeFilePath} - failed`))
          uploadResults.failed.push({
            file: relativeFilePath,
            error: errorDetails,
          })
        })
    }
  }

  log("\n")
  log(kleur.bold("Upload Summary"))
  log(kleur.green(`  Succeeded: ${uploadResults.succeeded.length} files`))
  if (uploadResults.failed.length > 0) {
    log(kleur.red(`  Failed: ${uploadResults.failed.length} files`))
    for (const { file, error } of uploadResults.failed) {
      log(kleur.red(`    - ${file}`))
      log(kleur.gray(`      ${error}`))
    }
  }
  if (uploadResults.failed.length > 0 && uploadResults.succeeded.length === 0) {
    onError(
      `\nPublish completed with ${uploadResults.failed.length} failed upload(s)`,
    )
    return onExit(1)
  }

  if (uploadResults.failed.length > 0 && uploadResults.succeeded.length > 0) {
    onSuccess(
      `\nPublish completed with ${uploadResults.succeeded.length} files uploaded and ${uploadResults.failed.length} failed upload(s)`,
    )
    return onExit(1)
  }
  await ky.post("package_releases/update", {
    json: {
      package_name_with_version: `${scopedPackageName}@${releaseVersion}`,
      ready_to_build: true,
      ...(typeof packageJson.license === "string" && packageJson.license.trim()
        ? { license: packageJson.license.trim() }
        : {}),
    },
  })

  onSuccess(
    [
      "\n",
      kleur.bold().green(`"${tsciPackageName}@${releaseVersion}" published!`),
      kleur.underline(kleur.blue(`https://tscircuit.com/${scopedPackageName}`)),
    ].join("\n"),
  )

  return onExit(0)
}
