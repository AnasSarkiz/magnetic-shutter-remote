import * as fs from "node:fs"
import * as path from "node:path"
import kleur from "kleur"
import { prompts } from "lib/utils/prompts"
import { getPackageManager } from "./get-package-manager"
import { resolveTarballUrlFromRegistry } from "./resolve-tarball-url-from-registry"
import { detectAndSetupKicadLibrary } from "./detect-and-setup-kicad-library"
import { handleRegistryAuthError } from "./handle-registry-auth-error"
import { withProjectInstallLock } from "./with-project-install-lock"

/**
 * Checks if a package spec is a tscircuit component format and normalizes it.
 * Returns null if it's not a tscircuit component format (e.g., regular npm package, URL, etc.)
 * @param packageSpec - The package specifier
 * @returns The normalized @tsci scoped package name or null if not a tscircuit component
 */
export function normalizeTscircuitPackageName(
  packageSpec: string,
): string | null {
  // Already a tscircuit scoped package
  if (
    packageSpec.startsWith("@tscircuit/") ||
    packageSpec.startsWith("@tsci/")
  ) {
    return packageSpec
  }

  // Check for URLs or git repos - these are not tscircuit components
  if (
    packageSpec.startsWith("http://") ||
    packageSpec.startsWith("https://") ||
    packageSpec.startsWith("git+") ||
    packageSpec.startsWith("git://")
  ) {
    return null
  }

  // Check for npm package with version (e.g., lodash@4.17.21) - not a tscircuit component
  if (packageSpec.includes("@") && !packageSpec.startsWith("@")) {
    return null
  }

  // Check for scoped packages that aren't tscircuit
  if (
    packageSpec.startsWith("@") &&
    !packageSpec.startsWith("@tsci/") &&
    !packageSpec.startsWith("@tscircuit/")
  ) {
    return null
  }

  // Try to match author/component or author.component format
  const match = packageSpec.match(/^([^/.@]+)[/.]([^/.@]+)$/)
  if (match) {
    const [, author, componentName] = match
    return `@tsci/${author}.${componentName}`
  }

  // Anything else is treated as a regular package name
  return null
}

export async function addPackage(
  packageSpec: string,
  projectDir: string = process.cwd(),
) {
  return addPackages([packageSpec], projectDir)
}

/**
 * Adds packages to the project (works like bun add).
 * Detects tscircuit component formats and handles @tsci registry setup.
 * All other package specs are passed directly to the package manager.
 *
 * @param packageSpecs - Array of package specifiers
 * @param projectDir - The root directory of the project (defaults to process.cwd())
 */
export async function addPackages(
  packageSpecs: string[],
  projectDir: string = process.cwd(),
) {
  // Cover registry setup and post-install setup as well as the package manager.
  return withProjectInstallLock(projectDir, () =>
    addPackagesUnlocked(packageSpecs, projectDir),
  )
}

async function addPackagesUnlocked(packageSpecs: string[], projectDir: string) {
  const normalized = packageSpecs.map((spec) => ({
    original: spec,
    normalized: normalizeTscircuitPackageName(spec),
  }))

  const displayNames = normalized
    .map((p) => p.normalized || p.original)
    .join(" ")
  console.log(kleur.cyan(`Adding ${kleur.bold(displayNames)}...`))

  const hasTsciPackage = normalized.some((p) =>
    p.normalized?.startsWith("@tsci/"),
  )

  let useTarball = false
  if (hasTsciPackage) {
    const npmrcPath = path.join(projectDir, ".npmrc")
    const npmrcContent = fs.existsSync(npmrcPath)
      ? fs.readFileSync(npmrcPath, "utf-8")
      : ""

    let hasTsciRegistry = /@tsci[/:]/.test(npmrcContent)

    if (!hasTsciRegistry) {
      const { addRegistry } = await prompts({
        type: "confirm",
        name: "addRegistry",
        message:
          "No .npmrc entry for @tsci packages was found. Add '@tsci:registry=https://npm.tscircuit.com'?",
        initial: true,
      })

      if (addRegistry) {
        const trimmedContent = npmrcContent.trimEnd()
        const newContent = `${trimmedContent.length > 0 ? `${trimmedContent}\n` : ""}@tsci:registry=https://npm.tscircuit.com\n`
        fs.writeFileSync(npmrcPath, newContent)
        console.log(kleur.green("✓ Updated .npmrc with tscircuit registry"))
        hasTsciRegistry = true
      } else {
        console.log(
          "Continuing without updating .npmrc; will fetch package directly from registry tarball.",
        )
        useTarball = true
      }
    }
  }

  const installTargets = await Promise.all(
    normalized.map(async ({ original, normalized: norm }) => {
      if (norm?.startsWith("@tsci/") && useTarball) {
        return resolveTarballUrlFromRegistry(norm)
      }
      return norm || original
    }),
  )

  const packageManager = getPackageManager()
  try {
    await packageManager.install({
      name: installTargets.join(" "),
      cwd: projectDir,
    })
    console.log(kleur.green(`✓ Added ${kleur.bold(displayNames)} successfully`))

    for (const spec of packageSpecs) {
      await detectAndSetupKicadLibrary(spec, projectDir)
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error)
    console.error(kleur.red(`✗ Failed to add ${displayNames}:`), errorMessage)
    handleRegistryAuthError({ error, projectDir })
    throw new Error(`Failed to add ${displayNames}: ${errorMessage}`)
  }
}
