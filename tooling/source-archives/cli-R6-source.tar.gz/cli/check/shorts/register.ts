import { mkdir, writeFile } from "node:fs/promises"
import path from "node:path"
import type {
  BitmapShort,
  FindBitmapShortsOptions,
} from "@tscircuit/check-shorts"
import type { PlatformConfig } from "@tscircuit/props"
import { all_layers, layer_string } from "circuit-json"
import type { Command } from "commander"
import { getCircuitJsonForCheck, resolveCheckInputFilePath } from "../shared"
import {
  type CheckShortsLayerOption,
  getCheckShortLayers,
} from "./get-check-short-layers"

interface CheckShortsOptions {
  mode?: "pcb" | "gerber"
  layer?: CheckShortsLayerOption
  pixelsPerMm?: string
}

export interface CheckShortsResult {
  output: string
  shorts: BitmapShort[]
  artifacts?: Array<{
    content: Uint8Array | string
    contentType: "image/png" | "image/svg+xml"
    defaultOutputPath: string
  }>
}

type CheckShortsModule = typeof import("@tscircuit/check-shorts")

export const CHECK_SHORTS_CDN_URL =
  "https://jscdn.tscircuit.com/@tscircuit/check-shorts/latest/+esm"

const importCheckShortsFromCdn = async (
  url: string,
): Promise<CheckShortsModule> => await import(url)

const importCheckShortsFromPackage = async (): Promise<CheckShortsModule> =>
  await import("@tscircuit/check-shorts")

export const loadCheckShorts = async (
  options: {
    importFromCdn?: (url: string) => Promise<CheckShortsModule>
    preferCdn?: boolean
  } = {},
): Promise<CheckShortsModule> => {
  const importFromCdn = options.importFromCdn ?? importCheckShortsFromCdn
  const preferCdn =
    options.preferCdn ??
    (process.env.NODE_ENV !== "test" && process.env.TSCI_TEST_MODE !== "true")

  if (!preferCdn) return importCheckShortsFromPackage()

  try {
    return await importFromCdn(CHECK_SHORTS_CDN_URL)
  } catch (cdnError) {
    try {
      return await importCheckShortsFromPackage()
    } catch (packageError) {
      throw new AggregateError(
        [cdnError, packageError],
        "Failed to load @tscircuit/check-shorts from jscdn or the installed CLI package",
      )
    }
  }
}

const parsePixelsPerMm = (value?: string): number | undefined => {
  if (!value) return undefined
  const parsedValue = Number(value)
  if (!Number.isFinite(parsedValue) || parsedValue <= 0) {
    throw new Error("--pixels-per-mm must be a positive number")
  }
  return parsedValue
}

const parseMode = (mode?: string): "pcb" | "gerber" => {
  if (!mode) return "gerber"
  if (mode === "pcb" || mode === "gerber") return mode
  throw new Error("--mode must be either pcb or gerber")
}

const checkShortsLayerNames = [...all_layers, "all"].join(", ")

const parseLayer = (layer?: string): CheckShortsLayerOption => {
  if (!layer) return "all"
  if (layer === "all") return layer

  const parsedLayer = layer_string.safeParse(layer)
  if (parsedLayer.success) return parsedLayer.data

  throw new Error(`--layer must be one of: ${checkShortsLayerNames}`)
}

const formatLabels = (labels: string[]) =>
  labels.length > 0 ? labels.join(", ") : "(unknown)"

const formatShort = (short: BitmapShort, index: number) => {
  const center = `x=${short.center.x.toFixed(3)}mm y=${short.center.y.toFixed(3)}mm`
  return [
    `${index + 1}. ${short.layer}/${short.mode} short at ${center}`,
    `   ${formatLabels(short.firstOwnerLabels)} <-> ${formatLabels(short.secondOwnerLabels)}`,
    `   pixels=${short.pixelCount}`,
  ].join("\n")
}

const getShortArtifactOutputPath = () =>
  path.resolve(process.cwd(), "checks", "check-shorts", "bitmap.png")

const getShortPcbSnapshotOutputPath = () =>
  path.resolve(process.cwd(), "checks", "check-shorts", "pcb.svg")

export const checkShorts = async (
  file?: string,
  options: CheckShortsOptions = {},
): Promise<CheckShortsResult> => {
  const resolvedInputFilePath = await resolveCheckInputFilePath(file)
  const mode = parseMode(options.mode)
  const layerOption = parseLayer(options.layer)
  const pixelsPerMm = parsePixelsPerMm(options.pixelsPerMm)
  const circuitJson = await getCircuitJsonForCheck({
    filePath: resolvedInputFilePath,
    platformConfig: {
      pcbDisabled: false,
      routingDisabled: false,
    } satisfies PlatformConfig,
    allowPrebuiltCircuitJson: true,
  })
  const layers = getCheckShortLayers({ circuitJson, layerOption })
  const {
    appendBitmapLegend,
    createShortDebugSvg,
    encodeRgbaPng,
    renderBitmapShortDebug,
  } = await loadCheckShorts()

  const debugRenders = await Promise.all(
    layers.map((layer) =>
      renderBitmapShortDebug(circuitJson, {
        mode,
        layer,
        pixelsPerMm,
      } satisfies FindBitmapShortsOptions),
    ),
  )
  const shorts = debugRenders.flatMap((debugRender) => debugRender.shorts)
  const filename = path.basename(resolvedInputFilePath)

  if (shorts.length === 0) {
    return {
      output: `No shorts detected in ${filename}`,
      shorts,
    }
  }

  const debugRenderWithShorts =
    debugRenders.find((debugRender) => debugRender.shorts.length > 0) ??
    debugRenders[0]!
  const debugRenderWithLegend = appendBitmapLegend(debugRenderWithShorts)
  const artifacts = [
    {
      content: encodeRgbaPng(debugRenderWithLegend),
      contentType: "image/png" as const,
      defaultOutputPath: getShortArtifactOutputPath(),
    },
    {
      content: createShortDebugSvg(circuitJson, shorts),
      contentType: "image/svg+xml" as const,
      defaultOutputPath: getShortPcbSnapshotOutputPath(),
    },
  ]

  return {
    output: [
      `Detected ${shorts.length} short${shorts.length === 1 ? "" : "s"} in ${filename}`,
      ...shorts.map(formatShort),
    ].join("\n"),
    shorts,
    artifacts,
  }
}

export const registerCheckShorts = (program: Command) => {
  program.commands
    .find((c) => c.name() === "check")!
    .command("shorts")
    .description("Detect unintended shorts between separate PCB copper groups")
    .argument("[file]", "Path to the entry file or prebuilt circuit JSON")
    .option(
      "--mode <mode>",
      "Bitmap source to analyze: pcb or gerber",
      "gerber",
    )
    .option(
      "--layer <layer>",
      `Layer to analyze: ${checkShortsLayerNames}`,
      "all",
    )
    .option("--pixels-per-mm <number>", "Bitmap resolution for short detection")
    .action(async (file?: string, options?: CheckShortsOptions) => {
      try {
        const result = await checkShorts(file, options)
        console.log(result.output)
        if (result.artifacts) {
          for (const artifact of result.artifacts) {
            const outputPath = artifact.defaultOutputPath
            await mkdir(path.dirname(outputPath), { recursive: true })
            await writeFile(outputPath, artifact.content)
            console.log(`Short debug artifact written to ${outputPath}`)
          }
        }
        if (result.shorts.length > 0) {
          process.exit(1)
        }
      } catch (error) {
        console.error(error instanceof Error ? error.message : String(error))
        process.exit(1)
      }
    })
}
