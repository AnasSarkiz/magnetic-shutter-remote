import {
  addPcbXRayOptions,
  getPcbXRaySettings,
  type PcbXRayCliOptions,
} from "lib/shared/pcb-x-ray-options"
import type { Command } from "commander"
import type { VisibleLayerRef } from "circuit-json"
import { CAMERA_PRESET_NAMES, type CameraPreset } from "circuit-json-to-3d-png"
import { snapshotProject } from "lib/shared/snapshot-project"

export const registerSnapshot = (program: Command) => {
  addPcbXRayOptions(program.command("snapshot"))
    .argument(
      "[path]",
      "Path to file, directory, or glob pattern (e.g., 'examples/**/*.tsx')",
    )
    .description(
      "Generate schematic and PCB snapshots (add --3d for 3d preview)",
    )
    .option("-u, --update", "Update snapshots on disk")
    .option("--force-update", "Force update snapshots even if they match")
    .option("--3d", "Generate 3d preview snapshots")
    .option("--pcb-only", "Generate only PCB snapshots")
    .option("--schematic-only", "Generate only schematic snapshots")
    .option("--simulation-only", "Generate only simulation snapshots")
    .option(
      "--layer <layer>",
      "Generate a PCB snapshot for one layer: top or bottom (implies --pcb-only)",
    )
    .option("--disable-parts-engine", "Disable the parts engine")
    .option("--show-courtyards", "Show courtyard outlines in PCB snapshots")
    .option(
      "--camera-preset <preset>",
      `Camera angle preset for 3D snapshots (implies --3d). Valid presets: ${CAMERA_PRESET_NAMES.join(", ")}`,
    )
    .option("--ci", "Enable CI mode with snapshot diff artifacts")
    .option("--test", "Enable test mode with snapshot diff artifacts")
    .option(
      "--concurrency <number>",
      "Number of files to snapshot in parallel (default: 1)",
      "1",
    )
    .action(
      async (
        target: string | undefined,
        options: {
          update?: boolean
          "3d"?: boolean
          pcbOnly?: boolean
          schematicOnly?: boolean
          simulationOnly?: boolean
          forceUpdate?: boolean
          disablePartsEngine?: boolean
          showCourtyards?: boolean
          layer?: string
          cameraPreset?: string
          ci?: boolean
          test?: boolean
          concurrency?: string
        } & PcbXRayCliOptions,
      ) => {
        if (
          options.cameraPreset &&
          !CAMERA_PRESET_NAMES.includes(options.cameraPreset as CameraPreset)
        ) {
          console.error(
            `Unknown camera preset "${options.cameraPreset}". Valid presets: ${CAMERA_PRESET_NAMES.join(", ")}`,
          )
          process.exit(1)
        }

        let pcbLayer: VisibleLayerRef | undefined
        if (options.layer === "top" || options.layer === "bottom") {
          pcbLayer = options.layer
        } else if (options.layer) {
          console.error(
            `Unknown PCB layer "${options.layer}". Valid layers: top, bottom`,
          )
          process.exit(1)
        }

        if (pcbLayer && options.schematicOnly) {
          console.error(
            "A PCB layer snapshot cannot be combined with --schematic-only.",
          )
          process.exit(1)
        }

        if (
          options.simulationOnly &&
          (options.pcbOnly ||
            options.schematicOnly ||
            Boolean(pcbLayer) ||
            options["3d"] ||
            options.cameraPreset)
        ) {
          console.error(
            "--simulation-only cannot be combined with --pcb-only, --schematic-only, --layer, --3d, or --camera-preset.",
          )
          process.exit(1)
        }

        if (
          options.xRayNet?.length &&
          (options.schematicOnly ||
            options.simulationOnly ||
            options["3d"] ||
            options.cameraPreset)
        ) {
          console.error(
            "--x-ray-net cannot be combined with schematic, simulation, or 3D-only options.",
          )
          process.exit(1)
        }
        let pcbOnly = options.pcbOnly ?? Boolean(options.xRayNet?.length)
        if (pcbLayer) {
          pcbOnly = true
        }

        await snapshotProject({
          concurrency: Math.max(
            1,
            Number.parseInt(options.concurrency || "1", 10),
          ),
          update: options.update ?? false,
          threeD: options["3d"] ?? false,
          pcbOnly,
          schematicOnly: options.schematicOnly ?? false,
          simulationOnly: options.simulationOnly ?? false,
          pcbLayer,
          forceUpdate: options.forceUpdate ?? false,
          filePaths: target ? [target] : [],
          platformConfig: options.disablePartsEngine
            ? { partsEngineDisabled: true }
            : undefined,
          pcbSnapshotSettingsOverride: {
            ...(options.showCourtyards ? { showCourtyards: true } : {}),
            ...getPcbXRaySettings(options),
          },
          cameraPreset: options.cameraPreset as CameraPreset | undefined,
          createDiff: (options.ci ?? false) || (options.test ?? false),
          onExit: (code) => process.exit(code),
          onError: (msg) => console.error(msg),
          onSuccess: (msg) => console.log(msg),
        })
      },
    )
}
