import type { Command } from "commander"
import * as fs from "node:fs"
import * as path from "node:path"
import { setupTsciProject } from "lib/shared/setup-tsci-packages"
import { generateTsConfig } from "lib/shared/generate-ts-config"
import { writeFileIfNotExists } from "lib/shared/write-file-if-not-exists"
import { generateGitIgnoreFile } from "lib/shared/generate-gitignore-file"
import { generatePackageJson } from "lib/shared/generate-package-json"
import { setupTscircuitSkill } from "lib/shared/setup-tscircuit-skill"
import { cliConfig, getSessionToken } from "lib/cli-config"
import { jwtDecode } from "jwt-decode"
import { saveProjectConfig } from "lib/project-config"
import { checkForTsciUpdates } from "lib/shared/check-for-cli-update"
import { prompts } from "lib/utils/prompts"
import { fetchAccount } from "lib/registry-api/fetch-account"
import kleur from "kleur"
import { captureTelemetryEvent } from "lib/telemetry"

export const registerInit = (program: Command) => {
  program
    .command("init")
    .description(
      "Initialize a new TSCircuit project in the specified directory (or current directory if none is provided)",
    )
    .argument(
      "[directory]",
      "Directory name (optional, defaults to current directory)",
    )
    .option("-y, --yes", "Use defaults and skip prompts")
    .option("--no-install", "Skip installing dependencies")
    .action(
      async (
        directory?: string,
        options?: { yes?: boolean; install?: boolean },
      ) => {
        await checkForTsciUpdates()

        if (!directory && !options?.yes) {
          const { continueInCurrentDirectory } = await prompts({
            type: "confirm",
            name: "continueInCurrentDirectory",
            message:
              "Do you want to initialize a new project in the current directory?",
            initial: true,
          })
          if (!continueInCurrentDirectory) {
            const { desiredDirectory } = await prompts({
              type: "text",
              name: "desiredDirectory",
              message: "Enter the desired directory name",
            })
            if (desiredDirectory) {
              directory = desiredDirectory
            } else {
              console.log("Project initialization cancelled.")
              return process.exit(0)
            }
          }
        }

        const projectDir = directory
          ? path.resolve(process.cwd(), directory)
          : process.cwd()

        let tsciHandle: string | null = null
        const token = getSessionToken()
        if (token) {
          try {
            const decoded = jwtDecode<{ tscircuit_handle?: string }>(token)
            if (decoded.tscircuit_handle) {
              tsciHandle = decoded.tscircuit_handle
            }
          } catch {}
        }

        const dirName = path.basename(projectDir)

        let defaultPackageName = dirName
        if (tsciHandle) {
          defaultPackageName = `@tsci/${tsciHandle}.${dirName}`
        }

        const { packageName } = options?.yes
          ? { packageName: defaultPackageName }
          : await prompts({
              type: "text",
              name: "packageName",
              message: "Package name",
              initial: defaultPackageName,
            })

        let authorName = cliConfig.get("tscircuitHandle")
        if (!authorName) {
          const account = await fetchAccount()
          if (account?.tscircuit_handle) {
            authorName = account.tscircuit_handle
          }
        }

        // Ensure the directory exists
        fs.mkdirSync(projectDir, { recursive: true })

        // Create essential project files
        writeFileIfNotExists(
          path.join(projectDir, "index.circuit.tsx"),
          `
export default () => (
  <board>
    <resistor resistance="1k" footprint="0402" name="R1" />
    <capacitor capacitance="1000pF" footprint="0402" name="C1" />
    <trace from=".R1 > .pin1" to=".C1 > .pin1" />
  </board>
)
`,
        )

        if (saveProjectConfig(null, projectDir)) {
          console.log("Created tscircuit.config.json with schema")
        }

        writeFileIfNotExists(
          path.join(projectDir, ".npmrc"),
          `
@tsci:registry=https://npm.tscircuit.com
`,
        )

        console.log("Generating package.json")
        // Generate package.json
        generatePackageJson(projectDir, { packageName, authorName })
        // Generate tsconfig.json
        generateTsConfig(projectDir)
        // Create .gitignore file
        generateGitIgnoreFile(projectDir)
        // Setup tscircuit claude skill
        await setupTscircuitSkill(projectDir, options?.yes)
        // Setup project dependencies
        await setupTsciProject(projectDir, options?.install ? undefined : [])

        await captureTelemetryEvent("tsci_init", {
          command: "init",
          directory_provided: directory !== undefined,
          yes: Boolean(options?.yes),
          no_install: options?.install === false,
          status: "success",
        })

        console.info(
          "\n",
          kleur.green("🎉 Initialization complete!"),
          "Run ",
          kleur.bold(
            kleur.blue(
              `${
                directory ? `${kleur.bold(`cd ${directory}`)} && ` : ""
              }${kleur.bold("tsci dev")}`,
            ),
          ),
          " to start developing.",
        )
        process.exit(0)
      },
    )
}
