#!/usr/bin/env node
import { Command } from "commander"
import { registerStaticAssetLoaders } from "lib/shared/register-static-asset-loaders"
import { perfectCli } from "perfect-cli"
import { getVersion } from "./../lib/getVersion"
import { registerAdd } from "./add/register"
import { registerAgent } from "./agent/register"
import { registerAuthLogin } from "./auth/login/register"
import { registerAuthLogout } from "./auth/logout/register"
import { registerAuthPrintToken } from "./auth/print-token/register"
import { registerAuth } from "./auth/register"
import { registerAuthSetToken } from "./auth/set-token/register"
import { registerAuthSetupNpmrc } from "./auth/setup-npmrc/register"
import { registerAuthWhoami } from "./auth/whoami/register"
import { registerBuild } from "./build/register"
import { registerCheckNetlist } from "./check/netlist/register"
import { registerCheckPinSpecification } from "./check/pin-specification/register"
import { registerCheckPlacement } from "./check/placement/register"
import { registerCheck } from "./check/register"
import { registerCheckRoutingDifficulty } from "./check/routing-difficulty/register"
import { registerCheckSchematicPlacement } from "./check/schematic-placement/register"
import { registerCheckShorts } from "./check/shorts/register"
import { registerCheckSource } from "./check/source/register"
import { registerCheckTraceLength } from "./check/trace-length/register"
import { registerClone } from "./clone/register"
import { registerConfigPrint } from "./config/print/register"
import { registerConfig } from "./config/register"
import { registerConfigSet } from "./config/set/register"
import { registerConvert } from "./convert/register"
import { registerDev } from "./dev/register"
import { registerDoctor } from "./doctor/register"
import { registerExport } from "./export/register"
import { registerImport } from "./import/register"
import { registerInit } from "./init/register"
import { registerInstall } from "./install/register"
import { registerPush } from "./push/register"
import { registerReportAutorouter } from "./report/autorouter/register"
import { registerReport } from "./report/register"
import { registerRemove } from "./remove/register"
import { registerRegistryPackagesCreate } from "./registry/packages/create/register"
import { registerRegistryPackagesUpdate } from "./registry/packages/update/register"
import { registerRegistryPackages } from "./registry/packages/register"
import { registerRegistry } from "./registry/register"
import { registerSearch } from "./search/register"
import { registerSetup } from "./setup/register"
import { registerSimulate } from "./simulate/register"
import { registerSnapshot } from "./snapshot/register"
import { registerTranspile } from "./transpile/register"
import { registerUpgradeCommand } from "./upgrade/register"
import { registerUpdate } from "./update/register"

export const program = new Command()

program.name("tsci").description("CLI for developing tscircuit packages")

registerStaticAssetLoaders()

registerInit(program)

registerDev(program)
registerClone(program)
registerPush(program)

registerAuth(program)
registerAuthLogin(program)
registerAuthLogout(program)
registerAuthPrintToken(program)
registerAuthSetToken(program)
registerAuthWhoami(program)
registerAuthSetupNpmrc(program)

registerConfig(program)
registerConfigPrint(program)
registerConfigSet(program)

registerExport(program)
registerBuild(program)
registerTranspile(program)
registerAdd(program)
registerAgent(program)
registerRemove(program)
registerSnapshot(program)
registerSetup(program)
registerInstall(program)
registerUpdate(program)
registerUpgradeCommand(program)
registerDoctor(program)
registerReport(program)
registerReportAutorouter(program)
registerCheck(program)
registerCheckNetlist(program)
registerCheckPinSpecification(program)
registerCheckPlacement(program)
registerCheckRoutingDifficulty(program)
registerCheckSchematicPlacement(program)
registerCheckShorts(program)
registerCheckSource(program)
registerCheckTraceLength(program)

registerRegistry(program)
registerRegistryPackages(program)
registerRegistryPackagesCreate(program)
registerRegistryPackagesUpdate(program)

registerSearch(program)
registerImport(program)
registerConvert(program)
registerSimulate(program)

// Manually handle top-level --version, -v, and -V flags.
// Do not intercept subcommand arguments, e.g. `tsci agent --version` should
// forward `--version` to tsci-agent.
const cliArgs = process.argv.slice(2)
const firstCommandIndex = cliArgs.findIndex((arg) => !arg.startsWith("-"))
const topLevelArgs =
  firstCommandIndex === -1 ? cliArgs : cliArgs.slice(0, firstCommandIndex)
if (
  topLevelArgs.includes("--version") ||
  topLevelArgs.includes("-v") ||
  topLevelArgs.includes("-V")
) {
  console.log(getVersion({ verbose: topLevelArgs.includes("--verbose") }))
  process.exit(0)
}

// Add a custom version command
program
  .command("version")
  .description("Print CLI version")
  .option("--verbose", "Print tscircuit + CLI dependency versions")
  .action((options: { verbose?: boolean }) => {
    console.log(getVersion({ verbose: options.verbose }))
  })

if (process.argv.length === 2) {
  // perfectCli uses commander@12 internally which is not strictly
  // compatible with commander@14's TypeScript types. Cast to any to
  // avoid a type mismatch.
  perfectCli(program as any, process.argv).catch((err) => {
    // Handle cancelled interactive sessions gracefully
    if (err instanceof Error && err.name === "TypeError") {
      console.error("\nAborted.")
      process.exit(130)
    }
    throw err
  })
} else {
  program.parse()
}
