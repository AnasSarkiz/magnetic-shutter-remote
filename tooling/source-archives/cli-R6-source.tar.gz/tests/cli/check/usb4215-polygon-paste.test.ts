import { expect, test } from "bun:test"
import { appendCopperBridgeTrace } from "@tscircuit/check-shorts"
import { any_circuit_element } from "circuit-json"
import { writeFile } from "node:fs/promises"
import { join } from "node:path"
import { temporaryDirectory } from "tempy"
import { checkShorts } from "../../../cli/check/shorts/register"
import fixture from "./usb4215-polygon-paste.circuit.json"
const circuit = any_circuit_element.array().parse(fixture)
test("real USB4215 polygon paste keeps the complete Gerber shorts check operable", async () => {
  expect(circuit.filter(e => e.type === "pcb_solder_paste" && e.shape === "polygon")).toHaveLength(16)
  const result = await checkShorts(join(import.meta.dirname, "usb4215-polygon-paste.circuit.json"))
  expect(result.shorts).toHaveLength(0)
}, 30000)
test("polygon paste does not hide an injected VBUS to CC1 short", async () => {
  const component = circuit.find(e => e.type === "source_component" && e.name === "J1")
  if (!component || component.type !== "source_component") throw new Error("J1 source missing")
  const placed = circuit.find(e => e.type === "pcb_component" && e.source_component_id === component.source_component_id)
  if (!placed || placed.type !== "pcb_component") throw new Error("J1 placement missing")
  const pads = circuit.filter(e => e.type === "pcb_smtpad" && e.pcb_component_id === placed.pcb_component_id)
  const vbus = pads.find(e => e.port_hints?.includes("pin18"))
  const cc1 = pads.find(e => e.port_hints?.includes("pin20"))
  if (!vbus || !cc1) throw new Error("VBUS/CC1 missing")
  const bridged = appendCopperBridgeTrace(circuit, {start:{x:vbus.x,y:vbus.y},end:{x:cc1.x,y:cc1.y},width:0.3,layer:"top"})
  const input = join(temporaryDirectory(),"bridge.circuit.json")
  await writeFile(input,JSON.stringify(bridged))
  const result = await checkShorts(input)
  expect(result.shorts.length).toBeGreaterThan(0)
}, 30000)
