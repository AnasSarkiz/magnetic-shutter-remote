import type { ManualEditEvent, PlatformConfig } from "@tscircuit/props"
import type { TabId } from "lib/components/CircuitJsonPreview/PreviewContentProps"
import type { RunCompletedPayload } from "./run-completion"

export interface RunFrameProps {
  /**
   * Map of filenames to file contents that will be available in the worker
   */
  fsMap: Map<string, string> | Record<string, string>

  /**
   * When true, indicates the file map is still loading and a loading state
   * should be displayed instead of attempting to execute any code.
   */
  isLoadingFiles?: boolean

  /**
   * The entry point file that will be executed first. If not provided,
   * @tscircuit/eval will infer the entrypoint
   */
  entrypoint?: string

  /**
   * The path to the main component that should be rendered. If not provided,
   * the default component from the entry point will be used.
   */
  mainComponentPath?: string

  /**
   * Whether to show a run button that controls when code executes
   */
  showRunButton?: boolean

  /**
   * Whether to show a full screen button
   */
  showToggleFullScreen?: boolean

  /**
   * Whether to expand the preview to fill the available space by default
   */
  defaultToFullScreen?: boolean

  /**
   * An optional left-side header, you can put a save button, a run button, or
   * a title here.
   */
  leftHeaderContent?: React.ReactNode

  /**
   * Whether the run frame is embedded in a web page
   */
  isWebEmbedded?: boolean

  /**
   * Whether the run frame is running in the tscircuit CLI surface.
   */
  isCli?: boolean

  /**
   * Whether to show the file menu
   */
  showFileMenu?: boolean

  /**
   * Called when the circuit JSON changes
   */
  onCircuitJsonChange?: (circuitJson: any) => void

  /**
   * Called when rendering is finished
   */
  onRenderFinished?: (params: { circuitJson: any }) => void

  /**
   * Called when code execution and rendering have completed (even if errors occurred)
   */
  onRunCompleted?: (payload: RunCompletedPayload) => void

  /**
   * Called when the initial render is finished (fast)
   */
  onInitialRender?: (params: { circuitJson: any }) => void

  /**
   * Called when rendering is started
   */
  onRenderStarted?: () => void

  /**
   * Called for each render event
   */
  onRenderEvent?: (event: any) => void

  /**
   * Called when an error occurs
   */
  onError?: (error: Error) => void

  /**
   * Called when an edit event occurs
   */
  onEditEvent?: (editEvent: ManualEditEvent) => void

  /**
   * Any edit events that have occurred and should be applied
   */
  editEvents?: ManualEditEvent[]

  onPcbBoundsSelected?: (bounds: {
    minX: number
    minY: number
    maxX: number
    maxY: number
  }) => void

  /**
   * If true, turns on debug logging
   */
  debug?: boolean

  defaultActiveTab?: TabId

  /**
   * Alias for defaultActiveTab
   */
  defaultTab?: TabId

  /**
   * Tabs to display. Defaults to all
   */
  availableTabs?: TabId[]

  schematicSvgOptions?: {
    css?: string
    className?: string
  }

  evalWebWorkerBlobUrl?: string

  evalVersion?: string
  forceLatestEvalVersion?: boolean

  shouldLoadLatestEval?: boolean
  onChangeShouldLoadLatestEval?: (shouldLoadLatestEval: boolean) => void

  /**
   * Optional project URL whose pathname will be used when
   * reporting autorouting bugs
   */
  projectUrl?: string

  /**
   * Base URL for the project, used in webworker platform config
   */
  projectBaseUrl?: string

  /**
   * Platform config for the eval webworker
   */
  platformConfig?: PlatformConfig

  onReportAutoroutingLog?: (
    name: string,
    data: { simpleRouteJson: any },
  ) => void

  /**
   * Enable fetch proxy for the web worker (useful for standalone bundles)
   */
  enableFetchProxy?: boolean

  /**
   * Called when an action requires authentication (e.g. reporting autorouting bugs)
   */
  onLoginRequired?: () => void

  /**
   * The session token to used for the tscircuit registry
   */
  tscircuitSessionToken?: string

  /**
   * Configuration for proxying EasyEDA API requests, used by the parts engine
   * when fetching part circuit JSON (e.g. for connector footprints).
   */
  easyEdaProxyConfig?: {
    proxyEndpointUrl: string
    headers?: Record<string, string>
  }
}
