import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "lib/components/ui/tabs"
import { cn } from "lib/utils"
import { hasSimulationAnalysisResult } from "lib/utils/has-simulation-analysis-result"
import { CadViewer } from "@tscircuit/3d-viewer"
import {
  useCallback,
  useEffect,
  useState,
  useMemo,
  type ComponentProps,
} from "react"
import { ErrorFallback } from "../ErrorFallback"
import { ErrorBoundary, type FallbackProps } from "react-error-boundary"
import { ErrorTabContent } from "../ErrorTabContent/ErrorTabContent"
import {
  SchematicViewer,
  useSchematicViewerController,
} from "@tscircuit/schematic-viewer"
import { AssemblyViewer, PinoutViewer } from "@tscircuit/assembly-viewer"
import PreviewEmptyState from "../PreviewEmptyState"
import { CircuitJsonTableViewer } from "../CircuitJsonTableViewer/CircuitJsonTableViewer"
import { BomTable } from "../BomTable"
import { AnalogSimulationViewer } from "@tscircuit/schematic-viewer"
import {
  CheckIcon,
  EllipsisIcon,
  FullscreenIcon,
  Loader2,
  LoaderCircleIcon,
  MinimizeIcon,
  Circle,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuPortal,
  DropdownMenuSeparator,
} from "../ui/dropdown-menu"
import { Button } from "../ui/button"
import { Input } from "../ui/input"
import { PcbViewerWithContainerHeight } from "../PcbViewerWithContainerHeight"
import { useStyles } from "lib/hooks/use-styles"
import { useFullscreenBodyScroll } from "lib/hooks/use-fullscreen-body-scroll"
import { useLocalStorageState } from "lib/hooks/use-local-storage-state"
import { RenderLogViewer } from "../RenderLogViewer/RenderLogViewer"
import { SolversTabContent } from "../SolversTabContent/SolversTabContent"
import { AutoroutingTabContent } from "../AutoroutingTabContent/AutoroutingTabContent"
import { capitalizeFirstLetters } from "lib/utils"
import { useErrorTelemetry } from "lib/hooks/use-error-telemetry"
import { usePostHogActivity } from "lib/hooks/use-posthog-activity"
import type {
  PreviewContentProps,
  TabId,
  SolverStartedEvent,
} from "./PreviewContentProps"
import type { CircuitJsonError } from "circuit-json"
import { version } from "../../../package.json"
import type { Object3D } from "three"
import { useEvalVersions } from "lib/hooks/use-eval-versions"
import { FileMenuLeftHeader } from "../FileMenuLeftHeader"
import {
  CrispFeedbackButton,
  shouldShowCrispFeedbackButton,
} from "./CrispFeedbackButton"

declare global {
  interface Window {
    TSCIRCUIT_3D_OBJECT_REF: Object3D | undefined
  }
}

const dropdownMenuItems = [
  "assembly",
  "pinout",
  "analog_simulation",
  "bom",
  "circuit_json",
  "errors",
  "render_log",
  "autorouting",
  "solvers",
]

export type { PreviewContentProps, TabId, SolverStartedEvent }
export type { AutoroutingPhase, AutoroutingPhaseEvent } from "lib/autorouting"

const getErrorMessage = (error: unknown) =>
  error instanceof Error ? error.message : "An unknown error occurred"

export const CircuitJsonPreview = ({
  code,
  fsMap,
  onRunClicked = undefined,
  errorMessage,
  errorStack,
  circuitJson,
  autoroutingGraphics,
  showRightHeaderContent = true,
  showCodeTab = false,
  codeTabContent,
  showJsonTab = true,
  showRenderLogTab = true,
  onActiveTabChange,
  renderLog,
  showImportAndFormatButtons = true,
  className,
  headerClassName,
  leftHeaderContent,
  readOnly,
  isStreaming,
  autoroutingLog,
  onReportAutoroutingLog,
  isRunningCode,
  hasCodeChangedSinceLastRun,
  onEditEvent,
  editEvents,
  defaultActiveTab,
  defaultTab,
  availableTabs,
  autoRotate3dViewerDisabled,
  showSchematicDebugGrid: showSchematicDebugGridProp = false,
  showSchematicPorts: showSchematicPortsProp = false,
  onChangeShowSchematicDebugGrid,
  onChangeShowSchematicPorts,
  showToggleFullScreen = true,
  defaultToFullScreen = false,
  activeEffectName,
  allowSelectingVersion = true,
  showFileMenu = false,
  isWebEmbedded = false,
  isCli = false,
  projectName,
  schematicSvgOptions,
  hideSchematicInAnalogSimulation = false,
  onRerunWithDebug,
  solverEvents,
  autoroutingPhases,
  onPcbBoundsSelected,
}: PreviewContentProps) => {
  useStyles()

  const {
    versions: evalVersions,
    latestVersion,
    lastRunEvalVersion,
    search: evalSearch,
    setSearch: setEvalSearch,
    selectVersion: selectEvalVersion,
  } = useEvalVersions(allowSelectingVersion)

  const circuitJsonErrors = useMemo<CircuitJsonError[] | null>(() => {
    if (!circuitJson) return null
    return circuitJson.filter(
      (e) => (e && "error_type" in e) || e.type.includes("error"),
    ) as any
  }, [circuitJson])

  const circuitJsonWarnings = useMemo<CircuitJsonError[] | null>(() => {
    if (!circuitJson) return null
    return circuitJson.filter(
      (e) => (e && "warning_type" in e) || e.type.includes("warning"),
    ) as any
  }, [circuitJson])

  const hasSchematicGroup = useMemo(() => {
    if (!circuitJson) return true
    return circuitJson.some((e) => e.type === "schematic_group")
  }, [circuitJson])

  const hasPanels = useMemo(() => {
    return circuitJson?.some((e) => e.type === "pcb_panel")
  }, [circuitJson])

  const schematicNavigationEnabled =
    (!availableTabs || availableTabs.includes("schematic")) &&
    hasSchematicGroup &&
    !hasPanels
  const { controller: schematicController, focusSchematicComponent } =
    useSchematicViewerController()

  const handleViewSchematicComponent = schematicNavigationEnabled
    ? ({ source_component_id }: { source_component_id: string }) => {
        const component = circuitJson?.find(
          (element) =>
            element.type === "schematic_component" &&
            element.source_component_id === source_component_id,
        )
        if (component?.type !== "schematic_component") return
        focusSchematicComponent(component.schematic_component_id)
        setActiveTab("schematic")
      }
    : undefined

  const isAnalogSimulationGraphPending = useMemo(() => {
    if (!circuitJson || !isRunningCode) return false
    if (circuitJsonErrors?.length) return false

    const hasSimulationExperiment = circuitJson.some(
      (e) => e.type === "simulation_experiment",
    )
    return hasSimulationExperiment && !hasSimulationAnalysisResult(circuitJson)
  }, [circuitJson, circuitJsonErrors, isRunningCode])

  const analogSimulationError = useMemo(() => {
    return circuitJsonErrors?.find((e) => e.type.startsWith("simulation_"))
  }, [circuitJsonErrors])

  useErrorTelemetry({
    errorMessage,
    errorStack,
    circuitJsonErrors,
  })

  const fallbackTab = defaultTab ?? availableTabs?.[0] ?? "pcb"
  const [activeTab, setActiveTabState] = useLocalStorageState<TabId>(
    "runframe-active-tab",
    defaultActiveTab ?? fallbackTab,
    defaultActiveTab,
  )
  usePostHogActivity({
    source: "runframe",
    component: "CircuitJsonPreview",
    isWebEmbedded,
    activeTab,
  })
  const [lastActiveTab, setLastActiveTab] = useState<TabId | null>(null)
  const [isFullScreen, setIsFullScreen] = useState(defaultToFullScreen)

  // Internal state for when CircuitJsonPreview is used standalone (without external state management)
  const [internalShowSchematicDebugGrid, setInternalShowSchematicDebugGrid] =
    useState(showSchematicDebugGridProp)
  const [internalShowSchematicPorts, setInternalShowSchematicPorts] = useState(
    showSchematicPortsProp,
  )

  // Use external state if handlers are provided, otherwise use internal state
  const showSchematicDebugGrid = onChangeShowSchematicDebugGrid
    ? showSchematicDebugGridProp
    : internalShowSchematicDebugGrid
  const showSchematicPorts = onChangeShowSchematicPorts
    ? showSchematicPortsProp
    : internalShowSchematicPorts
  const setShowSchematicDebugGrid =
    onChangeShowSchematicDebugGrid ?? setInternalShowSchematicDebugGrid
  const setShowSchematicPorts =
    onChangeShowSchematicPorts ?? setInternalShowSchematicPorts
  useFullscreenBodyScroll(isFullScreen)
  const setActiveTab = useCallback(
    (tab: TabId) => {
      setActiveTabState(tab)
      onActiveTabChange?.(tab)
    },
    [onActiveTabChange, setActiveTabState],
  )

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen)
  }

  useEffect(() => {
    if (errorMessage) {
      if (activeTab !== "errors") {
        setLastActiveTab(activeTab)
      }
      setActiveTab("errors")
    }
  }, [errorMessage])

  useEffect(() => {
    if (
      (activeTab === "code" || activeTab === "errors") &&
      circuitJson &&
      !errorMessage
    ) {
      setActiveTab(
        lastActiveTab ??
          defaultActiveTab ??
          defaultTab ??
          availableTabs?.[0] ??
          "pcb",
      )
    }
  }, [circuitJson])

  const setCadViewerRef = useCallback((value: Object3D | null) => {
    window.TSCIRCUIT_3D_OBJECT_REF = value === null ? undefined : value
  }, [])

  return (
    <div
      className={cn(
        "flex flex-col relative rf-overflow-x-hidden rf-h-full",
        className,
      )}
    >
      <div
        className={cn(
          "rf-md:sticky rf-md:top-2 rf-h-full",
          isFullScreen &&
            "rf-fixed rf-top-0 rf-left-0 rf-w-full rf-h-full rf-bg-white rf-overflow-hidden",
        )}
      >
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab as any}
          className="rf-flex-grow rf-flex rf-flex-col rf-h-full"
        >
          <div
            className={cn(
              "rf-flex rf-items-center rf-gap-2 rf-p-2 rf-pb-0",
              headerClassName,
            )}
          >
            {leftHeaderContent}
            {showFileMenu && !leftHeaderContent && (
              <FileMenuLeftHeader
                isWebEmbedded={isWebEmbedded}
                circuitJson={circuitJson}
                projectName={projectName}
                autoroutingLog={autoroutingLog}
                onReportAutoroutingLog={onReportAutoroutingLog}
                showSchematicDebugGrid={showSchematicDebugGrid}
                onChangeShowSchematicDebugGrid={setShowSchematicDebugGrid}
                showSchematicPorts={showSchematicPorts}
                onChangeShowSchematicPorts={setShowSchematicPorts}
              />
            )}
            {(leftHeaderContent || showFileMenu) && (
              <div className="rf-flex-grow" />
            )}
            {!leftHeaderContent && !showFileMenu && isRunningCode && (
              <Loader2 className="rf-w-4 rf-h-4 rf-animate-spin" />
            )}
            {!leftHeaderContent && !showFileMenu && (
              <div className="rf-flex-grow" />
            )}
            {renderLog && renderLog.progress !== 1 && !errorMessage && (
              <div className="rf-flex rf-items-center rf-gap-2 rf-min-w-0 rf-max-w-xs">
                {activeEffectName ? (
                  <div
                    className="rf-text-xs rf-text-gray-500 rf-truncate rf-min-w-0"
                    title={activeEffectName}
                  >
                    {activeEffectName}
                  </div>
                ) : (
                  renderLog.lastRenderEvent && (
                    <div
                      className="rf-text-xs rf-text-gray-500 rf-truncate rf-min-w-0"
                      title={renderLog.lastRenderEvent?.phase ?? ""}
                    >
                      {renderLog.lastRenderEvent?.phase ?? ""}
                    </div>
                  )
                )}
                <div className="rf-w-4 rf-h-4 rf-bg-blue-500 rf-opacity-50 rf-rounded-full rf-text-white rf-flex-shrink-0">
                  <LoaderCircleIcon className="rf-w-4 rf-h-4 rf-animate-spin" />
                </div>
                <div className="rf-text-xs rf-font-bold rf-text-gray-700 rf-tabular-nums rf-flex-shrink-0">
                  {((renderLog.progress ?? 0) * 100).toFixed(1)}%
                </div>
              </div>
            )}
            {showRightHeaderContent &&
              shouldShowCrispFeedbackButton({ isCli }) && (
                <CrispFeedbackButton />
              )}
            {showRightHeaderContent && (
              <TabsList>
                {showCodeTab && <TabsTrigger value="code">Code</TabsTrigger>}
                {!availableTabs || availableTabs.includes("pcb") ? (
                  <TabsTrigger value="pcb" className="rf-whitespace-nowrap">
                    {circuitJson && (
                      <span
                        className={cn(
                          "rf-inline-flex rf-items-center rf-justify-center rf-w-2 rf-h-2 rf-mr-1 rf-text-xs rf-font-bold rf-text-white rf-rounded-full",
                          !hasCodeChangedSinceLastRun
                            ? "rf-bg-blue-500"
                            : "rf-bg-gray-500",
                        )}
                      />
                    )}
                    PCB
                  </TabsTrigger>
                ) : null}
                {!availableTabs || availableTabs.includes("schematic") ? (
                  <TabsTrigger
                    value="schematic"
                    className={cn(
                      "rf-whitespace-nowrap",
                      circuitJson && !hasSchematicGroup && "rf-opacity-50",
                    )}
                    disabled={
                      circuitJson ? !hasSchematicGroup || hasPanels : false
                    }
                  >
                    {circuitJson && (
                      <span
                        className={cn(
                          "rf-inline-flex rf-items-center rf-justify-center rf-w-2 rf-h-2 rf-mr-1 rf-text-xs rf-font-bold rf-text-white rf-rounded-full",
                          !hasCodeChangedSinceLastRun
                            ? "rf-bg-blue-500"
                            : "rf-bg-gray-500",
                        )}
                      />
                    )}
                    Schematic
                  </TabsTrigger>
                ) : null}
                {!availableTabs || availableTabs.includes("cad") ? (
                  <TabsTrigger value="cad">
                    {circuitJson && (
                      <span
                        className={cn(
                          "inline-flex items-center justify-center w-2 h-2 mr-1 text-xs font-bold text-white rounded-full",
                          !hasCodeChangedSinceLastRun
                            ? "rf-bg-blue-500"
                            : "rf-bg-gray-500",
                        )}
                      />
                    )}
                    3D
                  </TabsTrigger>
                ) : null}
                {!["pcb", "cad", "schematic"].includes(activeTab) && (
                  <TabsTrigger value={activeTab}>
                    {capitalizeFirstLetters(activeTab)}
                  </TabsTrigger>
                )}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      type="button"
                      aria-label="More views"
                      className="rf-whitespace-nowrap rf-p-2 rf-mr-1 rf-cursor-pointer rf-relative"
                    >
                      <EllipsisIcon className="rf-w-4 rf-h-4" />
                      {((circuitJsonErrors && circuitJsonErrors.length > 0) ||
                        errorMessage) && (
                        <span className="rf-inline-flex rf-absolute rf-top-[6px] rf-right-[4px] rf-items-center rf-justify-center rf-w-1 rf-h-1 rf-ml-2 rf-text-[8px] rf-font-bold rf-text-white rf-bg-red-500 rf-rounded-full" />
                      )}
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="rf-*:text-xs rf-z-[101]">
                    {dropdownMenuItems
                      .filter(
                        (item) =>
                          !availableTabs ||
                          availableTabs.includes(item as TabId),
                      )
                      .map((item) => (
                        <DropdownMenuItem
                          key={item}
                          onSelect={() => setActiveTab(item as TabId)}
                        >
                          {activeTab !== item && (
                            <Circle className="rf-w-3 rf-h-3 rf-opacity-30" />
                          )}
                          {activeTab === item && (
                            <CheckIcon className="rf-w-3 rf-h-3" />
                          )}
                          <div className="rf-pr-2">
                            {capitalizeFirstLetters(item)}
                          </div>
                          {item === "errors" &&
                            ((circuitJsonErrors &&
                              circuitJsonErrors.length > 0) ||
                              errorMessage) && (
                              <span className="rf-inline-flex rf-items-center rf-justify-center rf-w-3 rf-h-3 rf-ml-2 rf-text-[8px] rf-font-bold rf-text-white rf-bg-red-500 rf-rounded-full">
                                {errorMessage ? 1 : circuitJsonErrors?.length}
                              </span>
                            )}
                          {item === "solvers" &&
                            solverEvents &&
                            solverEvents.length > 0 && (
                              <span className="rf-inline-flex rf-items-center rf-justify-center rf-min-w-[12px] rf-h-3 rf-px-1 rf-ml-2 rf-text-[8px] rf-font-bold rf-text-white rf-bg-blue-500 rf-rounded-full">
                                {solverEvents.length}
                              </span>
                            )}
                        </DropdownMenuItem>
                      ))}
                    <DropdownMenuItem
                      disabled
                      className="rf-opacity-60 rf-cursor-default rf-select-none"
                    >
                      <div className="rf-pr-2 rf-text-xs rf-text-gray-500">
                        @tscircuit/runframe@
                        {version
                          .split(".")
                          .map((part, i) =>
                            i === 2 ? parseInt(part) + 1 : part,
                          )
                          .join(".")}
                      </div>
                    </DropdownMenuItem>
                    {allowSelectingVersion ? (
                      <DropdownMenuSub
                        onOpenChange={(open) => !open && setEvalSearch("")}
                      >
                        <DropdownMenuSubTrigger className="rf-text-xs rf-opacity-60">
                          <div className="rf-pr-2 rf-text-xs rf-text-gray-500">
                            @tscircuit/eval@
                            {lastRunEvalVersion ?? latestVersion ?? "latest"}
                          </div>
                        </DropdownMenuSubTrigger>
                        <DropdownMenuPortal>
                          <DropdownMenuSubContent className="rf-*:text-xs rf-w-40 rf-max-h-[200px] rf-overflow-y-auto">
                            <div className="rf-p-1">
                              <Input
                                value={evalSearch}
                                onChange={(e) => setEvalSearch(e.target.value)}
                                placeholder="Search..."
                                className="rf-h-7 rf-text-xs"
                              />
                            </div>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onSelect={() => selectEvalVersion(null)}
                            >
                              {latestVersion
                                ? `${latestVersion} (latest)`
                                : "latest"}
                            </DropdownMenuItem>
                            {evalVersions.map((v) => (
                              <DropdownMenuItem
                                key={v}
                                onSelect={() => selectEvalVersion(v)}
                              >
                                {v}
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuSubContent>
                        </DropdownMenuPortal>
                      </DropdownMenuSub>
                    ) : (
                      lastRunEvalVersion && (
                        <DropdownMenuItem
                          disabled
                          className="rf-opacity-60 rf-cursor-default rf-select-none"
                        >
                          <div className="rf-pr-2 rf-text-xs rf-text-gray-500">
                            @tscircuit/eval@{lastRunEvalVersion}
                          </div>
                        </DropdownMenuItem>
                      )
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </TabsList>
            )}
            {showToggleFullScreen && (
              <Button onClick={toggleFullScreen} variant="ghost">
                {isFullScreen ? (
                  <MinimizeIcon size={16} />
                ) : (
                  <FullscreenIcon size={16} />
                )}
              </Button>
            )}
          </div>
          {showCodeTab && (
            <TabsContent
              value="code"
              className="rf-flex-grow rf-overflow-hidden"
            >
              <div className="rf-h-full">{codeTabContent}</div>
            </TabsContent>
          )}
          {(!availableTabs || availableTabs.includes("pcb")) && (
            <TabsContent value="pcb">
              <div
                className={cn(
                  "rf-overflow-hidden",
                  isFullScreen ? "rf-h-[calc(100vh-52px)]" : "rf-h-full",
                )}
              >
                <ErrorBoundary
                  fallbackRender={({ error }: FallbackProps) => (
                    <div className="rf-mt-4 rf-bg-red-50 rf-rounded-md rf-border rf-border-red-200">
                      <div className="rf-p-4">
                        <h3 className="rf-text-lg rf-font-semibold rf-text-red-800 rf-mb-3">
                          Error loading PCB viewer
                        </h3>
                        <p className="rf-text-xs rf-font-mono rf-whitespace-pre-wrap rf-text-red-600 rf-mt-2">
                          {getErrorMessage(error)}
                        </p>
                      </div>
                    </div>
                  )}
                >
                  {circuitJson ? (
                    <PcbViewerWithContainerHeight
                      focusOnHover={false}
                      circuitJson={circuitJson}
                      debugGraphics={autoroutingGraphics}
                      onBoundsSelected={onPcbBoundsSelected}
                      onViewSchematicComponent={handleViewSchematicComponent}
                      containerClassName={cn(
                        "rf-h-full rf-w-full",
                        isFullScreen
                          ? "rf-min-h-[calc(100vh-240px)]"
                          : "rf-min-h-[620px]",
                      )}
                      onEditEventsChanged={(editEvents) => {
                        if (onEditEvent) {
                          for (const e of editEvents) {
                            onEditEvent(e)
                          }
                        }
                      }}
                      // onEditEventsChanged={(editEvents) => {
                      //   if (editEvents.some((editEvent) => editEvent.in_progress))
                      //     return
                      //   // Update state with new edit events
                      //   const newManualEditsFileContent = applyPcbEditEvents({
                      //     editEvents,
                      //     circuitJson,
                      //     manualEditsFileContent,
                      //   })
                      //   onManualEditsFileContentChange?.(
                      //     JSON.stringify(newManualEditsFileContent, null, 2),
                      //   )
                      // }}
                    />
                  ) : (
                    <PreviewEmptyState onRunClicked={onRunClicked} />
                  )}
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}

          {(!availableTabs || availableTabs.includes("assembly")) && (
            <TabsContent value="assembly">
              <div
                className={cn(
                  "rf-overflow-auto",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full  rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary fallback={<div>Error loading Assembly</div>}>
                  {circuitJson ? (
                    <AssemblyViewer
                      circuitJson={circuitJson}
                      containerStyle={{
                        height: "100%",
                      }}
                      editingEnabled
                      debugGrid
                    />
                  ) : (
                    <PreviewEmptyState onRunClicked={onRunClicked} />
                  )}
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}
          {(!availableTabs || availableTabs.includes("pinout")) && (
            <TabsContent value="pinout">
              <div
                className={cn(
                  "rf-overflow-auto",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full  rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary
                  fallback={<div>Error loading Pinout Viewer</div>}
                >
                  {circuitJson ? (
                    <PinoutViewer
                      circuitJson={circuitJson}
                      containerStyle={{
                        height: "100%",
                      }}
                    />
                  ) : (
                    <PreviewEmptyState onRunClicked={onRunClicked} />
                  )}
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}
          {(!availableTabs || availableTabs.includes("schematic")) && (
            <TabsContent value="schematic">
              <div
                className={cn(
                  "rf-overflow-auto rf-bg-white",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full  rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary
                  fallbackRender={({ error }: FallbackProps) => (
                    <div className="rf-mt-4 rf-bg-red-50 rf-rounded-md rf-border rf-border-red-200">
                      <div className="rf-p-4">
                        <h3 className="rf-text-lg rf-font-semibold rf-text-red-800 rf-mb-3">
                          Error loading Schematic
                        </h3>
                        <p className="rf-text-xs rf-font-mono rf-whitespace-pre-wrap rf-text-red-600 rf-mt-2">
                          {getErrorMessage(error)}
                        </p>
                      </div>
                    </div>
                  )}
                >
                  {circuitJson ? (
                    <SchematicViewer
                      controller={schematicController}
                      circuitJson={circuitJson}
                      containerStyle={{
                        height: "100%",
                      }}
                      debugGrid={showSchematicDebugGrid}
                      showSchematicPorts={showSchematicPorts}
                      css={schematicSvgOptions?.css}
                      className={schematicSvgOptions?.className}
                    />
                  ) : (
                    <PreviewEmptyState onRunClicked={onRunClicked} />
                  )}
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}

          {(!availableTabs || availableTabs.includes("cad")) && (
            <TabsContent value="cad">
              <div
                className={cn(
                  "rf-overflow-auto",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full  rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary
                  fallbackRender={({ error, resetErrorBoundary }) => (
                    <ErrorFallback
                      error={error}
                      resetErrorBoundary={resetErrorBoundary}
                    />
                  )}
                >
                  {circuitJson ? (
                    <CadViewer
                      key={`cad-${isFullScreen}`}
                      ref={setCadViewerRef}
                      circuitJson={circuitJson}
                      autoRotateDisabled={autoRotate3dViewerDisabled}
                      onViewSchematicComponent={handleViewSchematicComponent}
                    />
                  ) : (
                    <PreviewEmptyState onRunClicked={onRunClicked} />
                  )}
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}

          {(!availableTabs || availableTabs.includes("analog_simulation")) && (
            <TabsContent value="analog_simulation">
              <div
                className={cn(
                  "rf-overflow-auto",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full  rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary
                  fallback={<div>Error loading Analog Simulation</div>}
                >
                  {circuitJson ? (
                    analogSimulationError ? (
                      <div className="rf-mt-4 rf-bg-red-50 rf-rounded-md rf-border rf-border-red-200">
                        <div className="rf-p-4">
                          <h3 className="rf-text-lg rf-font-semibold rf-text-red-800 rf-mb-3">
                            Error running analog simulation
                          </h3>
                          <p className="rf-text-xs rf-font-mono rf-whitespace-pre-wrap rf-text-red-600 rf-mt-2">
                            {analogSimulationError.message}
                          </p>
                        </div>
                      </div>
                    ) : isAnalogSimulationGraphPending ? (
                      <div className="rf-flex rf-h-full rf-min-h-[300px] rf-items-center rf-justify-center rf-bg-slate-50">
                        <div className="rf-flex rf-items-center rf-gap-2 rf-text-sm rf-text-slate-600">
                          <Loader2 className="rf-h-4 rf-w-4 rf-animate-spin" />
                          Running analog simulation...
                        </div>
                      </div>
                    ) : (
                      <AnalogSimulationViewer
                        circuitJson={circuitJson}
                        hideSchematic={hideSchematicInAnalogSimulation}
                        containerStyle={{
                          height: "100%",
                        }}
                      />
                    )
                  ) : (
                    <PreviewEmptyState onRunClicked={onRunClicked} />
                  )}
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}

          {(!availableTabs || availableTabs.includes("bom")) && (
            <TabsContent value="bom">
              <div
                className={cn(
                  "rf-overflow-auto",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full  rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary
                  fallbackRender={({ error }: FallbackProps) => (
                    <div className="rf-mt-4 rf-bg-red-50 rf-rounded-md rf-border rf-border-red-200">
                      <div className="rf-p-4">
                        <h3 className="rf-text-lg rf-font-semibold rf-text-red-800 rf-mb-3">
                          Error loading Bill of Materials
                        </h3>
                        <p className="rf-text-xs rf-font-mono rf-whitespace-pre-wrap rf-text-red-600 rf-mt-2">
                          {getErrorMessage(error)}
                        </p>
                      </div>
                    </div>
                  )}
                >
                  {circuitJson ? (
                    <BomTable circuitJson={circuitJson} />
                  ) : (
                    <PreviewEmptyState onRunClicked={onRunClicked} />
                  )}
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}
          {(!availableTabs || availableTabs.includes("circuit_json")) && (
            <TabsContent value="circuit_json">
              <div
                className={cn(
                  "rf-overflow-auto",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full  rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary fallback={<div>Error loading JSON viewer</div>}>
                  {circuitJson ? (
                    <CircuitJsonTableViewer elements={circuitJson} />
                  ) : (
                    <PreviewEmptyState onRunClicked={onRunClicked} />
                  )}
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}
          {(!availableTabs || availableTabs.includes("errors")) && (
            <TabsContent value="errors" className="rf-h-full">
              <div
                className={cn(
                  "rf-overflow-hidden",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full rf-min-h-[620px]",
                )}
              >
                {errorMessage ||
                (circuitJsonErrors && circuitJsonErrors.length > 0) ||
                circuitJson ? (
                  <ErrorTabContent
                    code={code}
                    fsMap={fsMap}
                    circuitJsonErrors={circuitJsonErrors}
                    circuitJsonWarnings={circuitJsonWarnings}
                    errorMessage={errorMessage}
                    errorStack={errorStack}
                    circuitJson={circuitJson}
                    evalVersion={lastRunEvalVersion}
                    autoroutingLog={autoroutingLog}
                    onReportAutoroutingLog={onReportAutoroutingLog}
                  />
                ) : (
                  <PreviewEmptyState onRunClicked={onRunClicked} />
                )}
              </div>
            </TabsContent>
          )}
          {showRenderLogTab &&
            (!availableTabs || availableTabs.includes("render_log")) && (
              <TabsContent value="render_log">
                <RenderLogViewer
                  renderLog={renderLog}
                  onRerunWithDebug={onRerunWithDebug}
                />
              </TabsContent>
            )}
          {(!availableTabs || availableTabs.includes("autorouting")) && (
            <TabsContent value="autorouting">
              <div
                className={cn(
                  "rf-overflow-auto",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary
                  fallback={
                    <div className="rf-p-4">
                      Error loading autorouting captures
                    </div>
                  }
                >
                  <AutoroutingTabContent
                    circuitJson={circuitJson}
                    phases={autoroutingPhases}
                    isRunning={isRunningCode}
                  />
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}
          {(!availableTabs || availableTabs.includes("solvers")) && (
            <TabsContent value="solvers">
              <div
                className={cn(
                  "rf-overflow-hidden",
                  isFullScreen
                    ? "rf-h-[calc(100vh-60px)]"
                    : "rf-h-full rf-min-h-[620px]",
                )}
              >
                <ErrorBoundary fallback={<div>Error loading Solvers view</div>}>
                  <SolversTabContent solverEvents={solverEvents} />
                </ErrorBoundary>
              </div>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  )
}
