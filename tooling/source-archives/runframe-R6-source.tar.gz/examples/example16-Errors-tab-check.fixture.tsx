import { RunFrameWithApi } from "lib/components/RunFrameWithApi/RunFrameWithApi"
import { useState, useEffect } from "react"
import { isFileApiAccessible } from "./utils/isFileApiAccessible.ts"

export default () => {
  const [showWarning, setShowWarning] = useState(false)

  useEffect(() => {
    setTimeout(async () => {
      await fetch("/api/files/upsert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          file_path: "main.tsx",
          text_content: `

export default () => (
  <board width="10mm" height="10mm">
    <resistor
      resistance="1k"
      footprint="0402"
      name="R1"
      pcbX={3}
    />
    <capacitor
      capacitance="1000pF"
      footprint="0402"
      name="C1"
      pcbX={-3}
    />
        <capacitor
      capacitance="1000pF"
      footprint="0402"
      name="C2"
      pcbX={-3}
    />
    <trace from=".R1 > .pin1" to=".C1 > .pin1" />
    <trace from=".R1 > .pin1" to=".C2 > .pin1" />

  </board>
)
`,
        }),
      })
      await fetch("/api/events/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          event_type: "INITIAL_FILES_UPLOADED",
          file_count: 1,
        }),
      })
    }, 500)

    if (!isFileApiAccessible()) {
      setShowWarning(true)
    }
  }, [])

  if (showWarning) {
    return (
      <div>
        <h1>RunFrame with API</h1>
        <p>
          We don't currently deploy the API to vercel, try locally! The vite
          plugin will automatically load it.
        </p>
      </div>
    )
  }

  return <RunFrameWithApi debug />
}
