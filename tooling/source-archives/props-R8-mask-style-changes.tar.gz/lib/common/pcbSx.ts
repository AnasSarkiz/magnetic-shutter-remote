import { length } from "circuit-json"
import { expectTypesMatch } from "lib/typecheck"
import { pcbCoordinate } from "./distance"
import { z } from "zod"

export type PcbSxSelector =
  | "& footprint[src^='kicad:'] silkscreentext"
  | "& footprint[src^='jlcpcb:'] silkscreentext"
  | "& silkscreentext"
  | "& fabricationnotetext"

export interface PcbSxValue {
  /** Absolute solder-paste expansion per pad side in mm; omitted keeps the pad default. */
  solderPasteMargin?: string | number
  /** Selector override of absolute solder-mask expansion per side in mm. */
  solderMaskMargin?: string | number
  fontSize?: string | number
  pcbX?: string | number
  pcbY?: string | number
  visibility?: "hidden" | "visible" | "inherit"
}

type PcbSxBase = Record<string, PcbSxValue>

export type PcbSx = PcbSxBase & {
  [K in PcbSxSelector]?: PcbSxValue
}

export const pcbSxValue = z.object({
  solderPasteMargin: length
    .refine(Number.isFinite, "Expected a finite paste margin")
    .optional(),
  solderMaskMargin: length
    .refine(Number.isFinite, "Expected a finite solder-mask margin")
    .optional(),
  fontSize: length.optional(),
  pcbX: pcbCoordinate.optional(),
  pcbY: pcbCoordinate.optional(),
  visibility: z.enum(["hidden", "visible", "inherit"]).optional(),
})

export const pcbSx = z.record(
  z.string(),
  pcbSxValue,
) as unknown as z.ZodType<PcbSx>

expectTypesMatch<PcbSx, z.input<typeof pcbSx>>(true)
