import { expect, test } from "bun:test"
import { any_circuit_element, type PcbComponent } from "circuit-json"
import {
  applyToPoint,
  compose,
  rotateDEG,
  translate,
} from "transformation-matrix"
import {
  convertCircuitJsonToPickAndPlaceRows,
  registerSupplierTerminals,
} from "../src"
import supplierFixture from "./assets/usb4215-supplier.circuit.json"
import routedFixture from "./assets/usb4215-r6.circuit.json"
const supplier = any_circuit_element.array().parse(supplierFixture)
const routed = any_circuit_element.array().parse(routedFixture)
const source = routed.find(
  (element) => element.type === "source_component" && element.name === "J1",
)!
if (source.type !== "source_component") throw new Error("Fixture J1 source absent")
const pcbComponent = routed.find(
  (element): element is PcbComponent =>
    element.type === "pcb_component" &&
    element.source_component_id === source.source_component_id,
)!
const supplierFootprint = { supplier: "jlcpcb", circuitJson: supplier } as const
const options = {
  supplier: "jlcpcb",
  requireSupplierRotation: true,
  supplierFootprints: { C37616412: supplierFootprint },
} as const

test("verifies all sixteen actual USB4215 terminals without inventing pin 1 or mutating board geometry", () => {
  const original = structuredClone(routed)
  expect(pcbComponent.pin1_location).toBeUndefined()
  expect(() =>
    convertCircuitJsonToPickAndPlaceRows(routed, {
      supplier: "jlcpcb",
      requireSupplierRotation: true,
    }),
  ).toThrow("missing_pin1_location")
  const registration = registerSupplierTerminals({
    circuitJson: routed,
    pcbComponent,
    supplierFootprint,
  })
  expect(registration.rotationDegrees).toBe(180)
  expect(registration.terminalCount).toBe(16)
  expect(registration.maximumPositionErrorMm).toBeLessThan(1e-9)
  const row = convertCircuitJsonToPickAndPlaceRows(routed, options).find(
    (row) => row.designator === "J1",
  )!
  expect(row.rotation).toBe(180)
  expect(row.mid_x).toBe(pcbComponent.center.x)
  expect(row.mid_y).toBe(pcbComponent.center.y)
  expect(routed).toEqual(original)
})
test("registers all quarter turns in TOP board coordinates", () => {
  for (const angle of [0, 90, 180, 270]) {
    const fixture = structuredClone(supplier)
    const transform = compose(translate(7, -12), rotateDEG(angle))
    for (const element of fixture)
      if (element.type === "pcb_port")
        Object.assign(element, applyToPoint(transform, element))
    const pcb = fixture.find(
      (element): element is PcbComponent => element.type === "pcb_component",
    )!
    pcb.rotation = angle
    expect(
      registerSupplierTerminals({
        circuitJson: fixture,
        pcbComponent: pcb,
        supplierFootprint,
      }).rotationDegrees,
    ).toBe(angle)
  }
})
test("rejects missing, shifted, mirrored terminals, bottom assembly and incorrect exact part identity", () => {
  const missing = routed.filter(
    (element) =>
      !(
        element.type === "pcb_port" &&
        element.pcb_component_id === pcbComponent.pcb_component_id &&
        element.pcb_port_id === "pcb_port_0"
      ),
  )
  expect(() => convertCircuitJsonToPickAndPlaceRows(missing, options)).toThrow(
    "one physical terminal",
  )
  const shifted = structuredClone(routed)
  const port = shifted.find(
    (element) =>
      element.type === "pcb_port" && element.pcb_port_id === "pcb_port_0",
  )!
  if (port.type !== "pcb_port") throw Error("Fixture missing")
  port.x += 0.01
  expect(() => convertCircuitJsonToPickAndPlaceRows(shifted, options)).toThrow(
    "unique rotation",
  )
  const reflected = structuredClone(routed)
  for (const element of reflected)
    if (
      element.type === "pcb_port" &&
      element.pcb_component_id === pcbComponent.pcb_component_id
    )
      element.x = -element.x
  expect(() =>
    convertCircuitJsonToPickAndPlaceRows(reflected, options),
  ).toThrow("unique rotation")
  expect(() =>
    registerSupplierTerminals({
      circuitJson: routed,
      pcbComponent: { ...pcbComponent, layer: "bottom" },
      supplierFootprint,
    }),
  ).toThrow("TOP")
  const wrong = structuredClone(supplier)
  const wrongSource = wrong.find(
    (element) => element.type === "source_component",
  )!
  if (wrongSource.type !== "source_component") throw Error("Fixture missing")
  wrongSource.manufacturer_part_number = "incorrect-part-negative-control"
  expect(() =>
    registerSupplierTerminals({
      circuitJson: routed,
      pcbComponent,
      supplierFootprint: { supplier: "jlcpcb", circuitJson: wrong },
    }),
  ).toThrow("identity mismatch")
})
