import type {
  AnyCircuitElement,
  PcbComponent,
  PcbPort,
  SourcePort,
  SupplierName,
} from "circuit-json"
import {
  applyToPoint,
  compose,
  rotateDEG,
  translate,
} from "transformation-matrix"

export interface SupplierTerminalFootprint {
  supplier: SupplierName
  circuitJson: AnyCircuitElement[]
}

export interface SupplierTerminalRegistration {
  rotationDegrees: number
  terminalCount: number
  maximumPositionErrorMm: number
}

type Terminal = { port: SourcePort; position: PcbPort }

function readTerminals(
  circuitJson: AnyCircuitElement[],
  pcbComponent: PcbComponent,
): Terminal[] {
  const sourcePorts = circuitJson.filter(
    (element): element is SourcePort =>
      element.type === "source_port" &&
      element.source_component_id === pcbComponent.source_component_id,
  )
  return sourcePorts.map((port) => {
    const positions = circuitJson.filter(
      (element): element is PcbPort =>
        element.type === "pcb_port" &&
        element.source_port_id === port.source_port_id &&
        element.pcb_component_id === pcbComponent.pcb_component_id,
    )
    if (positions.length !== 1)
      throw new Error(
        `Supplier rotation requires one physical terminal per port: ${port.name}`,
      )
    return { port, position: positions[0]! }
  })
}

/** Verify TOP assembly against the exact unrotated supplier model, without
 * inventing a numeric pin 1. Both coordinate frames are PCB world XY mm,
 * right-handed, +X right/+Y up/+Z above. Every named/numbered terminal must
 * match one unique quarter-turn and translation. Reflections are rejected.
 * This is terminal pose verification; land/drill fidelity is a separate check.
 */
export function registerSupplierTerminals(params: {
  circuitJson: AnyCircuitElement[]
  pcbComponent: PcbComponent
  supplierFootprint: SupplierTerminalFootprint
}): SupplierTerminalRegistration {
  const { circuitJson, pcbComponent, supplierFootprint } = params
  if (pcbComponent.layer !== "top")
    throw new Error(
      "Supplier terminal registration requires TOP assembly; bottom mirroring is not qualified",
    )
  const supplierComponents = supplierFootprint.circuitJson.filter(
    (element): element is PcbComponent =>
      element.type === "pcb_component" && !element.do_not_place,
  )
  if (
    supplierComponents.length !== 1 ||
    supplierComponents[0]!.layer !== "top" ||
    supplierComponents[0]!.rotation !== 0
  )
    throw new Error(
      "Supplier footprint must contain exactly one unrotated TOP component",
    )
  const placedSource = circuitJson.find(
    (element) =>
      element.type === "source_component" &&
      element.source_component_id === pcbComponent.source_component_id,
  )
  const supplierSource = supplierFootprint.circuitJson.find(
    (element) =>
      element.type === "source_component" &&
      element.source_component_id ===
        supplierComponents[0]!.source_component_id,
  )
  if (
    placedSource?.type !== "source_component" ||
    supplierSource?.type !== "source_component" ||
    !placedSource.supplier_part_numbers?.[supplierFootprint.supplier]?.[0] ||
    placedSource.supplier_part_numbers[supplierFootprint.supplier]?.[0] !==
      supplierSource.supplier_part_numbers?.[supplierFootprint.supplier]?.[0] ||
    placedSource.manufacturer_part_number !==
      supplierSource.manufacturer_part_number
  )
    throw new Error(
      "Supplier footprint exact MPN/part-number identity mismatch",
    )
  const placedTerminals = readTerminals(circuitJson, pcbComponent)
  const supplierTerminals = readTerminals(
    supplierFootprint.circuitJson,
    supplierComponents[0]!,
  )
  if (
    placedTerminals.length < 3 ||
    placedTerminals.length !== supplierTerminals.length
  )
    throw new Error("Supplier terminal coverage mismatch")
  const pairs = supplierTerminals.map((supplierTerminal) => {
    const matches = placedTerminals.filter((placedTerminal) =>
      supplierTerminal.port.pin_number !== undefined
        ? placedTerminal.port.pin_number === supplierTerminal.port.pin_number
        : placedTerminal.port.name === supplierTerminal.port.name,
    )
    if (matches.length !== 1)
      throw new Error(
        `Missing or ambiguous supplier terminal: ${supplierTerminal.port.name}`,
      )
    return { supplier: supplierTerminal.position, placed: matches[0]!.position }
  })
  const candidates = [0, 90, 180, 270].flatMap((rotationDegrees) => {
    const rotation = rotateDEG(rotationDegrees)
    const first = pairs[0]!
    const rotated = applyToPoint(rotation, first.supplier)
    const transform = compose(
      translate(first.placed.x - rotated.x, first.placed.y - rotated.y),
      rotation,
    )
    const maximumPositionErrorMm = Math.max(
      ...pairs.map((pair) => {
        const expected = applyToPoint(transform, pair.supplier)
        return Math.hypot(
          expected.x - pair.placed.x,
          expected.y - pair.placed.y,
        )
      }),
    )
    // Numerical transform/serialization bound only; not a manufacturing tolerance.
    return maximumPositionErrorMm <= 0.000001
      ? [
          {
            rotationDegrees,
            terminalCount: pairs.length,
            maximumPositionErrorMm,
          },
        ]
      : []
  })
  if (candidates.length !== 1)
    throw new Error(
      "Supplier terminals do not establish one unique rotation; geometry is mismatched, mirrored or ambiguous",
    )
  return candidates[0]!
}
