import { expect, test } from "bun:test"
import { getTestFixture } from "tests/fixtures/get-test-fixture"

test("specific mask selector overrides inherited general style", () => {
  const { circuit } = getTestFixture()
  circuit.add(<board width={10} height={8} routingDisabled pcbSx={{"& smtpad": {solderMaskMargin: 0.06}}}>
    <chip name="U1" pcbSx={{"& footprint smtpad[portHints='pin1']": {solderMaskMargin: 0.02}}}
      footprint={<footprint><smtpad portHints={["pin1"]} shape="rect" width={0.3} height={1.2} solderMaskMargin="0.0508mm"/></footprint>}/>
    <pcbnotetext text="Specific 0.02 mm beats inherited 0.06 mm" pcbY={2}/>
  </board>)
  circuit.render()
  expect(circuit.db.pcb_smtpad.list()[0].soldermask_margin).toBeCloseTo(0.02)
  expect(circuit.getCircuitJson()).toMatchPcbSnapshot(import.meta.path)
})
