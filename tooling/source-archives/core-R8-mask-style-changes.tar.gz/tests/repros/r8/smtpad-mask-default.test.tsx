import { expect, test } from "bun:test"
import { getTestFixture } from "tests/fixtures/get-test-fixture"

test("unmatched mask selector preserves explicit supplier margin", () => {
  const { circuit } = getTestFixture()
  circuit.add(<board width={10} height={8} routingDisabled pcbSx={{"& footprint[src='other'] smtpad": {solderMaskMargin: 0.01}}}>
    <chip name="U1" footprint={<footprint><smtpad shape="rect" width={0.3} height={1.2} solderMaskMargin="0.0508mm"/></footprint>}/>
    <pcbnotetext text="Unmatched style retains supplier 0.0508 mm" pcbY={2}/>
  </board>)
  circuit.render()
  expect(circuit.db.pcb_smtpad.list()[0].soldermask_margin).toBeCloseTo(0.0508)
  expect(circuit.getCircuitJson()).toMatchPcbSnapshot(import.meta.path)
})
