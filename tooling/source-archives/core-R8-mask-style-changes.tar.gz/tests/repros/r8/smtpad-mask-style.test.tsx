import { expect, test } from "bun:test"
import { getTestFixture } from "tests/fixtures/get-test-fixture"

test("mask process override preserves supplier primitive and copper", () => {
  const { circuit } = getTestFixture()
  circuit.add(<board width={10} height={8} routingDisabled>
    <chip name="U1" pcbSx={{"& smtpad": {solderMaskMargin: "0.04mm"}}}
      footprint={<footprint><smtpad portHints={["pin1"]} shape="rect" width={0.3} height={1.2}
        solderMaskMargin="0.0508mm"/></footprint>}/>
    <pcbnotetext text="Mask override 0.04 mm; supplier copper preserved" pcbY={2}/>
  </board>)
  circuit.render()
  const pad = circuit.db.pcb_smtpad.list()[0]
  expect(pad.soldermask_margin).toBeCloseTo(0.04)
  expect(pad.shape).toBe("rect")
  if (pad.shape !== "rect") throw new Error("Expected unchanged rectangular pad")
  expect([pad.x, pad.y, pad.width, pad.height]).toEqual([0, 0, 0.3, 1.2])
  expect(circuit.selectOne("smtpad")?.props.solderMaskMargin).toBe("0.0508mm")
  expect(circuit.getCircuitJson()).toMatchPcbSnapshot(import.meta.path)
})
