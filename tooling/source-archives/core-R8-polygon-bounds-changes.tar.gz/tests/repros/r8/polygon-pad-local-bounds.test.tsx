import { expect, test } from "bun:test"
import { getTestFixture } from "tests/fixtures/get-test-fixture"

for (const rotationDegrees of [0, 90, 180, 270]) {
  test(`offset polygon contributes its actual bounds at${rotationDegrees}deg`, () => {
    const { circuit } = getTestFixture()
    circuit.add(
      <board width={30} height={30} routingDisabled>
        <chip name="U1" pcbX={3} pcbY={-2} pcbRotation={rotationDegrees}
          footprint={<footprint>
            <smtpad shape="polygon" points={[{x:4,y:1},{x:6,y:1},{x:6,y:3},{x:4,y:3}]} />
            <smtpad shape="rect" width={1} height={1} pcbX={-1} />
          </footprint>} />
      </board>,
    )
    circuit.render()
    const component = circuit.db.pcb_component.list()[0]
    const pads = circuit.db.pcb_smtpad.list()
    const coordinates = pads.flatMap((pad) => {
      if (pad.shape === "polygon") return pad.points
      if (pad.shape === "rect") return [
        {x:pad.x-pad.width/2,y:pad.y-pad.height/2},
        {x:pad.x+pad.width/2,y:pad.y+pad.height/2},
      ]
      throw new Error("Unexpected test pad shape")
    })
    const minX = Math.min(...coordinates.map((point) => point.x))
    const maxX = Math.max(...coordinates.map((point) => point.x))
    const minY = Math.min(...coordinates.map((point) => point.y))
    const maxY = Math.max(...coordinates.map((point) => point.y))
    expect(component.center.x).toBeCloseTo((minX+maxX)/2,8)
    expect(component.center.y).toBeCloseTo((minY+maxY)/2,8)
    expect(component.width).toBeCloseTo(maxX-minX,8)
    expect(component.height).toBeCloseTo(maxY-minY,8)
    expect(circuit.getCircuitJson()).toMatchPcbSnapshot(`${import.meta.dir}/polygon-pad-local-bounds-${rotationDegrees}.test.tsx`)
  })
}
