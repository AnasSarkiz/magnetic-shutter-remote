import { expect, test } from "bun:test"
import { getTestFixture } from "tests/fixtures/get-test-fixture"

test("board footprint selector hides supplier circles while retaining functional text", () => {
  const { circuit } = getTestFixture()
  circuit.add(
    <board
      width={20}
      height={20}
      routingDisabled
      pcbSx={{ "& footprint silkscreencircle": { visibility: "hidden" } }}
    >
      <chip
        name="U1"
        footprint={
          <footprint>
            <silkscreencircle pcbX={1} pcbY={2} radius={0.2} />
          </footprint>
        }
      />
      <silkscreentext text="PIN 1" pcbX={4} pcbY={4} fontSize={1.8} />
    </board>,
  )
  circuit.render()
  expect(circuit.db.pcb_silkscreen_circle.list()).toHaveLength(0)
  expect(
    circuit.db.pcb_silkscreen_text.list().some((x) => x.text === "PIN 1"),
  ).toBe(true)
})

test("component scope only hides the selected circle footprint", () => {
  const { circuit } = getTestFixture()
  const footprint = (
    <footprint>
      <silkscreencircle radius={0.2} />
    </footprint>
  )
  circuit.add(
    <board width={20} height={20} routingDisabled>
      <chip
        name="U1"
        pcbX={-4}
        footprint={footprint}
        pcbSx={{ "& footprint silkscreencircle": { visibility: "hidden" } }}
      />
      <chip name="U2" pcbX={4} footprint={footprint} />
    </board>,
  )
  circuit.render()
  const circles = circuit.db.pcb_silkscreen_circle.list()
  expect(circles).toHaveLength(1)
  expect(circles[0].center.x).toBeCloseTo(4)
})

test("visible circle retains transform, radius, stroke and layer", () => {
  const { circuit } = getTestFixture()
  circuit.add(
    <board width={20} height={20} routingDisabled>
      <chip
        name="U1"
        pcbX={3}
        pcbY={4}
        footprint={
          <footprint>
            <silkscreencircle
              pcbX={1}
              pcbY={2}
              radius={0.2}
              strokeWidth={0.18}
              layer="bottom"
            />
          </footprint>
        }
      />
    </board>,
  )
  circuit.render()
  const circle = circuit.db.pcb_silkscreen_circle.list()[0]
  expect(circle.center).toEqual({ x: 4, y: 6 })
  expect(circle.radius).toBe(0.2)
  expect(circle.stroke_width).toBe(0.18)
  expect(circle.layer).toBe("bottom")
})
