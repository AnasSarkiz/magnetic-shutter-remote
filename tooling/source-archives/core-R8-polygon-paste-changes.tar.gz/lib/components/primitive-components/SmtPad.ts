import { resolvePcbProperty } from "lib/utils/pcbSx/resolve-pcb-property"
import { smtPadProps } from "@tscircuit/props"
import {
  distance,
  type LayerRef,
  type PcbSmtPad,
  type PcbSmtPadCircle,
  type PcbSmtPadRect,
  type PcbSmtPadPolygon,
  type PcbSmtPadRotatedRect,
  type PcbSmtPadPill,
  type PcbSmtPadRotatedPill,
} from "circuit-json"
import {
  applyToPoint,
  decomposeTSR,
  compose,
  translate,
  scale,
} from "transformation-matrix"
import { PrimitiveComponent } from "../base-components/PrimitiveComponent"
import type { Port } from "./Port"
import { selectPortForPcbPrimitive } from "./Port/selectPortForPcbPrimitive"
import { getAxisAlignedSizeFromRotatedRect } from "lib/utils/pcb/get-axis-aligned-size-from-rotated-rect"

export class SmtPad extends PrimitiveComponent<typeof smtPadProps> {
  pcb_smtpad_id: string | null = null

  matchedPort: Port | null = null

  isPcbPrimitive = true

  get config() {
    return {
      componentName: "SmtPad",
      zodProps: smtPadProps,
    }
  }

  _getPcbLocalBoundsBeforeLayout() {
    const { _parsedProps: props } = this
    if (props.shape !== "polygon") {
      return super._getPcbLocalBoundsBeforeLayout()
    }
    // Polygon points already carry their offset in the primitive-local frame.
    // A width/height box around0 loses that offset before board transformation.
    const xs = props.points.map((point) => point.x)
    const ys = props.points.map((point) => point.y)
    return {
      left: Math.min(...xs),
      right: Math.max(...xs),
      bottom: Math.min(...ys),
      top: Math.max(...ys),
    }
  }

  getPcbSize(): { width: number; height: number } {
    const { _parsedProps: props } = this
    if (props.shape === "circle") {
      return { width: props.radius! * 2, height: props.radius! * 2 }
    }
    if (props.shape === "rect") {
      return { width: props.width!, height: props.height! }
    }
    if (props.shape === "rotated_rect") {
      const { width, height } = getAxisAlignedSizeFromRotatedRect({
        width: props.width!,
        height: props.height!,
        ccwRotationDegrees: props.ccwRotation ?? 0,
      })
      return { width, height }
    }
    if (props.shape === "polygon") {
      const points = props.points!
      const xs = points.map((p) => p.x)
      const ys = points.map((p) => p.y)
      const minX = Math.min(...xs)
      const maxX = Math.max(...xs)
      const minY = Math.min(...ys)
      const maxY = Math.max(...ys)
      return { width: maxX - minX, height: maxY - minY }
    }
    if (props.shape === "pill") {
      return { width: props.width!, height: props.height! }
    }
    if (props.shape === "rotated_pill") {
      const { width, height } = getAxisAlignedSizeFromRotatedRect({
        width: props.width,
        height: props.height,
        ccwRotationDegrees: props.ccwRotation,
      })
      return { width, height }
    }
    throw new Error(
      `getPcbSize for shape "${(props as any).shape}" not implemented for ${this.componentName}`,
    )
  }

  doInitialPortMatching(): void {
    const parentPorts = this.getPrimitiveContainer()?.selectAll(
      "port",
    ) as Port[]

    if (!this.props.portHints) {
      return
    }

    const port = selectPortForPcbPrimitive(
      parentPorts,
      this,
      this.props.portHints,
    )
    if (!port) return

    this.matchedPort = port
    port.registerMatch(this)
  }

  doInitialPcbPrimitiveRender(): void {
    if (this.root?.pcbDisabled) return
    const { db } = this.root!
    const { _parsedProps: props } = this
    const isCoveredWithSolderMask = props.coveredWithSolderMask ?? false
    const shouldCreateSolderPaste = !isCoveredWithSolderMask
    const styledSolderMaskMargin = resolvePcbProperty({
      propertyName: "solderMaskMargin",
      resolvedPcbSx: this.getResolvedPcbSx(),
      pathFromAmpersand: "smtpad",
      component: this,
    })
    // A selected process override leaves the supplier primitive immutable.
    // Without a matching selector, preserve its explicit margin and default.
    const soldermaskMargin =
      typeof styledSolderMaskMargin === "number"
        ? styledSolderMaskMargin
        : props.solderMaskMargin
    const styledSolderPasteMargin = resolvePcbProperty({
      propertyName: "solderPasteMargin",
      resolvedPcbSx: this.getResolvedPcbSx(),
      pathFromAmpersand: "smtpad",
      component: this,
    })
    // Explicit primitive values retain priority; parent styles preserve imports.
    const solderPasteMargin =
      props.solderPasteMargin ??
      (typeof styledSolderPasteMargin === "number"
        ? styledSolderPasteMargin
        : undefined)
    // solderPasteMargin is absolute per side; without it the aperture keeps
    // the default 0.7 scale
    const getSolderPasteSize = (padSize: number, marginScale = 2): number =>
      solderPasteMargin !== undefined
        ? Math.max(padSize + marginScale * solderPasteMargin, 0)
        : padSize * 0.7

    this.emitSolderMaskMarginWarning(isCoveredWithSolderMask, soldermaskMargin)

    const subcircuit = this.getSubcircuit()

    const position = this._getGlobalPcbPositionBeforeLayout()
    const globalTransform = this._computePcbGlobalTransformBeforeLayout()
    const decomposedTransform = decomposeTSR(
      this._computePcbGlobalTransformBeforeLayout(),
    )
    const rotationDegrees = (decomposedTransform.rotation.angle * 180) / Math.PI
    const normalizedRotationDegrees = ((rotationDegrees % 360) + 360) % 360
    const rotationTolerance = 0.01
    const isAxisAligned =
      Math.abs(normalizedRotationDegrees) < rotationTolerance ||
      Math.abs(normalizedRotationDegrees - 180) < rotationTolerance ||
      Math.abs(normalizedRotationDegrees - 360) < rotationTolerance
    const isRotated90Degrees =
      Math.abs(normalizedRotationDegrees - 90) < rotationTolerance ||
      Math.abs(normalizedRotationDegrees - 270) < rotationTolerance
    let finalRotationDegrees =
      Math.abs(normalizedRotationDegrees - 360) < rotationTolerance
        ? 0
        : normalizedRotationDegrees
    const transformRotationBeforeFlip = finalRotationDegrees
    const { maybeFlipLayer: maybeFlipDefaultLayer, isFlipped } =
      this._getPcbPrimitiveFlippedHelpers()
    const primitiveContainer = this.getPrimitiveContainer()
    const primitiveContainerLayer =
      primitiveContainer?.props?.layer !== undefined
        ? primitiveContainer?._parsedProps.layer
        : undefined
    const maybeFlipLayer = (layer: LayerRef) =>
      primitiveContainerLayer ?? maybeFlipDefaultLayer(layer)

    if (isFlipped) {
      finalRotationDegrees = (360 - finalRotationDegrees + 360) % 360
    }

    const portHints = props.portHints?.map((ph) => ph.toString()) ?? []

    let pcb_smtpad: PcbSmtPad | null = null
    const pcb_component_id =
      this.parent?.pcb_component_id ??
      this.getPrimitiveContainer()?.pcb_component_id!
    if (props.shape === "circle") {
      pcb_smtpad = db.pcb_smtpad.insert({
        pcb_component_id,
        pcb_port_id: this.matchedPort?.pcb_port_id!, // port likely isn't matched
        layer: maybeFlipLayer(props.layer ?? "top"),
        shape: "circle",
        radius: props.radius!,
        port_hints: portHints,
        is_covered_with_solder_mask: isCoveredWithSolderMask,
        soldermask_margin: soldermaskMargin,
        x: position.x,
        y: position.y,
        subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
      } as PcbSmtPadCircle) as PcbSmtPadCircle
      const pasteRadius = getSolderPasteSize(pcb_smtpad.radius, 1)
      if (shouldCreateSolderPaste && pasteRadius > 0)
        db.pcb_solder_paste.insert({
          layer: pcb_smtpad.layer,
          shape: "circle",
          radius: pasteRadius,
          x: pcb_smtpad.x,
          y: pcb_smtpad.y,
          pcb_component_id: pcb_smtpad.pcb_component_id,
          pcb_smtpad_id: pcb_smtpad.pcb_smtpad_id,
          subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
          pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
        } as PcbSmtPadCircle)
    } else if (props.shape === "rect") {
      const hasRotation = !isAxisAligned && !isRotated90Degrees
      if (hasRotation) {
        pcb_smtpad = db.pcb_smtpad.insert({
          pcb_component_id,
          pcb_port_id: this.matchedPort?.pcb_port_id!,
          layer: maybeFlipLayer(props.layer ?? "top"),
          shape: "rotated_rect",
          width: props.width!,
          height: props.height!,
          corner_radius: props.cornerRadius ?? undefined,
          x: position.x,
          y: position.y,
          ccw_rotation: finalRotationDegrees,
          port_hints: portHints,
          is_covered_with_solder_mask: isCoveredWithSolderMask,
          soldermask_margin: soldermaskMargin,
          subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
          pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
        } as PcbSmtPadRotatedRect) as PcbSmtPadRotatedRect
      } else {
        pcb_smtpad = db.pcb_smtpad.insert({
          pcb_component_id,
          pcb_port_id: this.matchedPort?.pcb_port_id!,
          layer: maybeFlipLayer(props.layer ?? "top"),
          shape: "rect",
          width: isRotated90Degrees ? props.height! : props.width!,
          height: isRotated90Degrees ? props.width! : props.height!,
          corner_radius: props.cornerRadius ?? undefined,
          port_hints: portHints,
          is_covered_with_solder_mask: isCoveredWithSolderMask,
          soldermask_margin: soldermaskMargin,
          x: position.x,
          y: position.y,
          subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
          pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
        } as PcbSmtPadRect) as PcbSmtPadRect
      }
      const pasteWidth = getSolderPasteSize(pcb_smtpad.width)
      const pasteHeight = getSolderPasteSize(pcb_smtpad.height)
      if (shouldCreateSolderPaste && pasteWidth > 0 && pasteHeight > 0) {
        if (pcb_smtpad.shape === "rect") {
          db.pcb_solder_paste.insert({
            layer: maybeFlipLayer(props.layer ?? "top"),
            shape: "rect",
            width: pasteWidth,
            height: pasteHeight,
            x: pcb_smtpad.x,
            y: pcb_smtpad.y,
            pcb_component_id: pcb_smtpad.pcb_component_id,
            pcb_smtpad_id: pcb_smtpad.pcb_smtpad_id,
            subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
            pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
          } as PcbSmtPadRect)
        } else if (pcb_smtpad.shape === "rotated_rect") {
          db.pcb_solder_paste.insert({
            layer: maybeFlipLayer(props.layer ?? "top"),
            shape: "rotated_rect",
            width: pasteWidth,
            height: pasteHeight,
            x: pcb_smtpad.x,
            y: pcb_smtpad.y,
            ccw_rotation: pcb_smtpad.ccw_rotation,
            pcb_component_id: pcb_smtpad.pcb_component_id,
            pcb_smtpad_id: pcb_smtpad.pcb_smtpad_id,
            subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
            pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
          } as PcbSmtPadRotatedRect)
        }
      }
    } else if (props.shape === "rotated_rect") {
      const baseRotation = props.ccwRotation ?? 0
      const combinedRotationBeforeFlip =
        (transformRotationBeforeFlip + baseRotation + 360) % 360
      const padRotation = isFlipped
        ? (360 - combinedRotationBeforeFlip + 360) % 360
        : combinedRotationBeforeFlip

      pcb_smtpad = db.pcb_smtpad.insert({
        pcb_component_id,
        pcb_port_id: this.matchedPort?.pcb_port_id!,
        layer: maybeFlipLayer(props.layer ?? "top"),
        shape: "rotated_rect",
        width: props.width!,
        height: props.height!,
        corner_radius: props.cornerRadius ?? undefined,
        x: position.x,
        y: position.y,
        ccw_rotation: padRotation,
        port_hints: portHints,
        is_covered_with_solder_mask: isCoveredWithSolderMask,
        soldermask_margin: soldermaskMargin,
        subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
        pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
      } as PcbSmtPadRotatedRect) as PcbSmtPadRotatedRect

      const pasteWidth = getSolderPasteSize(pcb_smtpad.width)
      const pasteHeight = getSolderPasteSize(pcb_smtpad.height)
      if (shouldCreateSolderPaste && pasteWidth > 0 && pasteHeight > 0)
        db.pcb_solder_paste.insert({
          layer: maybeFlipLayer(props.layer ?? "top"),
          shape: "rotated_rect",
          width: pasteWidth,
          height: pasteHeight,
          x: position.x,
          y: position.y,
          ccw_rotation: padRotation,
          pcb_component_id,
          pcb_smtpad_id: pcb_smtpad.pcb_smtpad_id,
          subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
          pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
        } as PcbSmtPadRotatedRect)
    } else if (props.shape === "polygon") {
      const transformedPoints = props.points.map((point) => {
        const transformed = applyToPoint(globalTransform, {
          x: distance.parse(point.x),
          y: distance.parse(point.y),
        })
        return {
          x: transformed.x,
          y: transformed.y,
        }
      })

      pcb_smtpad = db.pcb_smtpad.insert({
        pcb_component_id,
        pcb_port_id: this.matchedPort?.pcb_port_id!, // port likely isn't matched
        layer: maybeFlipLayer(props.layer ?? "top"),
        shape: "polygon",
        points: transformedPoints,
        port_hints: portHints,
        is_covered_with_solder_mask: isCoveredWithSolderMask,
        soldermask_margin: soldermaskMargin,
        subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
        pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
      } as PcbSmtPadPolygon) as PcbSmtPadPolygon
      if (shouldCreateSolderPaste) {
        // Arbitrary polygon offsets can change topology. Fail explicitly rather
        // than pretending a bounding rectangle is its solder-paste aperture.
        if (solderPasteMargin !== undefined && solderPasteMargin !== 0) {
          throw new Error(
            "Nonzero solderPasteMargin for polygon pads requires polygon offset support",
          )
        }
        const minX = Math.min(...transformedPoints.map((point) => point.x))
        const maxX = Math.max(...transformedPoints.map((point) => point.x))
        const minY = Math.min(...transformedPoints.map((point) => point.y))
        const maxY = Math.max(...transformedPoints.map((point) => point.y))
        const x = (minX + maxX) / 2
        const y = (minY + maxY) / 2
        const pasteScale = solderPasteMargin === 0 ? 1 : 0.7
        const padToPasteTransform = compose(
          translate(x, y),
          scale(pasteScale),
          translate(-x, -y),
        )
        db.pcb_solder_paste.insert({
          layer: pcb_smtpad.layer,
          shape: "polygon",
          x,
          y,
          points: transformedPoints.map((point) =>
            applyToPoint(padToPasteTransform, point),
          ),
          pcb_component_id,
          pcb_smtpad_id: pcb_smtpad.pcb_smtpad_id,
          subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
          pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
        })
      }
    } else if (props.shape === "rotated_pill") {
      const combinedRotationBeforeFlip =
        (transformRotationBeforeFlip + props.ccwRotation + 360) % 360
      const padRotation = isFlipped
        ? (360 - combinedRotationBeforeFlip + 360) % 360
        : combinedRotationBeforeFlip

      pcb_smtpad = db.pcb_smtpad.insert({
        pcb_component_id,
        pcb_port_id: this.matchedPort?.pcb_port_id!,
        layer: maybeFlipLayer(props.layer ?? "top"),
        shape: "rotated_pill",
        x: position.x,
        y: position.y,
        radius: props.radius,
        height: props.height,
        width: props.width,
        ccw_rotation: padRotation,
        port_hints: portHints,
        is_covered_with_solder_mask: isCoveredWithSolderMask,
        soldermask_margin: soldermaskMargin,
        subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
        pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
      } as PcbSmtPadRotatedPill)
    } else if (props.shape === "pill") {
      if (finalRotationDegrees !== 0) {
        pcb_smtpad = db.pcb_smtpad.insert({
          pcb_component_id,
          pcb_port_id: this.matchedPort?.pcb_port_id!, // port likely isn't matched
          layer: maybeFlipLayer(props.layer ?? "top"),
          shape: "rotated_pill",
          x: position.x,
          y: position.y,
          radius: props.radius!,
          height: props.height!,
          width: props.width!,
          ccw_rotation: finalRotationDegrees,
          port_hints: portHints,
          is_covered_with_solder_mask: isCoveredWithSolderMask,
          soldermask_margin: soldermaskMargin,
          subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
          pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
        } as PcbSmtPadRotatedPill)
      } else {
        pcb_smtpad = db.pcb_smtpad.insert({
          pcb_component_id,
          pcb_port_id: this.matchedPort?.pcb_port_id!, // port likely isn't matched
          layer: maybeFlipLayer(props.layer ?? "top"),
          shape: "pill",
          x: position.x,
          y: position.y,
          radius: props.radius!,
          height: props.height!,
          width: props.width!,
          port_hints: portHints,
          is_covered_with_solder_mask: isCoveredWithSolderMask,
          soldermask_margin: soldermaskMargin,
          subcircuit_id: subcircuit?.subcircuit_id ?? undefined,
          pcb_group_id: this.getGroup()?.pcb_group_id ?? undefined,
        } as PcbSmtPadPill)
      }
    }
    if (pcb_smtpad) {
      this.pcb_smtpad_id = pcb_smtpad.pcb_smtpad_id
    }
  }

  doInitialPcbPortAttachment(): void {
    if (this.root?.pcbDisabled) return
    const { db } = this.root!
    db.pcb_smtpad.update(this.pcb_smtpad_id!, {
      pcb_port_id: this.matchedPort?.pcb_port_id!,
    })
  }

  getAvailablePcbLayers(): string[] {
    const { maybeFlipLayer } = this._getPcbPrimitiveFlippedHelpers()
    const primitiveContainer = this.getPrimitiveContainer()
    const primitiveContainerLayer =
      primitiveContainer?.props?.layer !== undefined
        ? primitiveContainer?._parsedProps.layer
        : undefined
    return [
      primitiveContainerLayer ??
        maybeFlipLayer(this._parsedProps.layer ?? "top"),
    ]
  }

  /** Axis-aligned bounds in board world space (mm): +X right, +Y top.
   * These are point coordinates, including the footprint placement transform.
   * Port overlap checks require top = max Y and bottom = min Y for every shape.
   */
  _getPcbCircuitJsonBounds(): {
    center: { x: number; y: number }
    bounds: { left: number; top: number; right: number; bottom: number }
    width: number
    height: number
  } {
    const { db } = this.root!
    const smtpad = db.pcb_smtpad.get(this.pcb_smtpad_id!)!

    if (smtpad.shape === "rect") {
      return {
        center: { x: smtpad.x, y: smtpad.y },
        bounds: {
          left: smtpad.x - smtpad.width / 2,
          top: smtpad.y + smtpad.height / 2,
          right: smtpad.x + smtpad.width / 2,
          bottom: smtpad.y - smtpad.height / 2,
        },
        width: smtpad.width,
        height: smtpad.height,
      }
    }
    if (smtpad.shape === "rotated_rect") {
      const { width, height, xExtent, yExtent } =
        getAxisAlignedSizeFromRotatedRect({
          width: smtpad.width,
          height: smtpad.height,
          ccwRotationDegrees: smtpad.ccw_rotation,
        })

      return {
        center: { x: smtpad.x, y: smtpad.y },
        bounds: {
          left: smtpad.x - xExtent,
          right: smtpad.x + xExtent,
          top: smtpad.y + yExtent,
          bottom: smtpad.y - yExtent,
        },
        width,
        height,
      }
    }
    if (smtpad.shape === "circle") {
      return {
        center: { x: smtpad.x, y: smtpad.y },
        bounds: {
          left: smtpad.x - smtpad.radius,
          top: smtpad.y + smtpad.radius,
          right: smtpad.x + smtpad.radius,
          bottom: smtpad.y - smtpad.radius,
        },
        width: smtpad.radius * 2,
        height: smtpad.radius * 2,
      }
    }
    if (smtpad.shape === "polygon") {
      const points = smtpad.points!
      const xs = points.map((p) => p.x)
      const ys = points.map((p) => p.y)
      const minX = Math.min(...xs)
      const maxX = Math.max(...xs)
      const minY = Math.min(...ys)
      const maxY = Math.max(...ys)

      return {
        center: { x: (minX + maxX) / 2, y: (minY + maxY) / 2 },
        bounds: {
          left: minX,
          top: maxY,
          right: maxX,
          bottom: minY,
        },
        width: maxX - minX,
        height: maxY - minY,
      }
    }
    if (smtpad.shape === "pill") {
      // For pill shape, the radius is applied to the shorter dimension
      const halfWidth = smtpad.width / 2
      const halfHeight = smtpad.height / 2
      return {
        center: { x: smtpad.x, y: smtpad.y },
        bounds: {
          left: smtpad.x - halfWidth,
          top: smtpad.y + halfHeight,
          right: smtpad.x + halfWidth,
          bottom: smtpad.y - halfHeight,
        },
        width: smtpad.width,
        height: smtpad.height,
      }
    }
    if (smtpad.shape === "rotated_pill") {
      const { width, height, xExtent, yExtent } =
        getAxisAlignedSizeFromRotatedRect({
          width: smtpad.width,
          height: smtpad.height,
          ccwRotationDegrees: smtpad.ccw_rotation,
        })

      return {
        center: { x: smtpad.x, y: smtpad.y },
        bounds: {
          left: smtpad.x - xExtent,
          right: smtpad.x + xExtent,
          top: smtpad.y + yExtent,
          bottom: smtpad.y - yExtent,
        },
        width,
        height,
      }
    }
    throw new Error(
      `circuitJson bounds calculation not implemented for shape "${(smtpad as any).shape}"`,
    )
  }

  _setPositionFromLayout(newCenter: { x: number; y: number }) {
    const { db } = this.root!
    db.pcb_smtpad.update(this.pcb_smtpad_id!, {
      x: newCenter.x,
      y: newCenter.y,
    })

    const solderPaste = db.pcb_solder_paste
      .list()
      .find((elm) => elm.pcb_smtpad_id === this.pcb_smtpad_id)
    if (solderPaste) {
      db.pcb_solder_paste.update(solderPaste.pcb_solder_paste_id, {
        x: newCenter.x,
        y: newCenter.y,
      })
    }

    this.matchedPort?._setPositionFromLayout(newCenter)
  }

  _moveCircuitJsonElements({
    deltaX,
    deltaY,
  }: { deltaX: number; deltaY: number }) {
    if (this.root?.pcbDisabled) return
    const { db } = this.root!
    if (!this.pcb_smtpad_id) return

    const pad = db.pcb_smtpad.get(this.pcb_smtpad_id)!

    if (
      pad.shape === "rect" ||
      pad.shape === "circle" ||
      pad.shape === "rotated_rect" ||
      pad.shape === "pill" ||
      pad.shape === "rotated_pill"
    ) {
      this._setPositionFromLayout({ x: pad.x + deltaX, y: pad.y + deltaY })
    } else if (pad.shape === "polygon") {
      db.pcb_smtpad.update(this.pcb_smtpad_id, {
        points: pad.points.map((p) => ({
          x: p.x + deltaX,
          y: p.y + deltaY,
        })),
      })

      const paste = db.pcb_solder_paste
        .list()
        .find((element) => element.pcb_smtpad_id === this.pcb_smtpad_id)
      if (paste?.shape === "polygon") {
        const displacement = translate(deltaX, deltaY)
        db.pcb_solder_paste.update(paste.pcb_solder_paste_id, {
          x: paste.x + deltaX,
          y: paste.y + deltaY,
          points: paste.points.map((point) =>
            applyToPoint(displacement, point),
          ),
        })
      }
      this.matchedPort?._setPositionFromLayout(
        this._getPcbCircuitJsonBounds().center,
      )
    }
  }
}
