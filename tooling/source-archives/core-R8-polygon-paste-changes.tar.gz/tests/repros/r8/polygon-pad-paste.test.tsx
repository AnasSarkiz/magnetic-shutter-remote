import { expect, test } from "bun:test"
import { getTestFixture } from "tests/fixtures/get-test-fixture"

const points = [
  { x: 0, y: 0 },
  { x: 2, y: 0 },
  { x: 2, y: 1 },
  { x: 1, y: 1 },
  { x: 1, y: 2 },
  { x: 0, y: 2 },
]
for (const ccwRotationDegrees of [0, 90, 180, 270]) {
  test(`polygon paste preserves concavity and registration at${ccwRotationDegrees}deg`, () => {
    const { circuit } = getTestFixture()
    circuit.add(
      <board width={20} height={20} routingDisabled>
        <chip
          name="U1"
          pcbX={3}
          pcbY={-2}
          pcbRotation={ccwRotationDegrees}
          footprint={
            <footprint>
              <smtpad shape="polygon" points={points} solderPasteMargin={0} />
            </footprint>
          }
        />
      </board>,
    )
    circuit.render()
    const pad = circuit.db.pcb_smtpad.list()[0]
    const paste = circuit.db.pcb_solder_paste.list()[0]
    expect(paste).toBeDefined()
    if (pad.shape !== "polygon" || paste.shape !== "polygon")
      throw new Error("Expected polygon pad/paste")
    expect(paste.points).toEqual(pad.points)
    expect(paste.pcb_smtpad_id).toBe(pad.pcb_smtpad_id)
    expect(paste.pcb_component_id).toBe(pad.pcb_component_id)
    expect(paste.layer).toBe(pad.layer)
    expect(paste.points).toHaveLength(6)
    expect(circuit.getCircuitJson()).toMatchPcbSnapshot(
      `${import.meta.dir}/polygon-pad-paste-${ccwRotationDegrees}.test.tsx`,
    )
  })
}

test("covered polygon creates no solder paste", () => {
  const { circuit } = getTestFixture()
  circuit.add(
    <board width={10} height={10} routingDisabled>
      <chip
        name="U1"
        footprint={
          <footprint>
            <smtpad shape="polygon" points={points} coveredWithSolderMask />
          </footprint>
        }
      />
    </board>,
  )
  circuit.render()
  expect(circuit.db.pcb_solder_paste.list()).toHaveLength(0)
})

test("polygon paste follows a layout translation without losing its concavity", () => {
  const { circuit } = getTestFixture()
  circuit.add(
    <board width={20} height={20} routingDisabled>
      <chip
        name="U1"
        footprint={
          <footprint>
            <smtpad shape="polygon" points={points} solderPasteMargin={0} />
          </footprint>
        }
      />
    </board>,
  )
  circuit.render()
  const primitive = circuit.selectOne("smtpad")
  if (!primitive) throw new Error("Missing polygon primitive")
  primitive._moveCircuitJsonElements({ deltaX: 2, deltaY: -3 })
  const pad = circuit.db.pcb_smtpad.list()[0]
  const paste = circuit.db.pcb_solder_paste.list()[0]
  if (pad.shape !== "polygon" || paste.shape !== "polygon")
    throw new Error("Expected polygon pad/paste")
  expect(paste.points).toEqual(pad.points)
  expect(paste.x).toBe(3)
  expect(paste.y).toBe(-2)
})

test("polygon paste default preserves the existing 0.7 scale", () => {
  const { circuit } = getTestFixture()
  circuit.add(
    <board width={20} height={20} routingDisabled>
      <chip
        name="U1"
        footprint={
          <footprint>
            <smtpad
              shape="polygon"
              points={[
                { x: 0, y: 0 },
                { x: 2, y: 0 },
                { x: 2, y: 2 },
                { x: 0, y: 2 },
              ]}
            />
          </footprint>
        }
      />
    </board>,
  )
  circuit.render()
  const paste = circuit.db.pcb_solder_paste.list()[0]
  if (paste.shape !== "polygon") throw new Error("Expected polygon paste")
  expect(Math.min(...paste.points.map((p) => p.x))).toBeCloseTo(0.3, 9)
  expect(Math.max(...paste.points.map((p) => p.x))).toBeCloseTo(1.7, 9)
})

test("unsupported polygon paste offsets fail explicitly", () => {
  const { circuit } = getTestFixture()
  circuit.add(
    <board width={20} height={20} routingDisabled>
      <chip
        name="U1"
        footprint={
          <footprint>
            <smtpad shape="polygon" points={points} solderPasteMargin={-0.1} />
          </footprint>
        }
      />
    </board>,
  )
  expect(() => circuit.render()).toThrow("requires polygon offset support")
  expect(circuit.db.pcb_solder_paste.list()).toHaveLength(0)
})
